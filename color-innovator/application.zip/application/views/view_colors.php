<?php $this->load->view('notification'); ?>
<div class="row">
    <div class="col-xs-12">
		<table class="table table-responsive" id="view_colors_tbl">
			<thead>
				<tr><th>SR No.</th><th>Color</th><th>Hex Code</th><th>Image</th><th>Coarse</th><th>Fine</th><th>Status</th><th>Operation</th></tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>
</div>