<div class="banner product application_page">
<img src="<?php echo base_url();?>homepage_assests/new_images_1/dinoflex-made-flat-stays-flat-bg_1.jpg" style="width:100%;height:auto;" />
			<div class="banner_content_container">
				<div class="background_small_image"></div>
				<div class="container-fluid">
					
					<div class="row banner_product">
                       
					<div class="banner_content col-sm-12">
						<div class="bg_small_img"></div> 
						<h2 class="page-title"><span><?php echo $product_1['title']; ?></span></h2>
						<div class="subhead">
							<img src="<?php echo base_url(); ?>homepage_assests/image/tile_square.png" class="tile_square">
							NEXT STEP<sub>TM</sub><span>Walk Soft</span>
						</div>
						<span>Luxury Vinyl Tile</span>						
						<div class="row">
							<p class="col-md-3 col-sm-1"></p>
							<p class="text-right col-md-9 col-sm-10 top_content_category"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<?php echo $product_1['header_content']; ?>
							</p>
						</div>
						
						<div class="row">
							<div class="col-md-6 col-sm-1"></div>
								<div class="col-md-4 col-sm-10 btn_skewx text-center" >
									<a href="<?php echo base_url(); ?>front_end/product_category"><div class="text-skewx"><span>more info</span>
												</div>
									</a>
								</div>
						</div>
							
					</div>
				    
					</div>
				</div>
			</div>
		</div>

<div class="container">
	<div class="row">
		
			
					<h1 align="center"> Comming Soon... </h1>		


	</div>
	<div class="row">
		 <h3 align="center">Interested in this product</h3>
	</div>
	<div class="row section1">
		<div class="col-md-4"></div>
			<div class="col-md-4 all_products">
				
				<div class="btn_skewx">
					<div class="text-skewx">
						<a class="sample_request">Request Quote</a>
					</div>
				</div>
								
			</div>
		<div class="col-md-4"></div>
	</div>
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8 sit_logo">
			<img src="<?php echo base_url(); ?>homepage_assests/image/gsa-logo.png">
			<img src="<?php echo base_url(); ?>homepage_assests/image/scs-logo.png">
			<img src="<?php echo base_url(); ?>homepage_assests/image/cgbc-logo.png">
			<img src="<?php echo base_url(); ?>homepage_assests/image/recycled-rubber-floor-logo.png">
			<img src="<?php echo base_url(); ?>homepage_assests/image/usgbc-logo.png">
			<img src="<?php echo base_url(); ?>homepage_assests/image/floor-score-logo.png">
		</div>
		<div class="col-md-2"></div>
	</div>
</div>