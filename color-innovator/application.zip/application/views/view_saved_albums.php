<?php $this->load->view('notification'); ?>
<div class="row">
    <div class="col-xs-12">
		<table class="table table-responsive" id="view_saved_album_tbl">
			<thead>
				<tr><th>SR No.</th><th>Swatch Name</th><th>Image</th><th>Swatch Info</th><th>Created Date</th><th>Operation</th></tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>
</div>