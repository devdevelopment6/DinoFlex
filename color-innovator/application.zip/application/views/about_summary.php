<div class="container about_section about_margin_top">
		<div class="row">
			<div class="col-md-6">
				<img src="<?php echo base_url(); ?>homepage_assests/image/about-environment.jpg" class="img-responsive img_margin_top1">
			</div>
			<div class="col-md-6">
				<div class="row ">
					<div class="col-md-12">
						<h2 class="body_content"><?php echo $about['banner_content_title_1']; ?></h2>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<p><?php echo $about['banner_content_1']; ?></p>
					</div>
				</div>
                
				<div class="row banner_content section1">
					<div class="col-md-0 col-sm-2"></div>
					<div class="col-md-12 col-sm-10 btn_skewx text-center btn">
						<a href="<?php echo base_url(); ?>front_end/about#about_us"><div class="text-skewx"><span>Back</span></div></a>
					</div>
					<div class="col-md-4 col-sm-10"></div>
				</div>
			</div>
		</div>
		
	 </div>
     
     <div class="row margin_right1">
			<div class="col-md-2"></div>
			<div class="col-md-8 col-sm-12 sit_logo">
				<img src="<?php echo base_url(); ?>homepage_assests/image/gsa-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/scs-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/cgbc-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/recycled-rubber-floor-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/usgbc-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/floor-score-logo.png">
			</div>
			<div class="col-md-2"></div>
			
			
		</div>