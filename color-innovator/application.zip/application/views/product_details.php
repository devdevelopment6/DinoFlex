
<div class=""> 
				<div class="container-fluid">
					
						<div class="col-md-3 float_right right"></div>
						<div class="">
                            <div class="col-md-4 float_right about_content_2">
                            
                                <h2 class="page-title"><span><?php echo $about['top_content_title']; ?></span></h2>
                                <div class="subhead about_header_content">
                                    <img src="<?php echo base_url(); ?>homepage_assests/image/tile_square.png" class="tile_square">
                                    NEXT STEP<sub>TM</sub><span>Walk Soft</span>
                                </div>
                                <span class="about_header_content_2">Luxury Vinyl Tile</span>						
                                <div class="row">
                                    <p class="col-md-3 col-sm-1"></p>
                                    <p class="text-right col-md-9 col-sm-10 content_about"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<?php echo $about['top_content']; ?></p>
                                    
                                </div>
                                <?php /*?><div class="row">
                                <div class="col-md-6 col-sm-1"></div>
                                    <div class="col-md-4 col-sm-9 btn_skewx text-center" >
                                        <a href="<?php echo base_url();?>front_end/about_content"><div class="text-skewx"><span>more info</span>
                                                    </div>
                                        </a>
                                    </div>
                                </div><?php */?>
                            </div>
                        </div>
                        
						<div class="col-md-3 float_right">
							<!--<img src="image/about-tile-texture-border-01.png">-->
						</div>

										
					
					
				</div>
			</div>
                    
       <div class="about_content">          
          <div class="row margin_right1">
			<div class="col-md-2"></div>
			<div class="col-md-8 col-sm-12 sit_logo">
				<img src="<?php echo base_url(); ?>homepage_assests/image/gsa-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/scs-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/cgbc-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/recycled-rubber-floor-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/usgbc-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/floor-score-logo.png">
			</div>
			<div class="col-md-2"></div>
			
		</div>	
		</div>