<div class="row margin_right1">
			<div class="col-md-2"></div>
			<div class="col-md-8 col-sm-12 sit_logo">
				<img src="<?php echo base_url(); ?>homepage_assests/image/scs-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/cgbc-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/recycled-rubber-floor-logo.png">
				<img src="<?php echo base_url(); ?>homepage_assests/image/usgbc-logo.png">
			</div>
			<div class="col-md-2"></div>
			
			
		</div>