<?php $this->load->view('notification'); ?>
<?php /*?>
<footer class="footer_section">
	<div class="footer_bg">
		<div class="container">
			<div class="row">
				<div class="col-md-4 footer_social">
					<div class="contact">
						<h3>Contact Us</h3>
						<p>email:<?php echo $contacts['email'];?><br>
							phone:<?php echo $contacts['phone_no'];?></p>
					</div>
					<div class="address">
                            <p><?php echo $contacts['address'];?></p>
					</div>

					<div class="social_media">
						<h3>Follow Us</h3>
						
						<div class="nav navbar-nav social_link">
							<div class="display_inline"><a href="<?php echo ($contacts['fb_link']!='')?$contacts['fb_link']:'#';?>" class="footer_social "><i class="fa fa-facebook-official" aria-hidden="true"></i></a>
							</div>
							<div class="display_inline"><a href="<?php echo ($contacts['twitter_link']!='')?$contacts['twitter_link']:'#';?>" class="footer_social "><i class="fa fa-twitter-square" aria-hidden="true"></i></a></div>
							<div class="display_inline"><a href="<?php echo ($contacts['pinterest_link']!='')?$contacts['pinterest_link']:'#';?>" class="footer_social "><i class="fa fa-pinterest-square" aria-hidden="true"></i></a>
							</div>
							<div class="display_inline"><a href="<?php echo ($contacts['linkedin_link']!='')?$contacts['linkedin_link']:'#';?>" class="footer_social"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></div>
						</div>
						
					</div>
					<div class="cmp_reserve">
						<p>    &copy; Dinoflex recycled rubber innovators.<br>
							All rights reserved. 2018</p>
					</div>
				</div>
                <div class="col-md-4">
                	<div></div>
                </div>
                 <div class="col-md-4">
                	<div class="req_footer_1">
                    	<p><button type="button" id="req_sample" class="sample_request_2"><div class="req_footer">Request a Sample</div></button></p>
                    </div>
                </div>
			</div>
		</div>
	</div>
	<div class="background_small_scr_footer"></div>
</footer><?php */?>

<div class="footer_container ">
	<div class="container">
		<div class="row">
           <div class="container">	
				<div class="col-md-12 new_footer_cls">
					<div class="col-md-4">
						<h3 class="social_media">Contact Us</h3>
						<ul class="ul_footer_top_margin">
				

								<li><a href="#" class="sample_request">Request a Sample</a>
								</li>
								<li><a href="http://madmimi.com/signups/f1484eca39e74246b730960818c9da1a/join" target="_blank">Subscribe to Our Mailing List</a></li>
							</ul>
					</div>
					
					<div class="col-md-5">
						<h3 class="read_more_line">Technical Information</h3>
						<div class="footer_info">
                        
                        	<?php /*?><a href="<?php echo base_url();?>front_end/sustainability" class="footer_read_more">Sustainability</a><br/><?php */?>
                            
                        	<a href="#" class="footer_read_more">Read More</a>
                        </div>
				<?php /*?>     <div class="row">
						<div class="col-md-12">
							<div class="sit_logo">
								<img src="<?php echo base_url(); ?>homepage_assests/image/gsa-logo.png" class="footer_img_2">
								<img src="<?php echo base_url(); ?>homepage_assests/image/scs-logo.png" class="footer_img_2">
								<img src="<?php echo base_url(); ?>homepage_assests/image/cgbc-logo.png" class="footer_img_2">
								<img src="<?php echo base_url(); ?>homepage_assests/image/recycled-rubber-floor-logo.png" class="footer_img_2">
								<img src="<?php echo base_url(); ?>homepage_assests/image/usgbc-logo.png" class="footer_img_2">
								<img src="<?php echo base_url(); ?>homepage_assests/image/floor-score-logo.png" class="footer_img_2">
							</div>
						</div>
					</div>	<?php */?>
                        <div>
							<div class="sit_logo col-md-12">
								<img src="<?php echo base_url(); ?>homepage_assests/image/scs-logo.png" class="footer_img_2" alt="scs-logo">
								<img src="<?php echo base_url(); ?>homepage_assests/image/cgbc-logo.png" class="footer_img_2" alt="cgbc-logo">
								<img src="<?php echo base_url(); ?>homepage_assests/image/recycled-rubber-floor-logo.png" class="footer_img_2" alt="recycled-rubber-floor-logo">
								<img src="<?php echo base_url(); ?>homepage_assests/image/usgbc-logo.png" class="footer_img_2" alt="usgbc-logo">
							</div>
						</div>
					</div>
			   	    <div class="col-md-3">
					   <div class="social_media">
							<h3>Follow Us</h3>
							<div class="col-md-12 nav navbar-nav social_link">
								<div class="display_inline"><a href="<?php echo ($contacts['fb_link']!='')?$contacts['fb_link']:'#';?>" class="footer_social ">
									<img src="<?php echo base_url().'homepage_assests/new_images_1/facebook-footer-icon.svg'; ?>" class="footer_new_icons" alt="facebook_logo" /></a>
								</div>
								<div class="display_inline"><a href="<?php echo ($contacts['twitter_link']!='')?$contacts['twitter_link']:'#';?>" class="footer_social "><img src="<?php echo base_url().'homepage_assests/new_images_1/twitter-footer-icon.svg'; ?>" class="footer_new_icons" alt="twitter_logo"/></a></div>
								<div class="display_inline"><a href="<?php echo ($contacts['pinterest_link']!='')?$contacts['pinterest_link']:'#';?>" class="footer_social "><img src="<?php echo base_url().'homepage_assests/new_images_1/pinterest-footer-icon.svg'; ?>" class="footer_new_icons" alt="pinterest_logo"/></a></div>
								<div class="display_inline"><a href="<?php echo ($contacts['linkedin_link']!='')?$contacts['linkedin_link']:'#';?>" class="footer_social"><img src="<?php echo base_url().'homepage_assests/new_images_1/linkedin-footer-icon.svg'; ?>" class="footer_new_icons" alt="linkedin_logo"/></a></div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-12">
					<div class="cmp_reserve footer_line">
						<p>&copy; Dinoflex recycled rubber innovators. All rights reserved. 2018</p>
				 	</div>
				</div>
           </div>  
        </div>
    </div>
</div>



<div class="container-fluid mobile_footer_container">
	<div class="row first_div">
    	<?php /*?><img src="<?php echo base_url().'homepage_assests/image/footer-tile-texture-border.png'; ?>" /><?php */?>
    </div>  
    <div class="row second_div">
    	<div class="col-md-12">
        	
            <div class="col-md-4">
				<h3 class="social_media">Contact Us</h3>
				<ul class="ul_footer_top_margin">
				

						<li><a href="#" class="sample_request">Request a Sample</a>
						</li>
						<li><a href="http://madmimi.com/signups/f1484eca39e74246b730960818c9da1a/join" target="_blank">Subscribe to Our Mailing List</a></li>
					</ul>
			</div>
            <div class="col-md-4">
                     <h3 class="read_more_line">Technical Information</h3>
                     <div class="footer_info"><a href="#" class="footer_read_more">Read More</a></div>
                     <div class="row">
                        <div class="col-md-12">
                            <div class="sit_logo">
                                <img src="<?php echo base_url(); ?>homepage_assests/image/scs-logo.png" class="footer_img_2" alt="scs-logo">
                                <img src="<?php echo base_url(); ?>homepage_assests/image/cgbc-logo.png" class="footer_img_2" alt="cgbc-logo">
                                <img src="<?php echo base_url(); ?>homepage_assests/image/recycled-rubber-floor-logo.png" class="footer_img_2" alt="recycled-rubber-floor-logo">
                                <img src="<?php echo base_url(); ?>homepage_assests/image/usgbc-logo.png" class="footer_img_2" alt="usgbc-logo">
                            </div>
                        </div>
                    </div>	
                            <div></div>
                    </div>
			<div class="col-md-4">
           <?php /*?> <div class="contact">
				
				<p style="margin-top:15px;"><a class="sample_request_2" style="padding:3px !important;"><span class="req_footer" style="padding:0px !important;">Request a Sample</span></a></p>
                <h3>Contact Us</h3>
                <p>email:<?php echo $contacts['email'];?><br>
                    phone:<?php echo $contacts['phone_no'];?></p>
            </div>
            <div class="address">
                    <p><?php echo $contacts['address'];?></p>
            </div><?php */?>

            <div class="social_media">
                <h3>Follow Us</h3>
                
                <div class="nav navbar-nav social_link">
                    <div class="display_inline"><a href="<?php echo ($contacts['fb_link']!='')?$contacts['fb_link']:'#';?>" class="footer_social "><img src="<?php echo base_url().'homepage_assests/new_images_1/facebook-footer-icon.svg'; ?>" class="footer_new_icons" /></i></a>
                                </div>
                                <div class="display_inline"><a href="<?php echo ($contacts['twitter_link']!='')?$contacts['twitter_link']:'#';?>" class="footer_social "><img src="<?php echo base_url().'homepage_assests/new_images_1/twitter-footer-icon.svg'; ?>" class="footer_new_icons"/></a></div>
                                <div class="display_inline"><a href="<?php echo ($contacts['pinterest_link']!='')?$contacts['pinterest_link']:'#';?>" class="footer_social "><img src="<?php echo base_url().'homepage_assests/new_images_1/pinterest-footer-icon.svg'; ?>" class="footer_new_icons"/></a></div>
                                <div class="display_inline"><a href="<?php echo ($contacts['linkedin_link']!='')?$contacts['linkedin_link']:'#';?>" class="footer_social"><img src="<?php echo base_url().'homepage_assests/new_images_1/linkedin-footer-icon.svg'; ?>" class="footer_new_icons"/></a></div>
                    </div>
                </div>
                
            </div>
            </div>        
            <div class="cmp_reserve">
                <p>    &copy; Dinoflex recycled rubber innovators.<br>
                    All rights reserved. 2018</p>
            </div>
        </div>
    </div>
   <?php /*?> <div  class="row third_div">
        <img  src="<?php echo base_url().'homepage_assests/image/footer-landing.jpg'; ?>" class="first_image" />
    </div><?php */?>
</div>
</body>
</html>

<div class="modal fade sample_request_form" role="dialog" id="">
	<div class="modal-dialog modal-sm modal_width">
		<div class="modal-content">
			<div class="modal-header">
            <img src="http://oneco.ca/~dinoflex/Color_innovator/homepage_assests/image/dinoflex-logo.png" class="modal_logo" alt="dinoflex-logo"/>
				<button type="button" class="close" data-dismiss="modal" style="color: #000;">
					<span class="fa fa-close"></span>
				</button>
				
			</div>
			<div class="modal-body">
				<div class="tab-content">
					<div id="order_sample_req" class="tab-pane fade in active">
                    <h3>Request a Product Sample</h3>
                    <p>In order for us to best serve you, please ensure that the following form is completely filled out.
					For additional sales and product information:<br><strong>Phone: </strong> 1.877.713.1899 <br><strong>Email: </strong> <a href="mailto:info@dinoflex.com">info@dinoflex.com</a></p>
						<form id="sample_form" name="sample_form">
                        <div class="form-group">
                        	<label class="login_error error" ></label>
                        </div>
                        	<?php
								$product_name = '';
							    $product_id = $this->uri->segment(3);
								if($product_id != '')
								{	
									$filter = array(
											'id'	=>	$product_id,
										);							
									$product_1 = $this->common_model->get_single('products',$filter);
									$product_name = $product_1['product_name'];
								}
								else
								{
									$product_name = '';
								}
							?>
							<div class="form-group">
								<label for="current_project">Current Project:</label>
								<input type="text" class="form-control" id="current_project" placeholder="Enter Current Project" name="current_project" value="<?php echo ($product_name !='')?$product_name:'';?>" >
							</div>
							<div class="form-group">
								<label for="future_project">Future Project</label>
								<input type="text" class="form-control" id="future_project" placeholder="Enter Future Project" name="future_project" >


							</div>
                            <div class="form-group">
								<label for="square_footage">Square Footage of Project?</label>
								<input type="text" class="form-control" id="square_footage" placeholder="Enter Square Footage" name="square_footage" >
							</div>
                            <div class="form-group">
                                    <label class="left">Tell us about yourself:</label>
                                    <br>
                					<div class="row">
                                    	<div class="col-md-12">
                                        	
                                                <input type="radio" name="yourself" id="Architect" value="Architect">
                                                <label for="Architect">Architect</label><br/>
                            
                                                <input type="radio" name="yourself" id="Building_Owner" value="Building_Owner">
                                                <label for="Building_Owner">Building Owner</label><br/>
                            
                                                <input type="radio" name="yourself" id="Facility_Manager" value="Facility_Manager">
                                                <label for="Facility_Manager">Facility Manager</label><br/>
                                                
                                                <input type="radio" name="yourself" id="Interior_Design_Consultant" value="Interior_Design_Consultant">
                                                <label for="Interior_Design_Consultant">Interior Design Consultant</label><br/>
                            
                                                <input type="radio" name="yourself" id="Flooring_Contractor" value="Flooring_Contractor">
                                                <label for="Flooring_Contractor">Flooring Contractor</label><br/>
                                           
                                                <input type="radio" name="yourself" id="General_Contractor" value="General_Contractor">
                                                <label for="General_Contractor">General Contractor</label><br/>

                                                <input type="radio" name="yourself" id="Retailer" value="Retailer">
                                                <label for="Retailer">Retailer</label><br/>
                            
                                                <input type="radio" name="yourself" id="Student" value="Student">
                                                <label for="Student">Student</label><br/>
                            
                                                <input type="radio" name="yourself" id="Home_Owner" value="Home_Owner">
                                                <label for="Home_Owner">Home Owner</label><br/>
                            
                                                <input type="radio" name="yourself" id="Other" value="Other">
                                                <label for="Other">Other</label><br/>
                                               
                                        </div>
                					</div>
                                </div>
                                <div class="form-group">
                                        <label class="left">Which Products you are Interested in:</label><br><br>
                    					<div class="row">
                                    		<div class="col-md-12">
                                                    <label class="left">Interior Flooring</label>
                                                    <br>
                                                    <input type="checkbox" name="interior_floor[]" value="Sport_Mat_Flooring">
                                                    <label for="Sport_Mat_Flooring">Sport Mat Flooring</label><br/>
                                
                                                    <input type="checkbox" name="interior_floor[]" value="Evolution_Flooring">
                                                    <label for="Evolution_Flooring">Evolution Flooring</label><br/>
                                
                                                    <input type="checkbox" name="interior_floor[]" value="Stride_Fitness_Tiles">
                                                    <label for="Stride_Fitness_Tiles">Stride Fitness Tiles</label><br/>

                                                    <input type="checkbox" name="interior_floor[]" value="Next_Step_Walk_Soft">
                                                    <label for="Next_Step_Walk_Soft">Next Step Walk Soft</label><br/>
                                
                                                    <input type="checkbox" name="interior_floor[]" value="Next_Step_Luxury">
                                                    <label for="Next_Step_Luxury">Next Step Luxury</label><br/>
                                                    
                                                    <input type="checkbox" name="interior_floor[]" value="Next_Step_High_Impact">
                                                    <label for="Next_Step_High_Impact">Next Step High Impact</label><br/>
                                
                                                    <input type="checkbox" name="interior_floor[]" value="Dinomat">
                                                    <label for="Dinomat">Dinomat®</label><br/>
                    						</div>
                                      </div>
                                </div>
                            	<div class="form-group">
                                    <label class="left">Exterior Surfacing</label>
                                    <br>
                                    <input type="checkbox" name="exterior_floor[]" value="Cushion_Walk_Pavers">
                                    <label for="Cushion_Walk_Pavers">Cushion Walk Pavers</label><br/>
                
                                    <input type="checkbox" name="exterior_floor[]" value="Playground_Tiles">
                                    <label for="Playground_Tiles">Playground Tiles</label><br/>
                
                                    <input type="checkbox" name="exterior_floor[]" value="NuVista_Tiles">
                                    <label for="NuVista_Tiles">NuVista Tiles</label><br/>
                                </div>
                				<div class="form-group">
                                    <label for="other_products">Other Products</label>
                                    <input type="text" class="form-control" id="other_products" placeholder="Enter Other Products" name="other_products" >
								</div>
                            	<div class="form-group">
                                    <label for="additional_notes">Additional Notes</label><br>
                                    <textarea name="additional_notes" cols="30" rows="4" id="additional_notes"></textarea>
                                </div>
                                <div class="form-group texts"><h3>Contact Information</h3>
                                    <p>* Asterisk Indicates Required Field.</p>
                
                                    <label for="name" class="left required">Name*</label><br>
                                    <input name="name" class="form-control" type="text" id="name" value="" size="30" maxlength="50">
                                    <br>
                
                                    <label for="company" class="left required">Company</label><br>
                                    <input name="company" class="form-control" type="text" id="company" value="" size="30" maxlength="50">
                                    <br>
                
                                    <label for="address" class="left required">Address*</label><br>
                                    <input name="address" class="form-control" type="text" id="address" value="" size="30" maxlength="50">
                                    <br>
                
                                    <label for="city" class="left required">City*</label><br>
                                    <input name="city" class="form-control" type="text" id="city" value="" size="30" maxlength="50">
                                    <br>
                
                                    <label for="prov" class="left required">State / Province*</label><br>
                                    <input name="state"  class="form-control" type="text" id="state" value="" size="30" maxlength="50">
                                    <br>
                
                                    <label for="postal" class="left required">Zip / Postal*</label><br>
                                    <input name="postal" class="form-control" type="text" id="postal" value="" size="30" maxlength="50">
                                    <br>
                
                                    <label for="email" class="left required">Email*</label><br>
                                    <input name="email" class="form-control" type="email" id="email" value="" size="30" maxlength="50">
                                    <br>
                
                                    <label for="phone" class="left required">Telephone*</label><br>
                                    <input name="phone" class="form-control" type="text" id="phone" value="" size="30" maxlength="50">
                                    <br>
                
                                    <label for="fax" class="left required">Fax</label><br>
                                    <input name="fax" class="form-control" type="text" id="fax" value="" size="30" maxlength="50">
                                    <br>
                                     <div class="g-recaptcha" data-sitekey="6LcYZ0AUAAAAANSNv7WOxoLHEn229F7vDHQFaHVT"></div>
                                      <span class="text-danger"><?php echo form_error('g-recaptcha-response'); ?></span>
                                </div>
                               

							<input type="submit" class="btn btn-primary" id="order_sample" value="Order Your Sample" name="submit">
						</form>
					</div>
					

				</div>
			</div>
		</div>
	</div>
</div>