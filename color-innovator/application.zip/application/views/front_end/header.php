<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?php echo base_url(); ?>homepage_assests/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="<?php echo base_url(); ?>homepage_assests/css/bootstrap-theme.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
	<link rel="stylesheet" href="<?php echo base_url(); ?>homepage_assests/css/custom.css"/>
	<script src="<?php echo base_url(); ?>homepage_assests/js/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
	<script src="<?php echo base_url(); ?>homepage_assests/js/bootstrap.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src="<?php echo base_url(); ?>homepage_assests/js/main.js"></script>
    <script type="text/javascript">var base_url = "<?php echo base_url(); ?>"; </script>
	
    <link rel="stylesheet" href="<?php echo base_url(); ?>FlexSlider-master/demo/css/flexslider.css" type="text/css">
    <script src="<?php echo base_url(); ?>FlexSlider-master/demo/js/jquery.flexslider.js"></script>
    <script src="<?php echo base_url(); ?>FlexSlider-master/demo/js/modernizr.js"></script>
    <link href="https://instituteofchildpsychology.com/inc/css/magnific-popup.css" rel="stylesheet" type="text/css" />
    <script src="https://instituteofchildpsychology.com/inc/js/jquery.magnific-popup.min.js"></script>
    <link href="https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" type="text/css" />
	<link href="https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/assets/owl.theme.default.min.css" rel="stylesheet" type="text/css" />
	<script src="https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/owl.carousel.js"></script>

 <script type="text/javascript">
   
    jQuery(window).load(function(){
      jQuery('#onetwo').flexslider({
        animation: "slide",
        animationLoop: false,
        itemWidth: 210,
        itemMargin: 5,
        minItems: 2,
        maxItems: 12,
        start: function(slider){
          jQuery('body').removeClass('loading');
          jQuery('#onetwo div.flex-viewport').addClass('col-md-11 col-md-offset-1');
		  
		  jQuery('.popup-link').magnificPopup({
	type: 'image',
	gallery:{enabled:true}
});
        }
      }); 
	  jQuery('#slider').flexslider({
        animation: "slide",
        animationLoop: false,
        itemWidth: 210,
        itemMargin: 5,
        minItems: 2,
        maxItems: 3,
        start: function(slider){
          jQuery('body').removeClass('loading');
		  
		  jQuery('.popup-link').magnificPopup({
	type: 'image',
	gallery:{enabled:true}
});
        }
      });
	  jQuery('#colorslider1').flexslider({
        animation: "slide",
        animationLoop: false,
        itemWidth: 210,
        itemMargin: 5,
        minItems: 2,
        maxItems: 3,
        start: function(slider){
          jQuery('body').removeClass('loading');
		  
jQuery('.popup-link').magnificPopup({
	type: 'image',
	gallery:{enabled:true}
});
        }
      });
	  jQuery('#colorslider2').flexslider({
        animation: "slide",
        animationLoop: false,
        itemWidth: 210,
        itemMargin: 5,
        minItems: 2,
        maxItems: 3,
        start: function(slider){
          jQuery('body').removeClass('loading');
		  
		  jQuery('.popup-link').magnificPopup({
	type: 'image',
	gallery:{enabled:true}
});
        }
      });
	  jQuery('#colorslider3').flexslider({
        animation: "slide",
        animationLoop: false,
        itemWidth: 210,
        itemMargin: 5,
        minItems: 2,
        maxItems: 3,
        start: function(slider){
          jQuery('body').removeClass('loading');
		  
		  jQuery('.popup-link').magnificPopup({
	type: 'image',
	gallery:{enabled:true}
});
        }
      });
	  jQuery('#colorslider4').flexslider({
        animation: "slide",
        animationLoop: false,
        itemWidth: 210,
        itemMargin: 5,
        minItems: 2,
        maxItems: 3,
        start: function(slider){
          jQuery('body').removeClass('loading');
		  
		  jQuery('.popup-link').magnificPopup({
	type: 'image',
	gallery:{enabled:true}
});
        }
      });
	  jQuery('#colorslider5').flexslider({
        animation: "slide",
        animationLoop: false,
        itemWidth: 210,
        itemMargin: 5,
        minItems: 2,
        maxItems: 3,
        start: function(slider){
          jQuery('body').removeClass('loading');
		  
		  jQuery('.popup-link').magnificPopup({
	type: 'image',
	gallery:{enabled:true}
});
        }
      });
	  jQuery('#colorslider6').flexslider({
        animation: "slide",
        animationLoop: false,
        itemWidth: 210,
        itemMargin: 5,
        minItems: 2,
        maxItems: 3,
        start: function(slider){
          jQuery('body').removeClass('loading');
		  
		  jQuery('.popup-link').magnificPopup({
	type: 'image',
	gallery:{enabled:true}
});
        }
      });
	  jQuery('#colorslider7').flexslider({
        animation: "slide",
        animationLoop: false,
        itemWidth: 210,
        itemMargin: 5,
        minItems: 2,
        maxItems: 3,
        start: function(slider){
          jQuery('body').removeClass('loading');
		  
		  jQuery('.popup-link').magnificPopup({
	type: 'image',
	gallery:{enabled:true}
});
        }
      });
	  
    });
  </script>

    
</head>
<body>
<header>
	<div class="container menuhide">
	    <div class="row">
	    </div>
		<nav class="navbar navbar-inverse menu row">
			<div class="container-fluid">
				<!--<div class="navbar-header">
					
				</div>-->
				<div class="collapse navbar-collapse" id="myNavbar"  aria-expanded="false" style='height: 29px;'>
					<div class="col-md-12">
						<ul class="nav navbar-nav navbar-right social_link">
                			<li class="make_menu_2"><div class="call_us">Questions? Call us: </div> <div class="call_us_2"> 877 713-1899 </div></li>
                            <?php /*?><li>
                                <form class="navbar-form navbar-left search" action="#">
                                    <button type="button" class="btn btn-default search" id="search_btn"><i class="fa fa-search" aria-hidden="true"></i></button>
                                </form>
                            </li><?php */?>
                            <li><a href="#"><img src="<?php echo base_url(); ?>homepage_assests/new_images_1/twitter-icon.svg" class="header_icons" alt="twitter-icon"/></a></li>
                            <li><a href="#"><img src="<?php echo base_url(); ?>homepage_assests/new_images_1/facebook-icon.svg" class="header_icons" alt="facebook-icon" /></a></li>
                            <li><a href="#"><img src="<?php echo base_url(); ?>homepage_assests/new_images_1/pinterest-icon.svg" class="header_icons" alt="pinterest-icon"/></a></li>
                            <li><a href="#"><img src="<?php echo base_url(); ?>homepage_assests/new_images_1/linkedin-icon.svg" class="header_icons" alt="linkedin-icon"/></a></li>
                        </ul>
					</div>
                	<div class="col-md-3">
                		<button type="button" class="navbar-toggle " data-toggle="collapse" data-target="#myNavbar" aria-expanded="false">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
						</button>
						<a href="<?php echo base_url(); ?>front_end"><img src="<?php echo base_url(); ?>homepage_assests/new_images_1/dinoflex-logo.svg" alt="dinoflex_logo" class="dinoflex_logo"/></a>
                   	</div>
                    <div class="col-md-9" id="mymenubar">
                		<!--<ul class="nav navbar-nav navbar-right social_link">
                			<li class="make_menu_2"><div class="call_us">Questions? Call us: </div> <div class="call_us_2"> 877 713-1899 </div></li>
                            <?php /*?><li>
                                <form class="navbar-form navbar-left search" action="#">
                                    <button type="button" class="btn btn-default search" id="search_btn"><i class="fa fa-search" aria-hidden="true"></i></button>
                                </form>
                            </li><?php */?>
                            <li><a href="#"><img src="<?php echo base_url(); ?>homepage_assests/new_images_1/twitter-icon.svg" class="header_icons" alt="twitter-icon"/></a></li>
                            <li><a href="#"><img src="<?php echo base_url(); ?>homepage_assests/new_images_1/facebook-icon.svg" class="header_icons" alt="facebook-icon" /></a></li>
                            <li><a href="#"><img src="<?php echo base_url(); ?>homepage_assests/new_images_1/pinterest-icon.svg" class="header_icons" alt="pinterest-icon"/></a></li>
                            <li><a href="#"><img src="<?php echo base_url(); ?>homepage_assests/new_images_1/linkedin-icon.svg" class="header_icons" alt="linkedin-icon"/></a></li>
                        </ul>-->
						<ul class="nav navbar-nav make_menu">
							<li><a href="<?php echo base_url(); ?>front_end/<?php echo str_replace(array('-'),"_","about_us")?>">About</a></li>
							<li class="dropdown app_tab"> <a class="dropdown-toggle app_navtab" data-toggle="dropdown" href="#">Best Use &nbsp;<span class="fa fa-caret-right dropdown_arraow"></span></a>
							 	<ul class="dropdown-menu app_dropdown_items">
								 <?php
								 	$get_app_categories= $this->common_model->get_by_condition('application_categories',array('status'=>1),array("display_order","ASC"));
								 	if($get_app_categories!=false){
										foreach($get_app_categories as $cat){
								 ?>
								 	<li><a href="<?php echo base_url(); ?>front_end/application_category/<?php echo str_replace(array(' ',"/"),array("_",'-'),$cat['category_name']); ?>"><?php echo $cat['category_name']; ?></a></li>
								 <?php }} ?>
								
								</ul>
							</li>
                        	<!--<li class="dropdown app_tab"> <a class="dropdown-toggle" href="<?php //echo base_url(); ?>front_end/applications">Best Use</a> </li>-->
                       		<?php /*?><li><img src="<?php echo base_url(); ?>homepage_assests/new_images_1/dinoflex-sub-menu-icon.svg" class="" /></li><?php */?>
							<li class="dropdown product_tab">
                                <a class="dropdown-toggle products_navtab" data-toggle="dropdown" href="#">Products&nbsp; <span class="fa fa-caret-right dropdown_arraow"></span></a>
                                <ul class="dropdown-menu product_dropdown_items">
                                	<li><a href="<?php echo base_url(); ?>front_end/product_category">All Products</a></li>
                                    <li><a href="<?php echo base_url(); ?>front_end/indoor_products">Indoor</a></li>
                                    <li><a href="<?php echo base_url(); ?>front_end/outdoor_products">Outdoor</a></li>
                                    <li><a href="<?php echo base_url(); ?>front_end/speciality_products">Specialty</a></li>
                                </ul> 
                            </li>   
                            <li class="dropdown"><a class="dropdown-toggle" href="<?php echo base_url(); ?>front_end/case_studies">Case Studies</a></li>
                            <li><a href="<?php echo base_url(); ?>front_end/blog">Blog</a></li>
                            <li><a href="<?php echo base_url(); ?>front_end/contact">Contact</a></li>
                            <li><a href="<?php echo base_url(); ?>" target="_blank"><img src="<?php echo base_url(); ?>homepage_assests/image/colour-innovator-logo.png" alt="dinoflex_color_innovator_logo"></a></li>
                            <?php /*?><li><a href="<?php echo base_url(); ?>front_end/news">News</a></li><?php */?>
                        </ul>
					</div>
				</div>
                <form class="navbar-form navbar-left search" action="#" id="search_form" style="display:none;">
                			<div class="form-group">
                       		 <input type="text" id="search" name="search" placeholder="Keywords..." class="form-control">
                            </div>
                             <button type="submit" class="btn btn-default" id="submit_search"><i class="fa fa-search" aria-hidden="true"></i></button>
                        </form>
			</div>
		</nav>

	</div>
</header>

	

<script type="text/javascript">
$(document).ready(function(){
	
	$("#search_btn").on('click',function(){
		$("#search_form").toggle();
	});
	 
	/*$('.products_navtab').click(function(){
		 window.location.href = "<?php echo base_url(); ?>front_end/product_category";
	});*/
	 
	$(".product_tab").click(
        function() {
            $('.product_dropdown_items').slideToggle('medium');
        });
	$(".app_tab").click(
        function() {
            $('.app_dropdown_items').slideToggle('medium');
        });
});
</script>