<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-14 11:49:04 --> Config Class Initialized
INFO - 2020-10-14 11:49:04 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:49:04 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:49:04 --> Utf8 Class Initialized
INFO - 2020-10-14 11:49:04 --> URI Class Initialized
INFO - 2020-10-14 11:49:04 --> Router Class Initialized
INFO - 2020-10-14 11:49:04 --> Output Class Initialized
INFO - 2020-10-14 11:49:04 --> Security Class Initialized
DEBUG - 2020-10-14 11:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:49:04 --> CSRF cookie sent
INFO - 2020-10-14 11:49:04 --> Input Class Initialized
INFO - 2020-10-14 11:49:04 --> Language Class Initialized
ERROR - 2020-10-14 11:49:04 --> 404 Page Not Found: /index
INFO - 2020-10-14 11:49:06 --> Config Class Initialized
INFO - 2020-10-14 11:49:06 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:49:06 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:49:06 --> Utf8 Class Initialized
INFO - 2020-10-14 11:49:06 --> URI Class Initialized
INFO - 2020-10-14 11:49:06 --> Router Class Initialized
INFO - 2020-10-14 11:49:06 --> Output Class Initialized
INFO - 2020-10-14 11:49:06 --> Security Class Initialized
DEBUG - 2020-10-14 11:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:49:06 --> CSRF cookie sent
INFO - 2020-10-14 11:49:06 --> CSRF token verified
INFO - 2020-10-14 11:49:06 --> Input Class Initialized
INFO - 2020-10-14 11:49:06 --> Language Class Initialized
INFO - 2020-10-14 11:49:06 --> Language Class Initialized
INFO - 2020-10-14 11:49:06 --> Config Class Initialized
INFO - 2020-10-14 11:49:06 --> Loader Class Initialized
INFO - 2020-10-14 11:49:06 --> Helper loaded: url_helper
INFO - 2020-10-14 11:49:06 --> Helper loaded: file_helper
INFO - 2020-10-14 11:49:06 --> Helper loaded: string_helper
INFO - 2020-10-14 11:49:06 --> Database Driver Class Initialized
INFO - 2020-10-14 11:49:06 --> Email Class Initialized
INFO - 2020-10-14 11:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 11:49:06 --> Controller Class Initialized
DEBUG - 2020-10-14 11:49:06 --> Home MX_Controller Initialized
INFO - 2020-10-14 11:49:06 --> Model "Common_model" initialized
ERROR - 2020-10-14 11:49:06 --> Severity: Notice --> Undefined index: SPT_DOCROOT /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 820
ERROR - 2020-10-14 11:49:06 --> Severity: Warning --> imagepng(/color-innovator/uploads/user_custom_images/10/20201014102102184-merge.png): failed to open stream: No such file or directory /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 885
INFO - 2020-10-14 11:49:06 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 11:49:06 --> Final output sent to browser
DEBUG - 2020-10-14 11:49:06 --> Total execution time: 0.2227
INFO - 2020-10-14 11:52:57 --> Config Class Initialized
INFO - 2020-10-14 11:52:57 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:52:57 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:52:57 --> Utf8 Class Initialized
INFO - 2020-10-14 11:52:57 --> URI Class Initialized
INFO - 2020-10-14 11:52:57 --> Router Class Initialized
INFO - 2020-10-14 11:52:57 --> Output Class Initialized
INFO - 2020-10-14 11:52:57 --> Security Class Initialized
DEBUG - 2020-10-14 11:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:52:57 --> CSRF cookie sent
INFO - 2020-10-14 11:52:57 --> Input Class Initialized
INFO - 2020-10-14 11:52:57 --> Language Class Initialized
ERROR - 2020-10-14 11:52:57 --> 404 Page Not Found: /index
INFO - 2020-10-14 11:58:00 --> Config Class Initialized
INFO - 2020-10-14 11:58:00 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:58:00 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:58:00 --> Utf8 Class Initialized
INFO - 2020-10-14 11:58:00 --> URI Class Initialized
INFO - 2020-10-14 11:58:00 --> Router Class Initialized
INFO - 2020-10-14 11:58:00 --> Output Class Initialized
INFO - 2020-10-14 11:58:00 --> Security Class Initialized
DEBUG - 2020-10-14 11:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:58:00 --> CSRF cookie sent
INFO - 2020-10-14 11:58:00 --> Input Class Initialized
INFO - 2020-10-14 11:58:00 --> Language Class Initialized
ERROR - 2020-10-14 11:58:00 --> 404 Page Not Found: /index
INFO - 2020-10-14 11:58:03 --> Config Class Initialized
INFO - 2020-10-14 11:58:03 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:58:03 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:58:03 --> Utf8 Class Initialized
INFO - 2020-10-14 11:58:03 --> URI Class Initialized
INFO - 2020-10-14 11:58:03 --> Router Class Initialized
INFO - 2020-10-14 11:58:03 --> Output Class Initialized
INFO - 2020-10-14 11:58:03 --> Security Class Initialized
DEBUG - 2020-10-14 11:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:58:03 --> CSRF cookie sent
INFO - 2020-10-14 11:58:03 --> CSRF token verified
INFO - 2020-10-14 11:58:03 --> Input Class Initialized
INFO - 2020-10-14 11:58:03 --> Language Class Initialized
INFO - 2020-10-14 11:58:03 --> Language Class Initialized
INFO - 2020-10-14 11:58:03 --> Config Class Initialized
INFO - 2020-10-14 11:58:03 --> Loader Class Initialized
INFO - 2020-10-14 11:58:03 --> Helper loaded: url_helper
INFO - 2020-10-14 11:58:03 --> Helper loaded: file_helper
INFO - 2020-10-14 11:58:03 --> Helper loaded: string_helper
INFO - 2020-10-14 11:58:03 --> Database Driver Class Initialized
INFO - 2020-10-14 11:58:03 --> Email Class Initialized
INFO - 2020-10-14 11:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 11:58:03 --> Controller Class Initialized
DEBUG - 2020-10-14 11:58:03 --> Home MX_Controller Initialized
INFO - 2020-10-14 11:58:03 --> Model "Common_model" initialized
INFO - 2020-10-14 11:58:48 --> Config Class Initialized
INFO - 2020-10-14 11:58:48 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:58:48 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:58:48 --> Utf8 Class Initialized
INFO - 2020-10-14 11:58:48 --> URI Class Initialized
INFO - 2020-10-14 11:58:48 --> Router Class Initialized
INFO - 2020-10-14 11:58:48 --> Output Class Initialized
INFO - 2020-10-14 11:58:48 --> Security Class Initialized
DEBUG - 2020-10-14 11:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:58:48 --> CSRF cookie sent
INFO - 2020-10-14 11:58:48 --> Input Class Initialized
INFO - 2020-10-14 11:58:48 --> Language Class Initialized
ERROR - 2020-10-14 11:58:48 --> 404 Page Not Found: /index
INFO - 2020-10-14 11:58:51 --> Config Class Initialized
INFO - 2020-10-14 11:58:51 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:58:51 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:58:51 --> Utf8 Class Initialized
INFO - 2020-10-14 11:58:51 --> URI Class Initialized
INFO - 2020-10-14 11:58:51 --> Router Class Initialized
INFO - 2020-10-14 11:58:51 --> Output Class Initialized
INFO - 2020-10-14 11:58:51 --> Security Class Initialized
DEBUG - 2020-10-14 11:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:58:51 --> CSRF cookie sent
INFO - 2020-10-14 11:58:51 --> CSRF token verified
INFO - 2020-10-14 11:58:51 --> Input Class Initialized
INFO - 2020-10-14 11:58:51 --> Language Class Initialized
INFO - 2020-10-14 11:58:51 --> Language Class Initialized
INFO - 2020-10-14 11:58:51 --> Config Class Initialized
INFO - 2020-10-14 11:58:51 --> Loader Class Initialized
INFO - 2020-10-14 11:58:51 --> Helper loaded: url_helper
INFO - 2020-10-14 11:58:51 --> Helper loaded: file_helper
INFO - 2020-10-14 11:58:51 --> Helper loaded: string_helper
INFO - 2020-10-14 11:58:51 --> Database Driver Class Initialized
INFO - 2020-10-14 11:58:51 --> Email Class Initialized
INFO - 2020-10-14 11:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 11:58:51 --> Controller Class Initialized
DEBUG - 2020-10-14 11:58:51 --> Home MX_Controller Initialized
INFO - 2020-10-14 11:58:51 --> Model "Common_model" initialized
INFO - 2020-10-14 11:58:56 --> Config Class Initialized
INFO - 2020-10-14 11:58:56 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:58:56 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:58:56 --> Utf8 Class Initialized
INFO - 2020-10-14 11:58:56 --> URI Class Initialized
INFO - 2020-10-14 11:58:56 --> Router Class Initialized
INFO - 2020-10-14 11:58:56 --> Output Class Initialized
INFO - 2020-10-14 11:58:56 --> Security Class Initialized
DEBUG - 2020-10-14 11:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:58:56 --> CSRF cookie sent
INFO - 2020-10-14 11:58:56 --> Input Class Initialized
INFO - 2020-10-14 11:58:56 --> Language Class Initialized
INFO - 2020-10-14 11:58:56 --> Language Class Initialized
INFO - 2020-10-14 11:58:56 --> Config Class Initialized
INFO - 2020-10-14 11:58:56 --> Loader Class Initialized
INFO - 2020-10-14 11:58:56 --> Helper loaded: url_helper
INFO - 2020-10-14 11:58:56 --> Helper loaded: file_helper
INFO - 2020-10-14 11:58:56 --> Helper loaded: string_helper
INFO - 2020-10-14 11:58:56 --> Database Driver Class Initialized
INFO - 2020-10-14 11:58:56 --> Email Class Initialized
INFO - 2020-10-14 11:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 11:58:56 --> Controller Class Initialized
DEBUG - 2020-10-14 11:58:56 --> Home MX_Controller Initialized
INFO - 2020-10-14 11:58:56 --> Model "Common_model" initialized
DEBUG - 2020-10-14 11:58:56 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 11:58:56 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 11:58:56 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 11:58:56 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/make.php
DEBUG - 2020-10-14 11:58:56 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 11:58:56 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 11:58:56 --> Final output sent to browser
DEBUG - 2020-10-14 11:58:56 --> Total execution time: 0.0494
INFO - 2020-10-14 11:58:58 --> Config Class Initialized
INFO - 2020-10-14 11:58:58 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:58:58 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:58:58 --> Utf8 Class Initialized
INFO - 2020-10-14 11:58:58 --> URI Class Initialized
INFO - 2020-10-14 11:58:58 --> Router Class Initialized
INFO - 2020-10-14 11:58:58 --> Output Class Initialized
INFO - 2020-10-14 11:58:58 --> Security Class Initialized
DEBUG - 2020-10-14 11:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:58:58 --> CSRF cookie sent
INFO - 2020-10-14 11:58:58 --> Input Class Initialized
INFO - 2020-10-14 11:58:58 --> Language Class Initialized
ERROR - 2020-10-14 11:58:58 --> 404 Page Not Found: /index
INFO - 2020-10-14 11:58:59 --> Config Class Initialized
INFO - 2020-10-14 11:58:59 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:58:59 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:58:59 --> Utf8 Class Initialized
INFO - 2020-10-14 11:58:59 --> URI Class Initialized
INFO - 2020-10-14 11:58:59 --> Router Class Initialized
INFO - 2020-10-14 11:58:59 --> Output Class Initialized
INFO - 2020-10-14 11:58:59 --> Security Class Initialized
DEBUG - 2020-10-14 11:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:58:59 --> CSRF cookie sent
INFO - 2020-10-14 11:58:59 --> Input Class Initialized
INFO - 2020-10-14 11:58:59 --> Language Class Initialized
INFO - 2020-10-14 11:58:59 --> Language Class Initialized
INFO - 2020-10-14 11:58:59 --> Config Class Initialized
INFO - 2020-10-14 11:58:59 --> Loader Class Initialized
INFO - 2020-10-14 11:58:59 --> Helper loaded: url_helper
INFO - 2020-10-14 11:58:59 --> Helper loaded: file_helper
INFO - 2020-10-14 11:58:59 --> Helper loaded: string_helper
INFO - 2020-10-14 11:58:59 --> Database Driver Class Initialized
INFO - 2020-10-14 11:58:59 --> Email Class Initialized
INFO - 2020-10-14 11:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 11:58:59 --> Controller Class Initialized
DEBUG - 2020-10-14 11:58:59 --> Home MX_Controller Initialized
INFO - 2020-10-14 11:58:59 --> Model "Common_model" initialized
INFO - 2020-10-14 11:58:59 --> Final output sent to browser
DEBUG - 2020-10-14 11:58:59 --> Total execution time: 0.0738
INFO - 2020-10-14 11:58:59 --> Config Class Initialized
INFO - 2020-10-14 11:58:59 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:58:59 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:58:59 --> Utf8 Class Initialized
INFO - 2020-10-14 11:58:59 --> URI Class Initialized
INFO - 2020-10-14 11:58:59 --> Router Class Initialized
INFO - 2020-10-14 11:58:59 --> Output Class Initialized
INFO - 2020-10-14 11:58:59 --> Security Class Initialized
DEBUG - 2020-10-14 11:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:58:59 --> CSRF cookie sent
INFO - 2020-10-14 11:58:59 --> CSRF token verified
INFO - 2020-10-14 11:58:59 --> Input Class Initialized
INFO - 2020-10-14 11:58:59 --> Language Class Initialized
INFO - 2020-10-14 11:58:59 --> Language Class Initialized
INFO - 2020-10-14 11:58:59 --> Config Class Initialized
INFO - 2020-10-14 11:58:59 --> Loader Class Initialized
INFO - 2020-10-14 11:58:59 --> Helper loaded: url_helper
INFO - 2020-10-14 11:58:59 --> Helper loaded: file_helper
INFO - 2020-10-14 11:58:59 --> Helper loaded: string_helper
INFO - 2020-10-14 11:58:59 --> Config Class Initialized
INFO - 2020-10-14 11:58:59 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:58:59 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:58:59 --> Utf8 Class Initialized
INFO - 2020-10-14 11:58:59 --> URI Class Initialized
INFO - 2020-10-14 11:58:59 --> Database Driver Class Initialized
INFO - 2020-10-14 11:58:59 --> Router Class Initialized
INFO - 2020-10-14 11:58:59 --> Output Class Initialized
INFO - 2020-10-14 11:58:59 --> Security Class Initialized
DEBUG - 2020-10-14 11:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:58:59 --> CSRF cookie sent
INFO - 2020-10-14 11:58:59 --> CSRF token verified
INFO - 2020-10-14 11:58:59 --> Input Class Initialized
INFO - 2020-10-14 11:58:59 --> Language Class Initialized
INFO - 2020-10-14 11:58:59 --> Email Class Initialized
INFO - 2020-10-14 11:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 11:58:59 --> Controller Class Initialized
DEBUG - 2020-10-14 11:58:59 --> Home MX_Controller Initialized
INFO - 2020-10-14 11:58:59 --> Model "Common_model" initialized
INFO - 2020-10-14 11:58:59 --> Language Class Initialized
INFO - 2020-10-14 11:58:59 --> Config Class Initialized
INFO - 2020-10-14 11:58:59 --> Final output sent to browser
DEBUG - 2020-10-14 11:58:59 --> Total execution time: 0.0286
INFO - 2020-10-14 11:58:59 --> Loader Class Initialized
INFO - 2020-10-14 11:58:59 --> Helper loaded: url_helper
INFO - 2020-10-14 11:58:59 --> Helper loaded: file_helper
INFO - 2020-10-14 11:58:59 --> Helper loaded: string_helper
INFO - 2020-10-14 11:58:59 --> Database Driver Class Initialized
INFO - 2020-10-14 11:58:59 --> Email Class Initialized
INFO - 2020-10-14 11:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 11:58:59 --> Controller Class Initialized
DEBUG - 2020-10-14 11:58:59 --> Home MX_Controller Initialized
INFO - 2020-10-14 11:58:59 --> Model "Common_model" initialized
INFO - 2020-10-14 11:58:59 --> Final output sent to browser
DEBUG - 2020-10-14 11:58:59 --> Total execution time: 0.0336
INFO - 2020-10-14 11:59:16 --> Config Class Initialized
INFO - 2020-10-14 11:59:16 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:59:16 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:59:16 --> Utf8 Class Initialized
INFO - 2020-10-14 11:59:16 --> URI Class Initialized
INFO - 2020-10-14 11:59:16 --> Router Class Initialized
INFO - 2020-10-14 11:59:16 --> Output Class Initialized
INFO - 2020-10-14 11:59:16 --> Security Class Initialized
DEBUG - 2020-10-14 11:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:59:16 --> CSRF cookie sent
INFO - 2020-10-14 11:59:16 --> Input Class Initialized
INFO - 2020-10-14 11:59:16 --> Language Class Initialized
ERROR - 2020-10-14 11:59:16 --> 404 Page Not Found: /index
INFO - 2020-10-14 11:59:20 --> Config Class Initialized
INFO - 2020-10-14 11:59:20 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:59:20 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:59:20 --> Utf8 Class Initialized
INFO - 2020-10-14 11:59:20 --> URI Class Initialized
INFO - 2020-10-14 11:59:20 --> Router Class Initialized
INFO - 2020-10-14 11:59:20 --> Output Class Initialized
INFO - 2020-10-14 11:59:20 --> Security Class Initialized
DEBUG - 2020-10-14 11:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:59:20 --> CSRF cookie sent
INFO - 2020-10-14 11:59:20 --> CSRF token verified
INFO - 2020-10-14 11:59:20 --> Input Class Initialized
INFO - 2020-10-14 11:59:20 --> Language Class Initialized
INFO - 2020-10-14 11:59:20 --> Language Class Initialized
INFO - 2020-10-14 11:59:20 --> Config Class Initialized
INFO - 2020-10-14 11:59:20 --> Loader Class Initialized
INFO - 2020-10-14 11:59:20 --> Helper loaded: url_helper
INFO - 2020-10-14 11:59:20 --> Helper loaded: file_helper
INFO - 2020-10-14 11:59:20 --> Helper loaded: string_helper
INFO - 2020-10-14 11:59:20 --> Database Driver Class Initialized
INFO - 2020-10-14 11:59:20 --> Email Class Initialized
INFO - 2020-10-14 11:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 11:59:20 --> Controller Class Initialized
DEBUG - 2020-10-14 11:59:20 --> Home MX_Controller Initialized
INFO - 2020-10-14 11:59:20 --> Model "Common_model" initialized
INFO - 2020-10-14 11:59:38 --> Config Class Initialized
INFO - 2020-10-14 11:59:38 --> Hooks Class Initialized
DEBUG - 2020-10-14 11:59:38 --> UTF-8 Support Enabled
INFO - 2020-10-14 11:59:38 --> Utf8 Class Initialized
INFO - 2020-10-14 11:59:38 --> URI Class Initialized
INFO - 2020-10-14 11:59:38 --> Router Class Initialized
INFO - 2020-10-14 11:59:38 --> Output Class Initialized
INFO - 2020-10-14 11:59:38 --> Security Class Initialized
DEBUG - 2020-10-14 11:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 11:59:38 --> CSRF cookie sent
INFO - 2020-10-14 11:59:38 --> Input Class Initialized
INFO - 2020-10-14 11:59:38 --> Language Class Initialized
INFO - 2020-10-14 11:59:38 --> Language Class Initialized
INFO - 2020-10-14 11:59:38 --> Config Class Initialized
INFO - 2020-10-14 11:59:38 --> Loader Class Initialized
INFO - 2020-10-14 11:59:38 --> Helper loaded: url_helper
INFO - 2020-10-14 11:59:38 --> Helper loaded: file_helper
INFO - 2020-10-14 11:59:38 --> Helper loaded: string_helper
INFO - 2020-10-14 11:59:38 --> Database Driver Class Initialized
INFO - 2020-10-14 11:59:38 --> Email Class Initialized
INFO - 2020-10-14 11:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 11:59:38 --> Controller Class Initialized
DEBUG - 2020-10-14 11:59:38 --> Home MX_Controller Initialized
INFO - 2020-10-14 11:59:38 --> Model "Common_model" initialized
ERROR - 2020-10-14 11:59:38 --> Severity: Notice --> Trying to access array offset on value of type null /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 895
ERROR - 2020-10-14 11:59:38 --> Severity: Notice --> Trying to access array offset on value of type null /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 896
ERROR - 2020-10-14 11:59:38 --> Severity: Notice --> Trying to access array offset on value of type bool /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 903
ERROR - 2020-10-14 11:59:38 --> Severity: Notice --> Trying to access array offset on value of type bool /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 904
ERROR - 2020-10-14 11:59:38 --> Severity: Notice --> Trying to access array offset on value of type null /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 906
ERROR - 2020-10-14 11:59:38 --> Severity: Notice --> Trying to access array offset on value of type bool /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 907
ERROR - 2020-10-14 11:59:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dinof2/public_html/color-innovator/system/core/Exceptions.php:271) /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 835
INFO - 2020-10-14 12:00:45 --> Config Class Initialized
INFO - 2020-10-14 12:00:45 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:00:45 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:00:45 --> Utf8 Class Initialized
INFO - 2020-10-14 12:00:45 --> URI Class Initialized
INFO - 2020-10-14 12:00:45 --> Router Class Initialized
INFO - 2020-10-14 12:00:45 --> Output Class Initialized
INFO - 2020-10-14 12:00:45 --> Security Class Initialized
DEBUG - 2020-10-14 12:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:00:45 --> CSRF cookie sent
INFO - 2020-10-14 12:00:45 --> Input Class Initialized
INFO - 2020-10-14 12:00:45 --> Language Class Initialized
INFO - 2020-10-14 12:00:45 --> Language Class Initialized
INFO - 2020-10-14 12:00:45 --> Config Class Initialized
INFO - 2020-10-14 12:00:45 --> Loader Class Initialized
INFO - 2020-10-14 12:00:45 --> Helper loaded: url_helper
INFO - 2020-10-14 12:00:45 --> Helper loaded: file_helper
INFO - 2020-10-14 12:00:45 --> Helper loaded: string_helper
INFO - 2020-10-14 12:00:45 --> Database Driver Class Initialized
INFO - 2020-10-14 12:00:45 --> Email Class Initialized
INFO - 2020-10-14 12:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:00:45 --> Controller Class Initialized
DEBUG - 2020-10-14 12:00:45 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:00:45 --> Model "Common_model" initialized
ERROR - 2020-10-14 12:00:45 --> Severity: Notice --> Trying to access array offset on value of type null /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 895
ERROR - 2020-10-14 12:00:45 --> Severity: Notice --> Trying to access array offset on value of type null /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 896
ERROR - 2020-10-14 12:00:45 --> Severity: Notice --> Trying to access array offset on value of type bool /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 903
ERROR - 2020-10-14 12:00:45 --> Severity: Notice --> Trying to access array offset on value of type bool /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 904
ERROR - 2020-10-14 12:00:45 --> Severity: Notice --> Trying to access array offset on value of type null /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 906
ERROR - 2020-10-14 12:00:45 --> Severity: Notice --> Trying to access array offset on value of type bool /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 907
ERROR - 2020-10-14 12:00:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dinof2/public_html/color-innovator/system/core/Exceptions.php:271) /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 835
INFO - 2020-10-14 12:01:36 --> Config Class Initialized
INFO - 2020-10-14 12:01:36 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:01:36 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:01:36 --> Utf8 Class Initialized
INFO - 2020-10-14 12:01:36 --> URI Class Initialized
INFO - 2020-10-14 12:01:36 --> Router Class Initialized
INFO - 2020-10-14 12:01:36 --> Output Class Initialized
INFO - 2020-10-14 12:01:36 --> Security Class Initialized
DEBUG - 2020-10-14 12:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:01:36 --> CSRF cookie sent
INFO - 2020-10-14 12:01:36 --> Input Class Initialized
INFO - 2020-10-14 12:01:36 --> Language Class Initialized
ERROR - 2020-10-14 12:01:36 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:01:39 --> Config Class Initialized
INFO - 2020-10-14 12:01:39 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:01:39 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:01:39 --> Utf8 Class Initialized
INFO - 2020-10-14 12:01:39 --> URI Class Initialized
INFO - 2020-10-14 12:01:39 --> Router Class Initialized
INFO - 2020-10-14 12:01:39 --> Output Class Initialized
INFO - 2020-10-14 12:01:39 --> Security Class Initialized
DEBUG - 2020-10-14 12:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:01:39 --> CSRF cookie sent
INFO - 2020-10-14 12:01:39 --> CSRF token verified
INFO - 2020-10-14 12:01:39 --> Input Class Initialized
INFO - 2020-10-14 12:01:39 --> Language Class Initialized
INFO - 2020-10-14 12:01:39 --> Language Class Initialized
INFO - 2020-10-14 12:01:39 --> Config Class Initialized
INFO - 2020-10-14 12:01:39 --> Loader Class Initialized
INFO - 2020-10-14 12:01:39 --> Helper loaded: url_helper
INFO - 2020-10-14 12:01:39 --> Helper loaded: file_helper
INFO - 2020-10-14 12:01:39 --> Helper loaded: string_helper
INFO - 2020-10-14 12:01:39 --> Database Driver Class Initialized
INFO - 2020-10-14 12:01:39 --> Email Class Initialized
INFO - 2020-10-14 12:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:01:39 --> Controller Class Initialized
DEBUG - 2020-10-14 12:01:39 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:01:39 --> Model "Common_model" initialized
INFO - 2020-10-14 12:01:49 --> Config Class Initialized
INFO - 2020-10-14 12:01:49 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:01:49 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:01:49 --> Utf8 Class Initialized
INFO - 2020-10-14 12:01:49 --> URI Class Initialized
INFO - 2020-10-14 12:01:49 --> Router Class Initialized
INFO - 2020-10-14 12:01:49 --> Output Class Initialized
INFO - 2020-10-14 12:01:49 --> Security Class Initialized
DEBUG - 2020-10-14 12:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:01:49 --> CSRF cookie sent
INFO - 2020-10-14 12:01:49 --> Input Class Initialized
INFO - 2020-10-14 12:01:49 --> Language Class Initialized
INFO - 2020-10-14 12:01:49 --> Language Class Initialized
INFO - 2020-10-14 12:01:49 --> Config Class Initialized
INFO - 2020-10-14 12:01:49 --> Loader Class Initialized
INFO - 2020-10-14 12:01:49 --> Helper loaded: url_helper
INFO - 2020-10-14 12:01:49 --> Helper loaded: file_helper
INFO - 2020-10-14 12:01:49 --> Helper loaded: string_helper
INFO - 2020-10-14 12:01:49 --> Database Driver Class Initialized
INFO - 2020-10-14 12:01:49 --> Email Class Initialized
INFO - 2020-10-14 12:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:01:49 --> Controller Class Initialized
DEBUG - 2020-10-14 12:01:49 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:01:49 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:01:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:01:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:01:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:01:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/make.php
DEBUG - 2020-10-14 12:01:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:01:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:01:49 --> Final output sent to browser
DEBUG - 2020-10-14 12:01:49 --> Total execution time: 0.0374
INFO - 2020-10-14 12:01:51 --> Config Class Initialized
INFO - 2020-10-14 12:01:51 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:01:51 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:01:51 --> Utf8 Class Initialized
INFO - 2020-10-14 12:01:51 --> URI Class Initialized
INFO - 2020-10-14 12:01:51 --> Router Class Initialized
INFO - 2020-10-14 12:01:51 --> Output Class Initialized
INFO - 2020-10-14 12:01:51 --> Security Class Initialized
DEBUG - 2020-10-14 12:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:01:51 --> CSRF cookie sent
INFO - 2020-10-14 12:01:51 --> Input Class Initialized
INFO - 2020-10-14 12:01:51 --> Language Class Initialized
ERROR - 2020-10-14 12:01:51 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:01:53 --> Config Class Initialized
INFO - 2020-10-14 12:01:53 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:01:53 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:01:53 --> Utf8 Class Initialized
INFO - 2020-10-14 12:01:53 --> URI Class Initialized
INFO - 2020-10-14 12:01:53 --> Router Class Initialized
INFO - 2020-10-14 12:01:53 --> Output Class Initialized
INFO - 2020-10-14 12:01:53 --> Security Class Initialized
DEBUG - 2020-10-14 12:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:01:53 --> CSRF cookie sent
INFO - 2020-10-14 12:01:53 --> Input Class Initialized
INFO - 2020-10-14 12:01:53 --> Language Class Initialized
INFO - 2020-10-14 12:01:53 --> Language Class Initialized
INFO - 2020-10-14 12:01:53 --> Config Class Initialized
INFO - 2020-10-14 12:01:53 --> Loader Class Initialized
INFO - 2020-10-14 12:01:53 --> Helper loaded: url_helper
INFO - 2020-10-14 12:01:53 --> Helper loaded: file_helper
INFO - 2020-10-14 12:01:53 --> Helper loaded: string_helper
INFO - 2020-10-14 12:01:53 --> Database Driver Class Initialized
INFO - 2020-10-14 12:01:53 --> Config Class Initialized
INFO - 2020-10-14 12:01:53 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:01:53 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:01:53 --> Utf8 Class Initialized
INFO - 2020-10-14 12:01:53 --> URI Class Initialized
INFO - 2020-10-14 12:01:53 --> Router Class Initialized
INFO - 2020-10-14 12:01:53 --> Email Class Initialized
INFO - 2020-10-14 12:01:53 --> Output Class Initialized
INFO - 2020-10-14 12:01:53 --> Security Class Initialized
INFO - 2020-10-14 12:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:01:53 --> Controller Class Initialized
DEBUG - 2020-10-14 12:01:53 --> Home MX_Controller Initialized
DEBUG - 2020-10-14 12:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:01:53 --> CSRF cookie sent
INFO - 2020-10-14 12:01:53 --> CSRF token verified
INFO - 2020-10-14 12:01:53 --> Input Class Initialized
INFO - 2020-10-14 12:01:53 --> Language Class Initialized
INFO - 2020-10-14 12:01:53 --> Model "Common_model" initialized
INFO - 2020-10-14 12:01:53 --> Final output sent to browser
DEBUG - 2020-10-14 12:01:53 --> Total execution time: 0.0276
INFO - 2020-10-14 12:01:53 --> Language Class Initialized
INFO - 2020-10-14 12:01:53 --> Config Class Initialized
INFO - 2020-10-14 12:01:53 --> Loader Class Initialized
INFO - 2020-10-14 12:01:53 --> Helper loaded: url_helper
INFO - 2020-10-14 12:01:53 --> Helper loaded: file_helper
INFO - 2020-10-14 12:01:53 --> Helper loaded: string_helper
INFO - 2020-10-14 12:01:53 --> Database Driver Class Initialized
INFO - 2020-10-14 12:01:53 --> Email Class Initialized
INFO - 2020-10-14 12:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:01:53 --> Controller Class Initialized
DEBUG - 2020-10-14 12:01:53 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:01:53 --> Model "Common_model" initialized
INFO - 2020-10-14 12:01:53 --> Final output sent to browser
DEBUG - 2020-10-14 12:01:53 --> Total execution time: 0.0276
INFO - 2020-10-14 12:01:54 --> Config Class Initialized
INFO - 2020-10-14 12:01:54 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:01:54 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:01:54 --> Utf8 Class Initialized
INFO - 2020-10-14 12:01:54 --> URI Class Initialized
INFO - 2020-10-14 12:01:54 --> Router Class Initialized
INFO - 2020-10-14 12:01:54 --> Output Class Initialized
INFO - 2020-10-14 12:01:54 --> Security Class Initialized
DEBUG - 2020-10-14 12:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:01:54 --> CSRF cookie sent
INFO - 2020-10-14 12:01:54 --> CSRF token verified
INFO - 2020-10-14 12:01:54 --> Input Class Initialized
INFO - 2020-10-14 12:01:54 --> Language Class Initialized
INFO - 2020-10-14 12:01:54 --> Language Class Initialized
INFO - 2020-10-14 12:01:54 --> Config Class Initialized
INFO - 2020-10-14 12:01:54 --> Loader Class Initialized
INFO - 2020-10-14 12:01:54 --> Helper loaded: url_helper
INFO - 2020-10-14 12:01:54 --> Helper loaded: file_helper
INFO - 2020-10-14 12:01:54 --> Helper loaded: string_helper
INFO - 2020-10-14 12:01:54 --> Database Driver Class Initialized
INFO - 2020-10-14 12:01:54 --> Email Class Initialized
INFO - 2020-10-14 12:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:01:54 --> Controller Class Initialized
DEBUG - 2020-10-14 12:01:54 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:01:54 --> Model "Common_model" initialized
INFO - 2020-10-14 12:01:54 --> Final output sent to browser
DEBUG - 2020-10-14 12:01:54 --> Total execution time: 0.0291
INFO - 2020-10-14 12:02:12 --> Config Class Initialized
INFO - 2020-10-14 12:02:12 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:02:12 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:02:12 --> Utf8 Class Initialized
INFO - 2020-10-14 12:02:12 --> URI Class Initialized
INFO - 2020-10-14 12:02:12 --> Router Class Initialized
INFO - 2020-10-14 12:02:12 --> Output Class Initialized
INFO - 2020-10-14 12:02:12 --> Security Class Initialized
DEBUG - 2020-10-14 12:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:02:12 --> CSRF cookie sent
INFO - 2020-10-14 12:02:12 --> Input Class Initialized
INFO - 2020-10-14 12:02:12 --> Language Class Initialized
ERROR - 2020-10-14 12:02:12 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:02:17 --> Config Class Initialized
INFO - 2020-10-14 12:02:17 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:02:17 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:02:17 --> Utf8 Class Initialized
INFO - 2020-10-14 12:02:17 --> URI Class Initialized
INFO - 2020-10-14 12:02:17 --> Router Class Initialized
INFO - 2020-10-14 12:02:17 --> Output Class Initialized
INFO - 2020-10-14 12:02:17 --> Security Class Initialized
DEBUG - 2020-10-14 12:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:02:17 --> CSRF cookie sent
INFO - 2020-10-14 12:02:17 --> CSRF token verified
INFO - 2020-10-14 12:02:17 --> Input Class Initialized
INFO - 2020-10-14 12:02:17 --> Language Class Initialized
INFO - 2020-10-14 12:02:17 --> Language Class Initialized
INFO - 2020-10-14 12:02:17 --> Config Class Initialized
INFO - 2020-10-14 12:02:17 --> Loader Class Initialized
INFO - 2020-10-14 12:02:17 --> Helper loaded: url_helper
INFO - 2020-10-14 12:02:17 --> Helper loaded: file_helper
INFO - 2020-10-14 12:02:17 --> Helper loaded: string_helper
INFO - 2020-10-14 12:02:17 --> Database Driver Class Initialized
INFO - 2020-10-14 12:02:17 --> Email Class Initialized
INFO - 2020-10-14 12:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:02:17 --> Controller Class Initialized
DEBUG - 2020-10-14 12:02:17 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:02:17 --> Model "Common_model" initialized
INFO - 2020-10-14 12:03:16 --> Config Class Initialized
INFO - 2020-10-14 12:03:16 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:03:16 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:03:16 --> Utf8 Class Initialized
INFO - 2020-10-14 12:03:16 --> URI Class Initialized
INFO - 2020-10-14 12:03:16 --> Router Class Initialized
INFO - 2020-10-14 12:03:16 --> Output Class Initialized
INFO - 2020-10-14 12:03:16 --> Security Class Initialized
DEBUG - 2020-10-14 12:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:03:16 --> CSRF cookie sent
INFO - 2020-10-14 12:03:16 --> Input Class Initialized
INFO - 2020-10-14 12:03:16 --> Language Class Initialized
ERROR - 2020-10-14 12:03:16 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:03:19 --> Config Class Initialized
INFO - 2020-10-14 12:03:19 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:03:19 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:03:19 --> Utf8 Class Initialized
INFO - 2020-10-14 12:03:19 --> URI Class Initialized
INFO - 2020-10-14 12:03:19 --> Router Class Initialized
INFO - 2020-10-14 12:03:19 --> Output Class Initialized
INFO - 2020-10-14 12:03:19 --> Security Class Initialized
DEBUG - 2020-10-14 12:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:03:19 --> CSRF cookie sent
INFO - 2020-10-14 12:03:19 --> CSRF token verified
INFO - 2020-10-14 12:03:19 --> Input Class Initialized
INFO - 2020-10-14 12:03:19 --> Language Class Initialized
INFO - 2020-10-14 12:03:19 --> Language Class Initialized
INFO - 2020-10-14 12:03:19 --> Config Class Initialized
INFO - 2020-10-14 12:03:19 --> Loader Class Initialized
INFO - 2020-10-14 12:03:19 --> Helper loaded: url_helper
INFO - 2020-10-14 12:03:19 --> Helper loaded: file_helper
INFO - 2020-10-14 12:03:19 --> Helper loaded: string_helper
INFO - 2020-10-14 12:03:19 --> Database Driver Class Initialized
INFO - 2020-10-14 12:03:19 --> Email Class Initialized
INFO - 2020-10-14 12:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:03:19 --> Controller Class Initialized
DEBUG - 2020-10-14 12:03:19 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:03:19 --> Model "Common_model" initialized
ERROR - 2020-10-14 12:03:20 --> Severity: Notice --> Undefined index: SPT_DOCROOT /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 820
ERROR - 2020-10-14 12:03:20 --> Severity: Warning --> imagepng(/color-innovator/uploads/user_custom_images/10/20201014102102184-merge.png): failed to open stream: No such file or directory /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 885
INFO - 2020-10-14 12:03:23 --> Config Class Initialized
INFO - 2020-10-14 12:03:23 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:03:23 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:03:23 --> Utf8 Class Initialized
INFO - 2020-10-14 12:03:23 --> URI Class Initialized
INFO - 2020-10-14 12:03:23 --> Router Class Initialized
INFO - 2020-10-14 12:03:23 --> Output Class Initialized
INFO - 2020-10-14 12:03:23 --> Security Class Initialized
DEBUG - 2020-10-14 12:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:03:23 --> CSRF cookie sent
INFO - 2020-10-14 12:03:23 --> Input Class Initialized
INFO - 2020-10-14 12:03:23 --> Language Class Initialized
INFO - 2020-10-14 12:03:23 --> Language Class Initialized
INFO - 2020-10-14 12:03:23 --> Config Class Initialized
INFO - 2020-10-14 12:03:23 --> Loader Class Initialized
INFO - 2020-10-14 12:03:23 --> Helper loaded: url_helper
INFO - 2020-10-14 12:03:23 --> Helper loaded: file_helper
INFO - 2020-10-14 12:03:23 --> Helper loaded: string_helper
INFO - 2020-10-14 12:03:23 --> Database Driver Class Initialized
INFO - 2020-10-14 12:03:23 --> Email Class Initialized
INFO - 2020-10-14 12:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:03:23 --> Controller Class Initialized
DEBUG - 2020-10-14 12:03:23 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:03:23 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:03:23 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:03:23 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:03:23 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:03:23 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/make.php
DEBUG - 2020-10-14 12:03:23 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:03:23 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:03:23 --> Final output sent to browser
DEBUG - 2020-10-14 12:03:23 --> Total execution time: 0.0434
INFO - 2020-10-14 12:03:25 --> Config Class Initialized
INFO - 2020-10-14 12:03:25 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:03:25 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:03:25 --> Utf8 Class Initialized
INFO - 2020-10-14 12:03:25 --> URI Class Initialized
INFO - 2020-10-14 12:03:25 --> Router Class Initialized
INFO - 2020-10-14 12:03:25 --> Output Class Initialized
INFO - 2020-10-14 12:03:25 --> Security Class Initialized
DEBUG - 2020-10-14 12:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:03:25 --> CSRF cookie sent
INFO - 2020-10-14 12:03:25 --> Input Class Initialized
INFO - 2020-10-14 12:03:25 --> Language Class Initialized
ERROR - 2020-10-14 12:03:25 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:03:27 --> Config Class Initialized
INFO - 2020-10-14 12:03:27 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:03:27 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:03:27 --> Utf8 Class Initialized
INFO - 2020-10-14 12:03:27 --> URI Class Initialized
INFO - 2020-10-14 12:03:27 --> Router Class Initialized
INFO - 2020-10-14 12:03:27 --> Output Class Initialized
INFO - 2020-10-14 12:03:27 --> Security Class Initialized
DEBUG - 2020-10-14 12:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:03:27 --> CSRF cookie sent
INFO - 2020-10-14 12:03:27 --> CSRF token verified
INFO - 2020-10-14 12:03:27 --> Input Class Initialized
INFO - 2020-10-14 12:03:27 --> Language Class Initialized
INFO - 2020-10-14 12:03:27 --> Language Class Initialized
INFO - 2020-10-14 12:03:27 --> Config Class Initialized
INFO - 2020-10-14 12:03:27 --> Config Class Initialized
INFO - 2020-10-14 12:03:27 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:03:27 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:03:27 --> Utf8 Class Initialized
INFO - 2020-10-14 12:03:27 --> URI Class Initialized
INFO - 2020-10-14 12:03:27 --> Router Class Initialized
INFO - 2020-10-14 12:03:27 --> Loader Class Initialized
INFO - 2020-10-14 12:03:27 --> Helper loaded: url_helper
INFO - 2020-10-14 12:03:27 --> Helper loaded: file_helper
INFO - 2020-10-14 12:03:27 --> Helper loaded: string_helper
INFO - 2020-10-14 12:03:27 --> Output Class Initialized
INFO - 2020-10-14 12:03:27 --> Security Class Initialized
DEBUG - 2020-10-14 12:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:03:27 --> Database Driver Class Initialized
INFO - 2020-10-14 12:03:27 --> CSRF cookie sent
INFO - 2020-10-14 12:03:27 --> Input Class Initialized
INFO - 2020-10-14 12:03:27 --> Language Class Initialized
INFO - 2020-10-14 12:03:27 --> Language Class Initialized
INFO - 2020-10-14 12:03:27 --> Config Class Initialized
INFO - 2020-10-14 12:03:27 --> Email Class Initialized
INFO - 2020-10-14 12:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:03:27 --> Controller Class Initialized
DEBUG - 2020-10-14 12:03:27 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:03:27 --> Model "Common_model" initialized
INFO - 2020-10-14 12:03:27 --> Loader Class Initialized
INFO - 2020-10-14 12:03:27 --> Helper loaded: url_helper
INFO - 2020-10-14 12:03:27 --> Config Class Initialized
INFO - 2020-10-14 12:03:27 --> Hooks Class Initialized
INFO - 2020-10-14 12:03:27 --> Helper loaded: file_helper
INFO - 2020-10-14 12:03:27 --> Helper loaded: string_helper
DEBUG - 2020-10-14 12:03:27 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:03:27 --> Utf8 Class Initialized
INFO - 2020-10-14 12:03:27 --> URI Class Initialized
INFO - 2020-10-14 12:03:27 --> Router Class Initialized
INFO - 2020-10-14 12:03:27 --> Output Class Initialized
INFO - 2020-10-14 12:03:27 --> Database Driver Class Initialized
INFO - 2020-10-14 12:03:27 --> Security Class Initialized
INFO - 2020-10-14 12:03:27 --> Final output sent to browser
DEBUG - 2020-10-14 12:03:27 --> Total execution time: 0.0499
DEBUG - 2020-10-14 12:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:03:27 --> CSRF cookie sent
INFO - 2020-10-14 12:03:27 --> CSRF token verified
INFO - 2020-10-14 12:03:27 --> Input Class Initialized
INFO - 2020-10-14 12:03:27 --> Language Class Initialized
INFO - 2020-10-14 12:03:27 --> Language Class Initialized
INFO - 2020-10-14 12:03:27 --> Config Class Initialized
INFO - 2020-10-14 12:03:27 --> Loader Class Initialized
INFO - 2020-10-14 12:03:27 --> Email Class Initialized
INFO - 2020-10-14 12:03:27 --> Helper loaded: url_helper
INFO - 2020-10-14 12:03:27 --> Helper loaded: file_helper
INFO - 2020-10-14 12:03:27 --> Helper loaded: string_helper
INFO - 2020-10-14 12:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:03:27 --> Controller Class Initialized
DEBUG - 2020-10-14 12:03:27 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:03:27 --> Model "Common_model" initialized
INFO - 2020-10-14 12:03:27 --> Final output sent to browser
DEBUG - 2020-10-14 12:03:27 --> Total execution time: 0.0793
INFO - 2020-10-14 12:03:27 --> Database Driver Class Initialized
INFO - 2020-10-14 12:03:27 --> Email Class Initialized
INFO - 2020-10-14 12:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:03:27 --> Controller Class Initialized
DEBUG - 2020-10-14 12:03:27 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:03:27 --> Model "Common_model" initialized
INFO - 2020-10-14 12:03:27 --> Final output sent to browser
DEBUG - 2020-10-14 12:03:27 --> Total execution time: 0.0711
INFO - 2020-10-14 12:03:36 --> Config Class Initialized
INFO - 2020-10-14 12:03:36 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:03:36 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:03:36 --> Utf8 Class Initialized
INFO - 2020-10-14 12:03:36 --> URI Class Initialized
INFO - 2020-10-14 12:03:36 --> Router Class Initialized
INFO - 2020-10-14 12:03:36 --> Output Class Initialized
INFO - 2020-10-14 12:03:36 --> Security Class Initialized
DEBUG - 2020-10-14 12:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:03:36 --> CSRF cookie sent
INFO - 2020-10-14 12:03:36 --> Input Class Initialized
INFO - 2020-10-14 12:03:36 --> Language Class Initialized
ERROR - 2020-10-14 12:03:36 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:03:39 --> Config Class Initialized
INFO - 2020-10-14 12:03:39 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:03:39 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:03:39 --> Utf8 Class Initialized
INFO - 2020-10-14 12:03:39 --> URI Class Initialized
INFO - 2020-10-14 12:03:39 --> Router Class Initialized
INFO - 2020-10-14 12:03:39 --> Output Class Initialized
INFO - 2020-10-14 12:03:39 --> Security Class Initialized
DEBUG - 2020-10-14 12:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:03:39 --> CSRF cookie sent
INFO - 2020-10-14 12:03:39 --> CSRF token verified
INFO - 2020-10-14 12:03:39 --> Input Class Initialized
INFO - 2020-10-14 12:03:39 --> Language Class Initialized
INFO - 2020-10-14 12:03:39 --> Language Class Initialized
INFO - 2020-10-14 12:03:39 --> Config Class Initialized
INFO - 2020-10-14 12:03:39 --> Loader Class Initialized
INFO - 2020-10-14 12:03:39 --> Helper loaded: url_helper
INFO - 2020-10-14 12:03:39 --> Helper loaded: file_helper
INFO - 2020-10-14 12:03:39 --> Helper loaded: string_helper
INFO - 2020-10-14 12:03:39 --> Database Driver Class Initialized
INFO - 2020-10-14 12:03:39 --> Email Class Initialized
INFO - 2020-10-14 12:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:03:39 --> Controller Class Initialized
DEBUG - 2020-10-14 12:03:39 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:03:39 --> Model "Common_model" initialized
ERROR - 2020-10-14 12:03:39 --> Severity: Notice --> Undefined index: SPT_DOCROOT /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 820
ERROR - 2020-10-14 12:03:39 --> Severity: Warning --> imagepng(/color-innovator/uploads/user_custom_images/10/20201014102102184-merge.png): failed to open stream: No such file or directory /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 885
INFO - 2020-10-14 12:04:25 --> Config Class Initialized
INFO - 2020-10-14 12:04:25 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:04:25 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:04:25 --> Utf8 Class Initialized
INFO - 2020-10-14 12:04:25 --> URI Class Initialized
INFO - 2020-10-14 12:04:25 --> Router Class Initialized
INFO - 2020-10-14 12:04:25 --> Output Class Initialized
INFO - 2020-10-14 12:04:25 --> Security Class Initialized
DEBUG - 2020-10-14 12:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:04:25 --> CSRF cookie sent
INFO - 2020-10-14 12:04:25 --> Input Class Initialized
INFO - 2020-10-14 12:04:25 --> Language Class Initialized
INFO - 2020-10-14 12:04:25 --> Language Class Initialized
INFO - 2020-10-14 12:04:25 --> Config Class Initialized
INFO - 2020-10-14 12:04:25 --> Loader Class Initialized
INFO - 2020-10-14 12:04:25 --> Helper loaded: url_helper
INFO - 2020-10-14 12:04:25 --> Helper loaded: file_helper
INFO - 2020-10-14 12:04:25 --> Helper loaded: string_helper
INFO - 2020-10-14 12:04:25 --> Database Driver Class Initialized
INFO - 2020-10-14 12:04:25 --> Email Class Initialized
INFO - 2020-10-14 12:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:04:25 --> Controller Class Initialized
DEBUG - 2020-10-14 12:04:25 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:04:25 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:04:25 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:04:25 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:04:25 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/mobile_view_links.php
DEBUG - 2020-10-14 12:04:25 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:04:25 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/place.php
DEBUG - 2020-10-14 12:04:25 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:04:25 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:04:25 --> Final output sent to browser
DEBUG - 2020-10-14 12:04:25 --> Total execution time: 0.0820
INFO - 2020-10-14 12:04:28 --> Config Class Initialized
INFO - 2020-10-14 12:04:28 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:04:28 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:04:28 --> Utf8 Class Initialized
INFO - 2020-10-14 12:04:28 --> URI Class Initialized
INFO - 2020-10-14 12:04:28 --> Router Class Initialized
INFO - 2020-10-14 12:04:28 --> Output Class Initialized
INFO - 2020-10-14 12:04:28 --> Security Class Initialized
DEBUG - 2020-10-14 12:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:04:28 --> CSRF cookie sent
INFO - 2020-10-14 12:04:28 --> CSRF token verified
INFO - 2020-10-14 12:04:28 --> Input Class Initialized
INFO - 2020-10-14 12:04:28 --> Language Class Initialized
INFO - 2020-10-14 12:04:28 --> Config Class Initialized
INFO - 2020-10-14 12:04:28 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:04:28 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:04:28 --> Utf8 Class Initialized
INFO - 2020-10-14 12:04:28 --> URI Class Initialized
INFO - 2020-10-14 12:04:28 --> Router Class Initialized
INFO - 2020-10-14 12:04:28 --> Output Class Initialized
INFO - 2020-10-14 12:04:28 --> Security Class Initialized
DEBUG - 2020-10-14 12:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:04:28 --> CSRF cookie sent
INFO - 2020-10-14 12:04:28 --> Input Class Initialized
INFO - 2020-10-14 12:04:28 --> Language Class Initialized
INFO - 2020-10-14 12:04:28 --> Language Class Initialized
INFO - 2020-10-14 12:04:28 --> Config Class Initialized
INFO - 2020-10-14 12:04:28 --> Loader Class Initialized
INFO - 2020-10-14 12:04:28 --> Helper loaded: url_helper
INFO - 2020-10-14 12:04:28 --> Helper loaded: file_helper
INFO - 2020-10-14 12:04:28 --> Helper loaded: string_helper
INFO - 2020-10-14 12:04:28 --> Database Driver Class Initialized
INFO - 2020-10-14 12:04:28 --> Language Class Initialized
INFO - 2020-10-14 12:04:28 --> Config Class Initialized
INFO - 2020-10-14 12:04:28 --> Loader Class Initialized
INFO - 2020-10-14 12:04:28 --> Helper loaded: url_helper
INFO - 2020-10-14 12:04:28 --> Helper loaded: file_helper
INFO - 2020-10-14 12:04:28 --> Helper loaded: string_helper
INFO - 2020-10-14 12:04:28 --> Email Class Initialized
INFO - 2020-10-14 12:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:04:28 --> Controller Class Initialized
DEBUG - 2020-10-14 12:04:28 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:04:28 --> Model "Common_model" initialized
INFO - 2020-10-14 12:04:28 --> Database Driver Class Initialized
INFO - 2020-10-14 12:04:28 --> Final output sent to browser
DEBUG - 2020-10-14 12:04:28 --> Total execution time: 0.0290
INFO - 2020-10-14 12:04:28 --> Config Class Initialized
INFO - 2020-10-14 12:04:28 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:04:28 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:04:28 --> Utf8 Class Initialized
INFO - 2020-10-14 12:04:28 --> URI Class Initialized
INFO - 2020-10-14 12:04:28 --> Router Class Initialized
INFO - 2020-10-14 12:04:28 --> Email Class Initialized
INFO - 2020-10-14 12:04:28 --> Output Class Initialized
INFO - 2020-10-14 12:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:04:28 --> Controller Class Initialized
INFO - 2020-10-14 12:04:28 --> Security Class Initialized
DEBUG - 2020-10-14 12:04:28 --> Home MX_Controller Initialized
DEBUG - 2020-10-14 12:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:04:28 --> CSRF cookie sent
INFO - 2020-10-14 12:04:28 --> CSRF token verified
INFO - 2020-10-14 12:04:28 --> Model "Common_model" initialized
INFO - 2020-10-14 12:04:28 --> Input Class Initialized
INFO - 2020-10-14 12:04:28 --> Language Class Initialized
INFO - 2020-10-14 12:04:28 --> Final output sent to browser
DEBUG - 2020-10-14 12:04:28 --> Total execution time: 0.0897
INFO - 2020-10-14 12:04:28 --> Language Class Initialized
INFO - 2020-10-14 12:04:28 --> Config Class Initialized
INFO - 2020-10-14 12:04:28 --> Loader Class Initialized
INFO - 2020-10-14 12:04:28 --> Helper loaded: url_helper
INFO - 2020-10-14 12:04:28 --> Helper loaded: file_helper
INFO - 2020-10-14 12:04:28 --> Helper loaded: string_helper
INFO - 2020-10-14 12:04:28 --> Database Driver Class Initialized
INFO - 2020-10-14 12:04:28 --> Email Class Initialized
INFO - 2020-10-14 12:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:04:28 --> Controller Class Initialized
DEBUG - 2020-10-14 12:04:28 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:04:28 --> Model "Common_model" initialized
INFO - 2020-10-14 12:04:28 --> Final output sent to browser
DEBUG - 2020-10-14 12:04:28 --> Total execution time: 0.0603
INFO - 2020-10-14 12:05:18 --> Config Class Initialized
INFO - 2020-10-14 12:05:18 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:05:18 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:05:18 --> Utf8 Class Initialized
INFO - 2020-10-14 12:05:18 --> URI Class Initialized
INFO - 2020-10-14 12:05:18 --> Router Class Initialized
INFO - 2020-10-14 12:05:18 --> Output Class Initialized
INFO - 2020-10-14 12:05:18 --> Security Class Initialized
DEBUG - 2020-10-14 12:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:05:18 --> CSRF cookie sent
INFO - 2020-10-14 12:05:18 --> Input Class Initialized
INFO - 2020-10-14 12:05:18 --> Language Class Initialized
INFO - 2020-10-14 12:05:18 --> Language Class Initialized
INFO - 2020-10-14 12:05:18 --> Config Class Initialized
INFO - 2020-10-14 12:05:18 --> Loader Class Initialized
INFO - 2020-10-14 12:05:18 --> Helper loaded: url_helper
INFO - 2020-10-14 12:05:18 --> Helper loaded: file_helper
INFO - 2020-10-14 12:05:18 --> Helper loaded: string_helper
INFO - 2020-10-14 12:05:18 --> Database Driver Class Initialized
INFO - 2020-10-14 12:05:18 --> Email Class Initialized
INFO - 2020-10-14 12:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:05:18 --> Controller Class Initialized
DEBUG - 2020-10-14 12:05:18 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:05:18 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:05:18 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:05:18 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:05:18 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:05:18 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/make.php
DEBUG - 2020-10-14 12:05:18 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:05:18 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:05:18 --> Final output sent to browser
DEBUG - 2020-10-14 12:05:18 --> Total execution time: 0.0394
INFO - 2020-10-14 12:05:20 --> Config Class Initialized
INFO - 2020-10-14 12:05:20 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:05:20 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:05:20 --> Utf8 Class Initialized
INFO - 2020-10-14 12:05:20 --> URI Class Initialized
INFO - 2020-10-14 12:05:20 --> Router Class Initialized
INFO - 2020-10-14 12:05:20 --> Output Class Initialized
INFO - 2020-10-14 12:05:20 --> Security Class Initialized
DEBUG - 2020-10-14 12:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:05:20 --> CSRF cookie sent
INFO - 2020-10-14 12:05:20 --> Input Class Initialized
INFO - 2020-10-14 12:05:20 --> Language Class Initialized
ERROR - 2020-10-14 12:05:20 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:05:24 --> Config Class Initialized
INFO - 2020-10-14 12:05:24 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:05:24 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:05:24 --> Utf8 Class Initialized
INFO - 2020-10-14 12:05:24 --> URI Class Initialized
INFO - 2020-10-14 12:05:24 --> Router Class Initialized
INFO - 2020-10-14 12:05:24 --> Output Class Initialized
INFO - 2020-10-14 12:05:24 --> Security Class Initialized
DEBUG - 2020-10-14 12:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:05:24 --> CSRF cookie sent
INFO - 2020-10-14 12:05:24 --> CSRF token verified
INFO - 2020-10-14 12:05:24 --> Input Class Initialized
INFO - 2020-10-14 12:05:24 --> Language Class Initialized
INFO - 2020-10-14 12:05:24 --> Language Class Initialized
INFO - 2020-10-14 12:05:24 --> Config Class Initialized
INFO - 2020-10-14 12:05:24 --> Loader Class Initialized
INFO - 2020-10-14 12:05:24 --> Helper loaded: url_helper
INFO - 2020-10-14 12:05:24 --> Helper loaded: file_helper
INFO - 2020-10-14 12:05:24 --> Helper loaded: string_helper
INFO - 2020-10-14 12:05:24 --> Database Driver Class Initialized
INFO - 2020-10-14 12:05:24 --> Email Class Initialized
INFO - 2020-10-14 12:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:05:24 --> Controller Class Initialized
DEBUG - 2020-10-14 12:05:24 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:05:24 --> Model "Common_model" initialized
INFO - 2020-10-14 12:05:24 --> Final output sent to browser
DEBUG - 2020-10-14 12:05:24 --> Total execution time: 0.0508
INFO - 2020-10-14 12:05:24 --> Config Class Initialized
INFO - 2020-10-14 12:05:24 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:05:24 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:05:24 --> Utf8 Class Initialized
INFO - 2020-10-14 12:05:24 --> URI Class Initialized
INFO - 2020-10-14 12:05:24 --> Router Class Initialized
INFO - 2020-10-14 12:05:24 --> Output Class Initialized
INFO - 2020-10-14 12:05:24 --> Security Class Initialized
DEBUG - 2020-10-14 12:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:05:24 --> CSRF cookie sent
INFO - 2020-10-14 12:05:24 --> Input Class Initialized
INFO - 2020-10-14 12:05:24 --> Language Class Initialized
INFO - 2020-10-14 12:05:24 --> Language Class Initialized
INFO - 2020-10-14 12:05:24 --> Config Class Initialized
INFO - 2020-10-14 12:05:24 --> Loader Class Initialized
INFO - 2020-10-14 12:05:24 --> Helper loaded: url_helper
INFO - 2020-10-14 12:05:24 --> Helper loaded: file_helper
INFO - 2020-10-14 12:05:24 --> Helper loaded: string_helper
INFO - 2020-10-14 12:05:24 --> Database Driver Class Initialized
INFO - 2020-10-14 12:05:24 --> Config Class Initialized
INFO - 2020-10-14 12:05:24 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:05:24 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:05:24 --> Utf8 Class Initialized
INFO - 2020-10-14 12:05:24 --> URI Class Initialized
INFO - 2020-10-14 12:05:24 --> Email Class Initialized
INFO - 2020-10-14 12:05:24 --> Router Class Initialized
INFO - 2020-10-14 12:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:05:24 --> Controller Class Initialized
DEBUG - 2020-10-14 12:05:24 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:05:24 --> Model "Common_model" initialized
INFO - 2020-10-14 12:05:24 --> Output Class Initialized
INFO - 2020-10-14 12:05:24 --> Security Class Initialized
DEBUG - 2020-10-14 12:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:05:24 --> CSRF cookie sent
INFO - 2020-10-14 12:05:24 --> CSRF token verified
INFO - 2020-10-14 12:05:24 --> Input Class Initialized
INFO - 2020-10-14 12:05:24 --> Language Class Initialized
INFO - 2020-10-14 12:05:24 --> Final output sent to browser
DEBUG - 2020-10-14 12:05:24 --> Total execution time: 0.0416
INFO - 2020-10-14 12:05:24 --> Language Class Initialized
INFO - 2020-10-14 12:05:24 --> Config Class Initialized
INFO - 2020-10-14 12:05:24 --> Loader Class Initialized
INFO - 2020-10-14 12:05:24 --> Helper loaded: url_helper
INFO - 2020-10-14 12:05:24 --> Helper loaded: file_helper
INFO - 2020-10-14 12:05:24 --> Helper loaded: string_helper
INFO - 2020-10-14 12:05:24 --> Database Driver Class Initialized
INFO - 2020-10-14 12:05:24 --> Email Class Initialized
INFO - 2020-10-14 12:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:05:24 --> Controller Class Initialized
DEBUG - 2020-10-14 12:05:24 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:05:24 --> Model "Common_model" initialized
INFO - 2020-10-14 12:05:24 --> Final output sent to browser
DEBUG - 2020-10-14 12:05:24 --> Total execution time: 0.0346
INFO - 2020-10-14 12:05:31 --> Config Class Initialized
INFO - 2020-10-14 12:05:31 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:05:31 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:05:31 --> Utf8 Class Initialized
INFO - 2020-10-14 12:05:31 --> URI Class Initialized
INFO - 2020-10-14 12:05:31 --> Router Class Initialized
INFO - 2020-10-14 12:05:31 --> Output Class Initialized
INFO - 2020-10-14 12:05:31 --> Security Class Initialized
DEBUG - 2020-10-14 12:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:05:31 --> CSRF cookie sent
INFO - 2020-10-14 12:05:31 --> Input Class Initialized
INFO - 2020-10-14 12:05:31 --> Language Class Initialized
ERROR - 2020-10-14 12:05:31 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:05:35 --> Config Class Initialized
INFO - 2020-10-14 12:05:35 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:05:35 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:05:35 --> Utf8 Class Initialized
INFO - 2020-10-14 12:05:35 --> URI Class Initialized
INFO - 2020-10-14 12:05:35 --> Router Class Initialized
INFO - 2020-10-14 12:05:35 --> Output Class Initialized
INFO - 2020-10-14 12:05:35 --> Security Class Initialized
DEBUG - 2020-10-14 12:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:05:35 --> CSRF cookie sent
INFO - 2020-10-14 12:05:35 --> CSRF token verified
INFO - 2020-10-14 12:05:35 --> Input Class Initialized
INFO - 2020-10-14 12:05:35 --> Language Class Initialized
INFO - 2020-10-14 12:05:35 --> Language Class Initialized
INFO - 2020-10-14 12:05:35 --> Config Class Initialized
INFO - 2020-10-14 12:05:35 --> Loader Class Initialized
INFO - 2020-10-14 12:05:35 --> Helper loaded: url_helper
INFO - 2020-10-14 12:05:35 --> Helper loaded: file_helper
INFO - 2020-10-14 12:05:35 --> Helper loaded: string_helper
INFO - 2020-10-14 12:05:35 --> Database Driver Class Initialized
INFO - 2020-10-14 12:05:35 --> Email Class Initialized
INFO - 2020-10-14 12:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:05:35 --> Controller Class Initialized
DEBUG - 2020-10-14 12:05:35 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:05:35 --> Model "Common_model" initialized
INFO - 2020-10-14 12:05:35 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:05:35 --> Final output sent to browser
DEBUG - 2020-10-14 12:05:35 --> Total execution time: 0.1891
INFO - 2020-10-14 12:06:03 --> Config Class Initialized
INFO - 2020-10-14 12:06:03 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:06:03 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:06:03 --> Utf8 Class Initialized
INFO - 2020-10-14 12:06:03 --> URI Class Initialized
INFO - 2020-10-14 12:06:03 --> Router Class Initialized
INFO - 2020-10-14 12:06:03 --> Output Class Initialized
INFO - 2020-10-14 12:06:03 --> Security Class Initialized
DEBUG - 2020-10-14 12:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:06:03 --> CSRF cookie sent
INFO - 2020-10-14 12:06:03 --> Input Class Initialized
INFO - 2020-10-14 12:06:03 --> Language Class Initialized
ERROR - 2020-10-14 12:06:03 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:06:15 --> Config Class Initialized
INFO - 2020-10-14 12:06:15 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:06:15 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:06:15 --> Utf8 Class Initialized
INFO - 2020-10-14 12:06:15 --> URI Class Initialized
INFO - 2020-10-14 12:06:15 --> Router Class Initialized
INFO - 2020-10-14 12:06:15 --> Output Class Initialized
INFO - 2020-10-14 12:06:15 --> Security Class Initialized
DEBUG - 2020-10-14 12:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:06:15 --> CSRF cookie sent
INFO - 2020-10-14 12:06:15 --> Input Class Initialized
INFO - 2020-10-14 12:06:15 --> Language Class Initialized
ERROR - 2020-10-14 12:06:15 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:09:08 --> Config Class Initialized
INFO - 2020-10-14 12:09:08 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:09:08 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:09:08 --> Utf8 Class Initialized
INFO - 2020-10-14 12:09:08 --> URI Class Initialized
INFO - 2020-10-14 12:09:08 --> Router Class Initialized
INFO - 2020-10-14 12:09:08 --> Output Class Initialized
INFO - 2020-10-14 12:09:08 --> Security Class Initialized
DEBUG - 2020-10-14 12:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:09:08 --> CSRF cookie sent
INFO - 2020-10-14 12:09:08 --> Input Class Initialized
INFO - 2020-10-14 12:09:08 --> Language Class Initialized
ERROR - 2020-10-14 12:09:08 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:09:09 --> Config Class Initialized
INFO - 2020-10-14 12:09:09 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:09:09 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:09:09 --> Utf8 Class Initialized
INFO - 2020-10-14 12:09:09 --> URI Class Initialized
INFO - 2020-10-14 12:09:09 --> Router Class Initialized
INFO - 2020-10-14 12:09:09 --> Output Class Initialized
INFO - 2020-10-14 12:09:09 --> Security Class Initialized
DEBUG - 2020-10-14 12:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:09:09 --> CSRF cookie sent
INFO - 2020-10-14 12:09:09 --> CSRF token verified
INFO - 2020-10-14 12:09:09 --> Input Class Initialized
INFO - 2020-10-14 12:09:09 --> Language Class Initialized
INFO - 2020-10-14 12:09:09 --> Language Class Initialized
INFO - 2020-10-14 12:09:09 --> Config Class Initialized
INFO - 2020-10-14 12:09:09 --> Loader Class Initialized
INFO - 2020-10-14 12:09:09 --> Helper loaded: url_helper
INFO - 2020-10-14 12:09:09 --> Helper loaded: file_helper
INFO - 2020-10-14 12:09:09 --> Helper loaded: string_helper
INFO - 2020-10-14 12:09:09 --> Database Driver Class Initialized
INFO - 2020-10-14 12:09:09 --> Email Class Initialized
INFO - 2020-10-14 12:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:09:09 --> Controller Class Initialized
DEBUG - 2020-10-14 12:09:09 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:09:09 --> Model "Common_model" initialized
INFO - 2020-10-14 12:10:15 --> Config Class Initialized
INFO - 2020-10-14 12:10:15 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:10:15 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:10:15 --> Utf8 Class Initialized
INFO - 2020-10-14 12:10:15 --> URI Class Initialized
INFO - 2020-10-14 12:10:15 --> Router Class Initialized
INFO - 2020-10-14 12:10:15 --> Output Class Initialized
INFO - 2020-10-14 12:10:15 --> Security Class Initialized
DEBUG - 2020-10-14 12:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:10:15 --> CSRF cookie sent
INFO - 2020-10-14 12:10:15 --> Input Class Initialized
INFO - 2020-10-14 12:10:15 --> Language Class Initialized
ERROR - 2020-10-14 12:10:15 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:10:17 --> Config Class Initialized
INFO - 2020-10-14 12:10:17 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:10:17 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:10:17 --> Utf8 Class Initialized
INFO - 2020-10-14 12:10:17 --> URI Class Initialized
INFO - 2020-10-14 12:10:17 --> Router Class Initialized
INFO - 2020-10-14 12:10:17 --> Output Class Initialized
INFO - 2020-10-14 12:10:17 --> Security Class Initialized
DEBUG - 2020-10-14 12:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:10:17 --> CSRF cookie sent
INFO - 2020-10-14 12:10:17 --> CSRF token verified
INFO - 2020-10-14 12:10:17 --> Input Class Initialized
INFO - 2020-10-14 12:10:17 --> Language Class Initialized
INFO - 2020-10-14 12:10:17 --> Language Class Initialized
INFO - 2020-10-14 12:10:17 --> Config Class Initialized
INFO - 2020-10-14 12:10:17 --> Loader Class Initialized
INFO - 2020-10-14 12:10:17 --> Helper loaded: url_helper
INFO - 2020-10-14 12:10:17 --> Helper loaded: file_helper
INFO - 2020-10-14 12:10:17 --> Helper loaded: string_helper
INFO - 2020-10-14 12:10:17 --> Database Driver Class Initialized
INFO - 2020-10-14 12:10:17 --> Email Class Initialized
INFO - 2020-10-14 12:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:10:17 --> Controller Class Initialized
DEBUG - 2020-10-14 12:10:17 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:10:17 --> Model "Common_model" initialized
INFO - 2020-10-14 12:13:06 --> Config Class Initialized
INFO - 2020-10-14 12:13:06 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:13:06 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:13:06 --> Utf8 Class Initialized
INFO - 2020-10-14 12:13:06 --> URI Class Initialized
INFO - 2020-10-14 12:13:06 --> Router Class Initialized
INFO - 2020-10-14 12:13:06 --> Output Class Initialized
INFO - 2020-10-14 12:13:06 --> Security Class Initialized
DEBUG - 2020-10-14 12:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:13:06 --> CSRF cookie sent
INFO - 2020-10-14 12:13:06 --> Input Class Initialized
INFO - 2020-10-14 12:13:06 --> Language Class Initialized
ERROR - 2020-10-14 12:13:06 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:13:08 --> Config Class Initialized
INFO - 2020-10-14 12:13:08 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:13:08 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:13:08 --> Utf8 Class Initialized
INFO - 2020-10-14 12:13:08 --> URI Class Initialized
INFO - 2020-10-14 12:13:08 --> Router Class Initialized
INFO - 2020-10-14 12:13:08 --> Output Class Initialized
INFO - 2020-10-14 12:13:08 --> Security Class Initialized
DEBUG - 2020-10-14 12:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:13:08 --> CSRF cookie sent
INFO - 2020-10-14 12:13:08 --> CSRF token verified
INFO - 2020-10-14 12:13:08 --> Input Class Initialized
INFO - 2020-10-14 12:13:08 --> Language Class Initialized
INFO - 2020-10-14 12:13:08 --> Language Class Initialized
INFO - 2020-10-14 12:13:08 --> Config Class Initialized
INFO - 2020-10-14 12:13:08 --> Loader Class Initialized
INFO - 2020-10-14 12:13:08 --> Helper loaded: url_helper
INFO - 2020-10-14 12:13:08 --> Helper loaded: file_helper
INFO - 2020-10-14 12:13:08 --> Helper loaded: string_helper
INFO - 2020-10-14 12:13:08 --> Database Driver Class Initialized
INFO - 2020-10-14 12:13:08 --> Email Class Initialized
INFO - 2020-10-14 12:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:13:08 --> Controller Class Initialized
DEBUG - 2020-10-14 12:13:08 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:13:08 --> Model "Common_model" initialized
ERROR - 2020-10-14 12:13:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php:837) /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 838
INFO - 2020-10-14 12:17:45 --> Config Class Initialized
INFO - 2020-10-14 12:17:45 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:17:45 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:17:45 --> Utf8 Class Initialized
INFO - 2020-10-14 12:17:45 --> URI Class Initialized
INFO - 2020-10-14 12:17:45 --> Router Class Initialized
INFO - 2020-10-14 12:17:45 --> Output Class Initialized
INFO - 2020-10-14 12:17:45 --> Security Class Initialized
DEBUG - 2020-10-14 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:17:45 --> CSRF cookie sent
INFO - 2020-10-14 12:17:45 --> Input Class Initialized
INFO - 2020-10-14 12:17:45 --> Language Class Initialized
INFO - 2020-10-14 12:17:45 --> Language Class Initialized
INFO - 2020-10-14 12:17:45 --> Config Class Initialized
INFO - 2020-10-14 12:17:45 --> Loader Class Initialized
INFO - 2020-10-14 12:17:45 --> Helper loaded: url_helper
INFO - 2020-10-14 12:17:45 --> Helper loaded: file_helper
INFO - 2020-10-14 12:17:45 --> Helper loaded: string_helper
INFO - 2020-10-14 12:17:45 --> Database Driver Class Initialized
INFO - 2020-10-14 12:17:45 --> Email Class Initialized
INFO - 2020-10-14 12:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:17:45 --> Controller Class Initialized
DEBUG - 2020-10-14 12:17:45 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:17:45 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:17:45 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:17:45 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:17:45 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:17:45 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/make.php
DEBUG - 2020-10-14 12:17:45 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:17:45 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:17:45 --> Final output sent to browser
DEBUG - 2020-10-14 12:17:45 --> Total execution time: 0.0446
INFO - 2020-10-14 12:17:47 --> Config Class Initialized
INFO - 2020-10-14 12:17:47 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:17:47 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:17:47 --> Utf8 Class Initialized
INFO - 2020-10-14 12:17:47 --> URI Class Initialized
INFO - 2020-10-14 12:17:47 --> Router Class Initialized
INFO - 2020-10-14 12:17:47 --> Output Class Initialized
INFO - 2020-10-14 12:17:47 --> Security Class Initialized
DEBUG - 2020-10-14 12:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:17:47 --> CSRF cookie sent
INFO - 2020-10-14 12:17:47 --> Input Class Initialized
INFO - 2020-10-14 12:17:47 --> Language Class Initialized
ERROR - 2020-10-14 12:17:47 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:17:48 --> Config Class Initialized
INFO - 2020-10-14 12:17:48 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:17:48 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:17:48 --> Utf8 Class Initialized
INFO - 2020-10-14 12:17:48 --> URI Class Initialized
INFO - 2020-10-14 12:17:48 --> Router Class Initialized
INFO - 2020-10-14 12:17:48 --> Output Class Initialized
INFO - 2020-10-14 12:17:48 --> Security Class Initialized
DEBUG - 2020-10-14 12:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:17:48 --> CSRF cookie sent
INFO - 2020-10-14 12:17:48 --> Input Class Initialized
INFO - 2020-10-14 12:17:48 --> Language Class Initialized
INFO - 2020-10-14 12:17:48 --> Language Class Initialized
INFO - 2020-10-14 12:17:48 --> Config Class Initialized
INFO - 2020-10-14 12:17:48 --> Loader Class Initialized
INFO - 2020-10-14 12:17:48 --> Helper loaded: url_helper
INFO - 2020-10-14 12:17:48 --> Helper loaded: file_helper
INFO - 2020-10-14 12:17:48 --> Helper loaded: string_helper
INFO - 2020-10-14 12:17:48 --> Database Driver Class Initialized
INFO - 2020-10-14 12:17:48 --> Email Class Initialized
INFO - 2020-10-14 12:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:17:48 --> Controller Class Initialized
DEBUG - 2020-10-14 12:17:48 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:17:48 --> Model "Common_model" initialized
INFO - 2020-10-14 12:17:48 --> Config Class Initialized
INFO - 2020-10-14 12:17:48 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:17:48 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:17:48 --> Utf8 Class Initialized
INFO - 2020-10-14 12:17:48 --> URI Class Initialized
INFO - 2020-10-14 12:17:48 --> Router Class Initialized
INFO - 2020-10-14 12:17:48 --> Output Class Initialized
INFO - 2020-10-14 12:17:48 --> Security Class Initialized
DEBUG - 2020-10-14 12:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:17:48 --> CSRF cookie sent
INFO - 2020-10-14 12:17:48 --> Final output sent to browser
DEBUG - 2020-10-14 12:17:48 --> Total execution time: 0.0378
INFO - 2020-10-14 12:17:48 --> CSRF token verified
INFO - 2020-10-14 12:17:48 --> Input Class Initialized
INFO - 2020-10-14 12:17:48 --> Language Class Initialized
INFO - 2020-10-14 12:17:48 --> Config Class Initialized
INFO - 2020-10-14 12:17:48 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:17:48 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:17:48 --> Utf8 Class Initialized
INFO - 2020-10-14 12:17:48 --> URI Class Initialized
INFO - 2020-10-14 12:17:48 --> Language Class Initialized
INFO - 2020-10-14 12:17:48 --> Config Class Initialized
INFO - 2020-10-14 12:17:48 --> Router Class Initialized
INFO - 2020-10-14 12:17:48 --> Loader Class Initialized
INFO - 2020-10-14 12:17:48 --> Output Class Initialized
INFO - 2020-10-14 12:17:48 --> Helper loaded: url_helper
INFO - 2020-10-14 12:17:48 --> Helper loaded: file_helper
INFO - 2020-10-14 12:17:48 --> Security Class Initialized
INFO - 2020-10-14 12:17:48 --> Helper loaded: string_helper
DEBUG - 2020-10-14 12:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:17:48 --> CSRF cookie sent
INFO - 2020-10-14 12:17:48 --> CSRF token verified
INFO - 2020-10-14 12:17:48 --> Input Class Initialized
INFO - 2020-10-14 12:17:48 --> Language Class Initialized
INFO - 2020-10-14 12:17:48 --> Database Driver Class Initialized
INFO - 2020-10-14 12:17:48 --> Language Class Initialized
INFO - 2020-10-14 12:17:48 --> Config Class Initialized
INFO - 2020-10-14 12:17:48 --> Loader Class Initialized
INFO - 2020-10-14 12:17:48 --> Helper loaded: url_helper
INFO - 2020-10-14 12:17:48 --> Helper loaded: file_helper
INFO - 2020-10-14 12:17:48 --> Helper loaded: string_helper
INFO - 2020-10-14 12:17:48 --> Email Class Initialized
INFO - 2020-10-14 12:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:17:48 --> Controller Class Initialized
DEBUG - 2020-10-14 12:17:48 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:17:48 --> Model "Common_model" initialized
INFO - 2020-10-14 12:17:48 --> Database Driver Class Initialized
INFO - 2020-10-14 12:17:48 --> Final output sent to browser
DEBUG - 2020-10-14 12:17:48 --> Total execution time: 0.0748
INFO - 2020-10-14 12:17:48 --> Email Class Initialized
INFO - 2020-10-14 12:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:17:48 --> Controller Class Initialized
DEBUG - 2020-10-14 12:17:48 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:17:48 --> Model "Common_model" initialized
INFO - 2020-10-14 12:17:48 --> Final output sent to browser
DEBUG - 2020-10-14 12:17:48 --> Total execution time: 0.0678
INFO - 2020-10-14 12:18:02 --> Config Class Initialized
INFO - 2020-10-14 12:18:02 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:18:02 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:18:02 --> Utf8 Class Initialized
INFO - 2020-10-14 12:18:02 --> URI Class Initialized
INFO - 2020-10-14 12:18:02 --> Router Class Initialized
INFO - 2020-10-14 12:18:02 --> Output Class Initialized
INFO - 2020-10-14 12:18:02 --> Security Class Initialized
DEBUG - 2020-10-14 12:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:18:02 --> CSRF cookie sent
INFO - 2020-10-14 12:18:02 --> Input Class Initialized
INFO - 2020-10-14 12:18:02 --> Language Class Initialized
ERROR - 2020-10-14 12:18:02 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:18:08 --> Config Class Initialized
INFO - 2020-10-14 12:18:08 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:18:08 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:18:08 --> Utf8 Class Initialized
INFO - 2020-10-14 12:18:08 --> URI Class Initialized
INFO - 2020-10-14 12:18:08 --> Router Class Initialized
INFO - 2020-10-14 12:18:08 --> Output Class Initialized
INFO - 2020-10-14 12:18:08 --> Security Class Initialized
DEBUG - 2020-10-14 12:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:18:08 --> CSRF cookie sent
INFO - 2020-10-14 12:18:08 --> CSRF token verified
INFO - 2020-10-14 12:18:08 --> Input Class Initialized
INFO - 2020-10-14 12:18:08 --> Language Class Initialized
INFO - 2020-10-14 12:18:08 --> Language Class Initialized
INFO - 2020-10-14 12:18:08 --> Config Class Initialized
INFO - 2020-10-14 12:18:08 --> Loader Class Initialized
INFO - 2020-10-14 12:18:08 --> Helper loaded: url_helper
INFO - 2020-10-14 12:18:08 --> Helper loaded: file_helper
INFO - 2020-10-14 12:18:08 --> Helper loaded: string_helper
INFO - 2020-10-14 12:18:08 --> Database Driver Class Initialized
INFO - 2020-10-14 12:18:08 --> Email Class Initialized
INFO - 2020-10-14 12:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:18:08 --> Controller Class Initialized
DEBUG - 2020-10-14 12:18:08 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:18:08 --> Model "Common_model" initialized
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecreatefromjpeg(): gd-jpeg: JPEG library reports unrecoverable error: Not a JPEG file: starts with 0x89 0x50 /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 844
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecreatefromjpeg(): 'https://dinoflex.com/color-innovator/images/1_65_0_0_0_Fine-6_35_43_67_39_Fine-1602670235433.jpg' is not a valid JPEG file /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 844
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:08 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:18:09 --> Severity: Notice --> Undefined index: SPT_DOCROOT /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 822
ERROR - 2020-10-14 12:18:09 --> Severity: Warning --> imagepng(/color-innovator/uploads/user_custom_images/10/20201014102102184-merge.png): failed to open stream: No such file or directory /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 892
INFO - 2020-10-14 12:18:09 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:18:09 --> Final output sent to browser
DEBUG - 2020-10-14 12:18:09 --> Total execution time: 0.7964
INFO - 2020-10-14 12:18:42 --> Config Class Initialized
INFO - 2020-10-14 12:18:42 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:18:42 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:18:42 --> Utf8 Class Initialized
INFO - 2020-10-14 12:18:42 --> URI Class Initialized
INFO - 2020-10-14 12:18:42 --> Router Class Initialized
INFO - 2020-10-14 12:18:42 --> Output Class Initialized
INFO - 2020-10-14 12:18:42 --> Security Class Initialized
DEBUG - 2020-10-14 12:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:18:42 --> CSRF cookie sent
INFO - 2020-10-14 12:18:42 --> Input Class Initialized
INFO - 2020-10-14 12:18:42 --> Language Class Initialized
ERROR - 2020-10-14 12:18:42 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:18:43 --> Config Class Initialized
INFO - 2020-10-14 12:18:43 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:18:43 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:18:43 --> Utf8 Class Initialized
INFO - 2020-10-14 12:18:43 --> URI Class Initialized
INFO - 2020-10-14 12:18:43 --> Router Class Initialized
INFO - 2020-10-14 12:18:43 --> Output Class Initialized
INFO - 2020-10-14 12:18:43 --> Security Class Initialized
DEBUG - 2020-10-14 12:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:18:43 --> CSRF cookie sent
INFO - 2020-10-14 12:18:43 --> Input Class Initialized
INFO - 2020-10-14 12:18:43 --> Language Class Initialized
ERROR - 2020-10-14 12:18:43 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:20:13 --> Config Class Initialized
INFO - 2020-10-14 12:20:13 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:20:13 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:20:13 --> Utf8 Class Initialized
INFO - 2020-10-14 12:20:13 --> URI Class Initialized
INFO - 2020-10-14 12:20:13 --> Router Class Initialized
INFO - 2020-10-14 12:20:13 --> Output Class Initialized
INFO - 2020-10-14 12:20:13 --> Security Class Initialized
DEBUG - 2020-10-14 12:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:20:13 --> CSRF cookie sent
INFO - 2020-10-14 12:20:13 --> Input Class Initialized
INFO - 2020-10-14 12:20:13 --> Language Class Initialized
ERROR - 2020-10-14 12:20:13 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:20:15 --> Config Class Initialized
INFO - 2020-10-14 12:20:15 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:20:15 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:20:15 --> Utf8 Class Initialized
INFO - 2020-10-14 12:20:15 --> URI Class Initialized
INFO - 2020-10-14 12:20:15 --> Router Class Initialized
INFO - 2020-10-14 12:20:15 --> Output Class Initialized
INFO - 2020-10-14 12:20:15 --> Security Class Initialized
DEBUG - 2020-10-14 12:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:20:15 --> CSRF cookie sent
INFO - 2020-10-14 12:20:15 --> CSRF token verified
INFO - 2020-10-14 12:20:15 --> Input Class Initialized
INFO - 2020-10-14 12:20:15 --> Language Class Initialized
INFO - 2020-10-14 12:20:15 --> Language Class Initialized
INFO - 2020-10-14 12:20:15 --> Config Class Initialized
INFO - 2020-10-14 12:20:15 --> Loader Class Initialized
INFO - 2020-10-14 12:20:15 --> Helper loaded: url_helper
INFO - 2020-10-14 12:20:15 --> Helper loaded: file_helper
INFO - 2020-10-14 12:20:15 --> Helper loaded: string_helper
INFO - 2020-10-14 12:20:15 --> Database Driver Class Initialized
INFO - 2020-10-14 12:20:15 --> Email Class Initialized
INFO - 2020-10-14 12:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:20:15 --> Controller Class Initialized
DEBUG - 2020-10-14 12:20:15 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:20:15 --> Model "Common_model" initialized
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecreatefromjpeg(): gd-jpeg: JPEG library reports unrecoverable error: Not a JPEG file: starts with 0x89 0x50 /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 844
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecreatefromjpeg(): 'https://dinoflex.com/color-innovator/images/1_65_0_0_0_Fine-6_35_43_67_39_Fine-1602670235433.jpg' is not a valid JPEG file /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 844
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:20:15 --> Severity: Notice --> Undefined index: SPT_DOCROOT /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 822
ERROR - 2020-10-14 12:20:15 --> Severity: Warning --> imagepng(/color-innovator/uploads/user_custom_images/10/20201014102102184-merge.png): failed to open stream: No such file or directory /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 892
INFO - 2020-10-14 12:20:15 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:20:15 --> Final output sent to browser
DEBUG - 2020-10-14 12:20:15 --> Total execution time: 0.8244
INFO - 2020-10-14 12:21:34 --> Config Class Initialized
INFO - 2020-10-14 12:21:34 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:21:34 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:21:34 --> Utf8 Class Initialized
INFO - 2020-10-14 12:21:34 --> URI Class Initialized
INFO - 2020-10-14 12:21:34 --> Router Class Initialized
INFO - 2020-10-14 12:21:34 --> Output Class Initialized
INFO - 2020-10-14 12:21:34 --> Security Class Initialized
DEBUG - 2020-10-14 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:21:34 --> CSRF cookie sent
INFO - 2020-10-14 12:21:34 --> Input Class Initialized
INFO - 2020-10-14 12:21:34 --> Language Class Initialized
ERROR - 2020-10-14 12:21:34 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:21:35 --> Config Class Initialized
INFO - 2020-10-14 12:21:35 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:21:35 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:21:35 --> Utf8 Class Initialized
INFO - 2020-10-14 12:21:35 --> URI Class Initialized
INFO - 2020-10-14 12:21:35 --> Router Class Initialized
INFO - 2020-10-14 12:21:35 --> Output Class Initialized
INFO - 2020-10-14 12:21:35 --> Security Class Initialized
DEBUG - 2020-10-14 12:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:21:35 --> CSRF cookie sent
INFO - 2020-10-14 12:21:35 --> CSRF token verified
INFO - 2020-10-14 12:21:35 --> Input Class Initialized
INFO - 2020-10-14 12:21:35 --> Language Class Initialized
INFO - 2020-10-14 12:21:35 --> Language Class Initialized
INFO - 2020-10-14 12:21:35 --> Config Class Initialized
INFO - 2020-10-14 12:21:35 --> Loader Class Initialized
INFO - 2020-10-14 12:21:35 --> Helper loaded: url_helper
INFO - 2020-10-14 12:21:35 --> Helper loaded: file_helper
INFO - 2020-10-14 12:21:35 --> Helper loaded: string_helper
INFO - 2020-10-14 12:21:35 --> Database Driver Class Initialized
INFO - 2020-10-14 12:21:35 --> Email Class Initialized
INFO - 2020-10-14 12:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:21:35 --> Controller Class Initialized
DEBUG - 2020-10-14 12:21:35 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:21:35 --> Model "Common_model" initialized
ERROR - 2020-10-14 12:21:36 --> Severity: Notice --> Undefined index: SPT_DOCROOT /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 822
ERROR - 2020-10-14 12:21:36 --> Severity: Warning --> imagepng(/color-innovator/uploads/user_custom_images/10/20201014102102184-merge.png): failed to open stream: No such file or directory /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 892
INFO - 2020-10-14 12:21:36 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:21:36 --> Final output sent to browser
DEBUG - 2020-10-14 12:21:36 --> Total execution time: 0.2448
INFO - 2020-10-14 12:24:05 --> Config Class Initialized
INFO - 2020-10-14 12:24:05 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:24:05 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:24:05 --> Utf8 Class Initialized
INFO - 2020-10-14 12:24:05 --> URI Class Initialized
INFO - 2020-10-14 12:24:05 --> Router Class Initialized
INFO - 2020-10-14 12:24:05 --> Output Class Initialized
INFO - 2020-10-14 12:24:05 --> Security Class Initialized
DEBUG - 2020-10-14 12:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:24:05 --> CSRF cookie sent
INFO - 2020-10-14 12:24:05 --> Input Class Initialized
INFO - 2020-10-14 12:24:05 --> Language Class Initialized
ERROR - 2020-10-14 12:24:05 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:24:07 --> Config Class Initialized
INFO - 2020-10-14 12:24:07 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:24:07 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:24:07 --> Utf8 Class Initialized
INFO - 2020-10-14 12:24:07 --> URI Class Initialized
INFO - 2020-10-14 12:24:07 --> Router Class Initialized
INFO - 2020-10-14 12:24:07 --> Output Class Initialized
INFO - 2020-10-14 12:24:07 --> Security Class Initialized
DEBUG - 2020-10-14 12:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:24:07 --> CSRF cookie sent
INFO - 2020-10-14 12:24:07 --> CSRF token verified
INFO - 2020-10-14 12:24:07 --> Input Class Initialized
INFO - 2020-10-14 12:24:07 --> Language Class Initialized
INFO - 2020-10-14 12:24:07 --> Language Class Initialized
INFO - 2020-10-14 12:24:07 --> Config Class Initialized
INFO - 2020-10-14 12:24:07 --> Loader Class Initialized
INFO - 2020-10-14 12:24:07 --> Helper loaded: url_helper
INFO - 2020-10-14 12:24:07 --> Helper loaded: file_helper
INFO - 2020-10-14 12:24:07 --> Helper loaded: string_helper
INFO - 2020-10-14 12:24:07 --> Database Driver Class Initialized
INFO - 2020-10-14 12:24:07 --> Email Class Initialized
INFO - 2020-10-14 12:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:24:07 --> Controller Class Initialized
DEBUG - 2020-10-14 12:24:07 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:24:07 --> Model "Common_model" initialized
INFO - 2020-10-14 12:24:08 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:24:08 --> Final output sent to browser
DEBUG - 2020-10-14 12:24:08 --> Total execution time: 0.3804
INFO - 2020-10-14 12:30:02 --> Config Class Initialized
INFO - 2020-10-14 12:30:02 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:30:02 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:30:02 --> Utf8 Class Initialized
INFO - 2020-10-14 12:30:02 --> URI Class Initialized
INFO - 2020-10-14 12:30:02 --> Router Class Initialized
INFO - 2020-10-14 12:30:02 --> Output Class Initialized
INFO - 2020-10-14 12:30:02 --> Security Class Initialized
DEBUG - 2020-10-14 12:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:30:02 --> CSRF cookie sent
INFO - 2020-10-14 12:30:02 --> Input Class Initialized
INFO - 2020-10-14 12:30:02 --> Language Class Initialized
INFO - 2020-10-14 12:30:02 --> Language Class Initialized
INFO - 2020-10-14 12:30:02 --> Config Class Initialized
INFO - 2020-10-14 12:30:02 --> Loader Class Initialized
INFO - 2020-10-14 12:30:02 --> Helper loaded: url_helper
INFO - 2020-10-14 12:30:02 --> Helper loaded: file_helper
INFO - 2020-10-14 12:30:02 --> Helper loaded: string_helper
INFO - 2020-10-14 12:30:02 --> Database Driver Class Initialized
INFO - 2020-10-14 12:30:02 --> Email Class Initialized
INFO - 2020-10-14 12:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:30:02 --> Controller Class Initialized
DEBUG - 2020-10-14 12:30:02 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:30:02 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:30:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:30:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:30:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:30:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/make_logo.php
DEBUG - 2020-10-14 12:30:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:30:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:30:02 --> Final output sent to browser
DEBUG - 2020-10-14 12:30:02 --> Total execution time: 0.1425
INFO - 2020-10-14 12:30:05 --> Config Class Initialized
INFO - 2020-10-14 12:30:05 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:30:05 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:30:05 --> Utf8 Class Initialized
INFO - 2020-10-14 12:30:05 --> URI Class Initialized
INFO - 2020-10-14 12:30:05 --> Router Class Initialized
INFO - 2020-10-14 12:30:05 --> Output Class Initialized
INFO - 2020-10-14 12:30:05 --> Security Class Initialized
DEBUG - 2020-10-14 12:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:30:05 --> CSRF cookie sent
INFO - 2020-10-14 12:30:05 --> Input Class Initialized
INFO - 2020-10-14 12:30:05 --> Language Class Initialized
INFO - 2020-10-14 12:30:05 --> Language Class Initialized
INFO - 2020-10-14 12:30:05 --> Config Class Initialized
INFO - 2020-10-14 12:30:05 --> Loader Class Initialized
INFO - 2020-10-14 12:30:05 --> Helper loaded: url_helper
INFO - 2020-10-14 12:30:05 --> Helper loaded: file_helper
INFO - 2020-10-14 12:30:05 --> Helper loaded: string_helper
INFO - 2020-10-14 12:30:05 --> Database Driver Class Initialized
INFO - 2020-10-14 12:30:05 --> Config Class Initialized
INFO - 2020-10-14 12:30:05 --> Hooks Class Initialized
INFO - 2020-10-14 12:30:05 --> Config Class Initialized
INFO - 2020-10-14 12:30:05 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:30:05 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:30:05 --> Utf8 Class Initialized
DEBUG - 2020-10-14 12:30:05 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:30:05 --> URI Class Initialized
INFO - 2020-10-14 12:30:05 --> Utf8 Class Initialized
INFO - 2020-10-14 12:30:05 --> URI Class Initialized
INFO - 2020-10-14 12:30:05 --> Router Class Initialized
INFO - 2020-10-14 12:30:05 --> Output Class Initialized
INFO - 2020-10-14 12:30:05 --> Router Class Initialized
INFO - 2020-10-14 12:30:05 --> Security Class Initialized
INFO - 2020-10-14 12:30:05 --> Output Class Initialized
INFO - 2020-10-14 12:30:05 --> Security Class Initialized
INFO - 2020-10-14 12:30:05 --> Email Class Initialized
DEBUG - 2020-10-14 12:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:30:05 --> CSRF cookie sent
INFO - 2020-10-14 12:30:05 --> CSRF token verified
INFO - 2020-10-14 12:30:05 --> Input Class Initialized
INFO - 2020-10-14 12:30:05 --> Language Class Initialized
INFO - 2020-10-14 12:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:30:05 --> Controller Class Initialized
DEBUG - 2020-10-14 12:30:05 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:30:05 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:30:05 --> CSRF cookie sent
INFO - 2020-10-14 12:30:05 --> CSRF token verified
INFO - 2020-10-14 12:30:05 --> Input Class Initialized
INFO - 2020-10-14 12:30:05 --> Language Class Initialized
INFO - 2020-10-14 12:30:05 --> Language Class Initialized
INFO - 2020-10-14 12:30:05 --> Config Class Initialized
INFO - 2020-10-14 12:30:05 --> Loader Class Initialized
INFO - 2020-10-14 12:30:05 --> Helper loaded: url_helper
INFO - 2020-10-14 12:30:05 --> Helper loaded: file_helper
INFO - 2020-10-14 12:30:05 --> Helper loaded: string_helper
INFO - 2020-10-14 12:30:05 --> Language Class Initialized
INFO - 2020-10-14 12:30:05 --> Config Class Initialized
INFO - 2020-10-14 12:30:05 --> Final output sent to browser
DEBUG - 2020-10-14 12:30:05 --> Total execution time: 0.1075
INFO - 2020-10-14 12:30:05 --> Database Driver Class Initialized
INFO - 2020-10-14 12:30:05 --> Loader Class Initialized
INFO - 2020-10-14 12:30:05 --> Helper loaded: url_helper
INFO - 2020-10-14 12:30:05 --> Helper loaded: file_helper
INFO - 2020-10-14 12:30:05 --> Helper loaded: string_helper
INFO - 2020-10-14 12:30:05 --> Email Class Initialized
INFO - 2020-10-14 12:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:30:05 --> Controller Class Initialized
DEBUG - 2020-10-14 12:30:05 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:30:05 --> Model "Common_model" initialized
INFO - 2020-10-14 12:30:05 --> Database Driver Class Initialized
INFO - 2020-10-14 12:30:05 --> Final output sent to browser
DEBUG - 2020-10-14 12:30:05 --> Total execution time: 0.0357
INFO - 2020-10-14 12:30:05 --> Email Class Initialized
INFO - 2020-10-14 12:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:30:05 --> Controller Class Initialized
DEBUG - 2020-10-14 12:30:05 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:30:05 --> Model "Common_model" initialized
INFO - 2020-10-14 12:30:05 --> Final output sent to browser
DEBUG - 2020-10-14 12:30:05 --> Total execution time: 0.0784
INFO - 2020-10-14 12:30:20 --> Config Class Initialized
INFO - 2020-10-14 12:30:20 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:30:20 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:30:20 --> Utf8 Class Initialized
INFO - 2020-10-14 12:30:20 --> URI Class Initialized
INFO - 2020-10-14 12:30:20 --> Router Class Initialized
INFO - 2020-10-14 12:30:20 --> Output Class Initialized
INFO - 2020-10-14 12:30:20 --> Security Class Initialized
DEBUG - 2020-10-14 12:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:30:20 --> CSRF cookie sent
INFO - 2020-10-14 12:30:20 --> CSRF token verified
INFO - 2020-10-14 12:30:20 --> Input Class Initialized
INFO - 2020-10-14 12:30:20 --> Language Class Initialized
INFO - 2020-10-14 12:30:20 --> Language Class Initialized
INFO - 2020-10-14 12:30:20 --> Config Class Initialized
INFO - 2020-10-14 12:30:20 --> Loader Class Initialized
INFO - 2020-10-14 12:30:20 --> Helper loaded: url_helper
INFO - 2020-10-14 12:30:20 --> Helper loaded: file_helper
INFO - 2020-10-14 12:30:20 --> Helper loaded: string_helper
INFO - 2020-10-14 12:30:20 --> Database Driver Class Initialized
INFO - 2020-10-14 12:30:20 --> Email Class Initialized
INFO - 2020-10-14 12:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:30:20 --> Controller Class Initialized
DEBUG - 2020-10-14 12:30:20 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:30:21 --> Model "Common_model" initialized
INFO - 2020-10-14 12:30:21 --> Final output sent to browser
DEBUG - 2020-10-14 12:30:21 --> Total execution time: 0.0292
INFO - 2020-10-14 12:31:26 --> Config Class Initialized
INFO - 2020-10-14 12:31:26 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:31:26 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:31:26 --> Utf8 Class Initialized
INFO - 2020-10-14 12:31:26 --> URI Class Initialized
INFO - 2020-10-14 12:31:26 --> Router Class Initialized
INFO - 2020-10-14 12:31:26 --> Output Class Initialized
INFO - 2020-10-14 12:31:26 --> Security Class Initialized
DEBUG - 2020-10-14 12:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:31:26 --> CSRF cookie sent
INFO - 2020-10-14 12:31:26 --> CSRF token verified
INFO - 2020-10-14 12:31:26 --> Input Class Initialized
INFO - 2020-10-14 12:31:26 --> Language Class Initialized
INFO - 2020-10-14 12:31:26 --> Language Class Initialized
INFO - 2020-10-14 12:31:26 --> Config Class Initialized
INFO - 2020-10-14 12:31:26 --> Loader Class Initialized
INFO - 2020-10-14 12:31:26 --> Helper loaded: url_helper
INFO - 2020-10-14 12:31:26 --> Helper loaded: file_helper
INFO - 2020-10-14 12:31:26 --> Helper loaded: string_helper
INFO - 2020-10-14 12:31:26 --> Database Driver Class Initialized
INFO - 2020-10-14 12:31:26 --> Email Class Initialized
INFO - 2020-10-14 12:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:31:26 --> Controller Class Initialized
DEBUG - 2020-10-14 12:31:26 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:31:26 --> Model "Common_model" initialized
INFO - 2020-10-14 12:31:26 --> Upload Class Initialized
INFO - 2020-10-14 12:31:26 --> Image Lib Class Initialized
INFO - 2020-10-14 12:31:26 --> Final output sent to browser
DEBUG - 2020-10-14 12:31:26 --> Total execution time: 0.0940
INFO - 2020-10-14 12:31:26 --> Config Class Initialized
INFO - 2020-10-14 12:31:26 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:31:26 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:31:26 --> Utf8 Class Initialized
INFO - 2020-10-14 12:31:26 --> URI Class Initialized
INFO - 2020-10-14 12:31:26 --> Router Class Initialized
INFO - 2020-10-14 12:31:26 --> Output Class Initialized
INFO - 2020-10-14 12:31:26 --> Security Class Initialized
DEBUG - 2020-10-14 12:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:31:26 --> CSRF cookie sent
INFO - 2020-10-14 12:31:26 --> CSRF token verified
INFO - 2020-10-14 12:31:26 --> Input Class Initialized
INFO - 2020-10-14 12:31:26 --> Language Class Initialized
INFO - 2020-10-14 12:31:26 --> Language Class Initialized
INFO - 2020-10-14 12:31:26 --> Config Class Initialized
INFO - 2020-10-14 12:31:26 --> Loader Class Initialized
INFO - 2020-10-14 12:31:26 --> Helper loaded: url_helper
INFO - 2020-10-14 12:31:26 --> Helper loaded: file_helper
INFO - 2020-10-14 12:31:26 --> Helper loaded: string_helper
INFO - 2020-10-14 12:31:26 --> Database Driver Class Initialized
INFO - 2020-10-14 12:31:26 --> Email Class Initialized
INFO - 2020-10-14 12:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:31:26 --> Controller Class Initialized
DEBUG - 2020-10-14 12:31:26 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:31:26 --> Model "Common_model" initialized
INFO - 2020-10-14 12:31:26 --> Final output sent to browser
DEBUG - 2020-10-14 12:31:26 --> Total execution time: 0.0310
INFO - 2020-10-14 12:31:49 --> Config Class Initialized
INFO - 2020-10-14 12:31:49 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:31:49 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:31:49 --> Utf8 Class Initialized
INFO - 2020-10-14 12:31:49 --> URI Class Initialized
INFO - 2020-10-14 12:31:49 --> Router Class Initialized
INFO - 2020-10-14 12:31:49 --> Output Class Initialized
INFO - 2020-10-14 12:31:49 --> Security Class Initialized
DEBUG - 2020-10-14 12:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:31:49 --> CSRF cookie sent
INFO - 2020-10-14 12:31:49 --> CSRF token verified
INFO - 2020-10-14 12:31:49 --> Input Class Initialized
INFO - 2020-10-14 12:31:49 --> Language Class Initialized
INFO - 2020-10-14 12:31:49 --> Language Class Initialized
INFO - 2020-10-14 12:31:49 --> Config Class Initialized
INFO - 2020-10-14 12:31:49 --> Loader Class Initialized
INFO - 2020-10-14 12:31:49 --> Helper loaded: url_helper
INFO - 2020-10-14 12:31:49 --> Helper loaded: file_helper
INFO - 2020-10-14 12:31:49 --> Helper loaded: string_helper
INFO - 2020-10-14 12:31:49 --> Database Driver Class Initialized
INFO - 2020-10-14 12:31:49 --> Email Class Initialized
INFO - 2020-10-14 12:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:31:49 --> Controller Class Initialized
DEBUG - 2020-10-14 12:31:49 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:31:49 --> Model "Common_model" initialized
ERROR - 2020-10-14 12:31:50 --> Severity: Notice --> Undefined index: SPT_DOCROOT /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 829
ERROR - 2020-10-14 12:31:50 --> Severity: Warning --> imagepng(/color-innovator/uploads/user_logo_images/10/20201014123126792-merge.png): failed to open stream: No such file or directory /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 1073
INFO - 2020-10-14 12:31:50 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:31:50 --> Final output sent to browser
DEBUG - 2020-10-14 12:31:50 --> Total execution time: 1.1876
INFO - 2020-10-14 12:32:41 --> Config Class Initialized
INFO - 2020-10-14 12:32:41 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:32:41 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:32:41 --> Utf8 Class Initialized
INFO - 2020-10-14 12:32:41 --> URI Class Initialized
INFO - 2020-10-14 12:32:41 --> Router Class Initialized
INFO - 2020-10-14 12:32:41 --> Output Class Initialized
INFO - 2020-10-14 12:32:41 --> Security Class Initialized
DEBUG - 2020-10-14 12:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:32:41 --> CSRF cookie sent
INFO - 2020-10-14 12:32:41 --> Input Class Initialized
INFO - 2020-10-14 12:32:41 --> Language Class Initialized
ERROR - 2020-10-14 12:32:41 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:32:42 --> Config Class Initialized
INFO - 2020-10-14 12:32:42 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:32:42 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:32:42 --> Utf8 Class Initialized
INFO - 2020-10-14 12:32:42 --> URI Class Initialized
INFO - 2020-10-14 12:32:42 --> Router Class Initialized
INFO - 2020-10-14 12:32:42 --> Output Class Initialized
INFO - 2020-10-14 12:32:42 --> Security Class Initialized
DEBUG - 2020-10-14 12:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:32:42 --> CSRF cookie sent
INFO - 2020-10-14 12:32:42 --> Input Class Initialized
INFO - 2020-10-14 12:32:42 --> Language Class Initialized
ERROR - 2020-10-14 12:32:42 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:32:44 --> Config Class Initialized
INFO - 2020-10-14 12:32:44 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:32:44 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:32:44 --> Utf8 Class Initialized
INFO - 2020-10-14 12:32:44 --> URI Class Initialized
INFO - 2020-10-14 12:32:44 --> Router Class Initialized
INFO - 2020-10-14 12:32:44 --> Output Class Initialized
INFO - 2020-10-14 12:32:44 --> Security Class Initialized
DEBUG - 2020-10-14 12:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:32:44 --> CSRF cookie sent
INFO - 2020-10-14 12:32:44 --> Input Class Initialized
INFO - 2020-10-14 12:32:44 --> Language Class Initialized
ERROR - 2020-10-14 12:32:44 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:33:52 --> Config Class Initialized
INFO - 2020-10-14 12:33:52 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:33:52 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:33:52 --> Utf8 Class Initialized
INFO - 2020-10-14 12:33:52 --> URI Class Initialized
INFO - 2020-10-14 12:33:52 --> Router Class Initialized
INFO - 2020-10-14 12:33:52 --> Output Class Initialized
INFO - 2020-10-14 12:33:52 --> Security Class Initialized
DEBUG - 2020-10-14 12:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:33:52 --> CSRF cookie sent
INFO - 2020-10-14 12:33:52 --> CSRF token verified
INFO - 2020-10-14 12:33:52 --> Input Class Initialized
INFO - 2020-10-14 12:33:52 --> Language Class Initialized
INFO - 2020-10-14 12:33:52 --> Language Class Initialized
INFO - 2020-10-14 12:33:52 --> Config Class Initialized
INFO - 2020-10-14 12:33:52 --> Loader Class Initialized
INFO - 2020-10-14 12:33:52 --> Helper loaded: url_helper
INFO - 2020-10-14 12:33:52 --> Helper loaded: file_helper
INFO - 2020-10-14 12:33:52 --> Helper loaded: string_helper
INFO - 2020-10-14 12:33:52 --> Database Driver Class Initialized
INFO - 2020-10-14 12:33:52 --> Email Class Initialized
INFO - 2020-10-14 12:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:33:52 --> Controller Class Initialized
DEBUG - 2020-10-14 12:33:52 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:33:52 --> Model "Common_model" initialized
ERROR - 2020-10-14 12:33:53 --> Severity: Notice --> Undefined index: SPT_DOCROOT /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 829
ERROR - 2020-10-14 12:33:53 --> Severity: Warning --> imagepng(/color-innovator/uploads/user_logo_images/10/20201014123126792-merge.png): failed to open stream: No such file or directory /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 1073
INFO - 2020-10-14 12:33:53 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:33:53 --> Final output sent to browser
DEBUG - 2020-10-14 12:33:53 --> Total execution time: 1.0274
INFO - 2020-10-14 12:34:49 --> Config Class Initialized
INFO - 2020-10-14 12:34:49 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:34:49 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:34:49 --> Utf8 Class Initialized
INFO - 2020-10-14 12:34:49 --> URI Class Initialized
INFO - 2020-10-14 12:34:49 --> Router Class Initialized
INFO - 2020-10-14 12:34:49 --> Output Class Initialized
INFO - 2020-10-14 12:34:49 --> Security Class Initialized
DEBUG - 2020-10-14 12:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:34:49 --> CSRF cookie sent
INFO - 2020-10-14 12:34:49 --> Input Class Initialized
INFO - 2020-10-14 12:34:49 --> Language Class Initialized
ERROR - 2020-10-14 12:34:49 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:34:50 --> Config Class Initialized
INFO - 2020-10-14 12:34:50 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:34:50 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:34:50 --> Utf8 Class Initialized
INFO - 2020-10-14 12:34:50 --> URI Class Initialized
INFO - 2020-10-14 12:34:50 --> Router Class Initialized
INFO - 2020-10-14 12:34:50 --> Output Class Initialized
INFO - 2020-10-14 12:34:50 --> Security Class Initialized
DEBUG - 2020-10-14 12:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:34:50 --> CSRF cookie sent
INFO - 2020-10-14 12:34:50 --> Input Class Initialized
INFO - 2020-10-14 12:34:50 --> Language Class Initialized
ERROR - 2020-10-14 12:34:50 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:34:52 --> Config Class Initialized
INFO - 2020-10-14 12:34:52 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:34:52 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:34:52 --> Utf8 Class Initialized
INFO - 2020-10-14 12:34:52 --> URI Class Initialized
INFO - 2020-10-14 12:34:52 --> Router Class Initialized
INFO - 2020-10-14 12:34:52 --> Output Class Initialized
INFO - 2020-10-14 12:34:52 --> Security Class Initialized
DEBUG - 2020-10-14 12:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:34:52 --> CSRF cookie sent
INFO - 2020-10-14 12:34:52 --> Input Class Initialized
INFO - 2020-10-14 12:34:52 --> Language Class Initialized
ERROR - 2020-10-14 12:34:52 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:34:53 --> Config Class Initialized
INFO - 2020-10-14 12:34:53 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:34:53 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:34:53 --> Utf8 Class Initialized
INFO - 2020-10-14 12:34:53 --> URI Class Initialized
INFO - 2020-10-14 12:34:53 --> Router Class Initialized
INFO - 2020-10-14 12:34:53 --> Output Class Initialized
INFO - 2020-10-14 12:34:53 --> Security Class Initialized
DEBUG - 2020-10-14 12:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:34:53 --> CSRF cookie sent
INFO - 2020-10-14 12:34:53 --> Input Class Initialized
INFO - 2020-10-14 12:34:53 --> Language Class Initialized
ERROR - 2020-10-14 12:34:53 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:34:58 --> Config Class Initialized
INFO - 2020-10-14 12:34:58 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:34:58 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:34:58 --> Utf8 Class Initialized
INFO - 2020-10-14 12:34:58 --> URI Class Initialized
INFO - 2020-10-14 12:34:58 --> Router Class Initialized
INFO - 2020-10-14 12:34:58 --> Output Class Initialized
INFO - 2020-10-14 12:34:58 --> Security Class Initialized
DEBUG - 2020-10-14 12:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:34:58 --> CSRF cookie sent
INFO - 2020-10-14 12:34:58 --> Input Class Initialized
INFO - 2020-10-14 12:34:58 --> Language Class Initialized
INFO - 2020-10-14 12:34:58 --> Language Class Initialized
INFO - 2020-10-14 12:34:58 --> Config Class Initialized
INFO - 2020-10-14 12:34:58 --> Loader Class Initialized
INFO - 2020-10-14 12:34:58 --> Helper loaded: url_helper
INFO - 2020-10-14 12:34:58 --> Helper loaded: file_helper
INFO - 2020-10-14 12:34:58 --> Helper loaded: string_helper
INFO - 2020-10-14 12:34:58 --> Database Driver Class Initialized
INFO - 2020-10-14 12:34:58 --> Email Class Initialized
INFO - 2020-10-14 12:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:34:58 --> Controller Class Initialized
DEBUG - 2020-10-14 12:34:58 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:34:58 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:34:58 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:34:58 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:34:58 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:34:58 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/make_logo.php
DEBUG - 2020-10-14 12:34:58 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:34:58 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:34:58 --> Final output sent to browser
DEBUG - 2020-10-14 12:34:58 --> Total execution time: 0.0419
INFO - 2020-10-14 12:35:01 --> Config Class Initialized
INFO - 2020-10-14 12:35:01 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:35:01 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:35:01 --> Utf8 Class Initialized
INFO - 2020-10-14 12:35:01 --> URI Class Initialized
INFO - 2020-10-14 12:35:01 --> Router Class Initialized
INFO - 2020-10-14 12:35:01 --> Output Class Initialized
INFO - 2020-10-14 12:35:01 --> Security Class Initialized
DEBUG - 2020-10-14 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:35:01 --> CSRF cookie sent
INFO - 2020-10-14 12:35:01 --> CSRF token verified
INFO - 2020-10-14 12:35:01 --> Input Class Initialized
INFO - 2020-10-14 12:35:01 --> Language Class Initialized
INFO - 2020-10-14 12:35:01 --> Language Class Initialized
INFO - 2020-10-14 12:35:01 --> Config Class Initialized
INFO - 2020-10-14 12:35:01 --> Loader Class Initialized
INFO - 2020-10-14 12:35:01 --> Helper loaded: url_helper
INFO - 2020-10-14 12:35:01 --> Helper loaded: file_helper
INFO - 2020-10-14 12:35:01 --> Helper loaded: string_helper
INFO - 2020-10-14 12:35:01 --> Database Driver Class Initialized
INFO - 2020-10-14 12:35:01 --> Email Class Initialized
INFO - 2020-10-14 12:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:35:01 --> Controller Class Initialized
DEBUG - 2020-10-14 12:35:01 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:35:01 --> Model "Common_model" initialized
INFO - 2020-10-14 12:35:01 --> Final output sent to browser
DEBUG - 2020-10-14 12:35:01 --> Total execution time: 0.0304
INFO - 2020-10-14 12:35:01 --> Config Class Initialized
INFO - 2020-10-14 12:35:01 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:35:01 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:35:01 --> Utf8 Class Initialized
INFO - 2020-10-14 12:35:01 --> URI Class Initialized
INFO - 2020-10-14 12:35:01 --> Router Class Initialized
INFO - 2020-10-14 12:35:01 --> Output Class Initialized
INFO - 2020-10-14 12:35:01 --> Security Class Initialized
DEBUG - 2020-10-14 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:35:01 --> CSRF cookie sent
INFO - 2020-10-14 12:35:01 --> CSRF token verified
INFO - 2020-10-14 12:35:01 --> Input Class Initialized
INFO - 2020-10-14 12:35:01 --> Language Class Initialized
INFO - 2020-10-14 12:35:01 --> Language Class Initialized
INFO - 2020-10-14 12:35:01 --> Config Class Initialized
INFO - 2020-10-14 12:35:01 --> Loader Class Initialized
INFO - 2020-10-14 12:35:01 --> Helper loaded: url_helper
INFO - 2020-10-14 12:35:01 --> Helper loaded: file_helper
INFO - 2020-10-14 12:35:01 --> Helper loaded: string_helper
INFO - 2020-10-14 12:35:01 --> Database Driver Class Initialized
INFO - 2020-10-14 12:35:01 --> Email Class Initialized
INFO - 2020-10-14 12:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:35:01 --> Controller Class Initialized
DEBUG - 2020-10-14 12:35:01 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:35:01 --> Model "Common_model" initialized
INFO - 2020-10-14 12:35:01 --> Config Class Initialized
INFO - 2020-10-14 12:35:01 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:35:01 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:35:01 --> Utf8 Class Initialized
INFO - 2020-10-14 12:35:01 --> URI Class Initialized
INFO - 2020-10-14 12:35:01 --> Router Class Initialized
INFO - 2020-10-14 12:35:01 --> Output Class Initialized
INFO - 2020-10-14 12:35:01 --> Final output sent to browser
DEBUG - 2020-10-14 12:35:01 --> Total execution time: 0.0895
INFO - 2020-10-14 12:35:01 --> Security Class Initialized
DEBUG - 2020-10-14 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:35:01 --> CSRF cookie sent
INFO - 2020-10-14 12:35:01 --> Input Class Initialized
INFO - 2020-10-14 12:35:01 --> Language Class Initialized
INFO - 2020-10-14 12:35:01 --> Language Class Initialized
INFO - 2020-10-14 12:35:01 --> Config Class Initialized
INFO - 2020-10-14 12:35:01 --> Loader Class Initialized
INFO - 2020-10-14 12:35:01 --> Helper loaded: url_helper
INFO - 2020-10-14 12:35:01 --> Helper loaded: file_helper
INFO - 2020-10-14 12:35:01 --> Helper loaded: string_helper
INFO - 2020-10-14 12:35:01 --> Database Driver Class Initialized
INFO - 2020-10-14 12:35:01 --> Email Class Initialized
INFO - 2020-10-14 12:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:35:01 --> Controller Class Initialized
DEBUG - 2020-10-14 12:35:01 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:35:01 --> Model "Common_model" initialized
INFO - 2020-10-14 12:35:01 --> Final output sent to browser
DEBUG - 2020-10-14 12:35:01 --> Total execution time: 0.0468
INFO - 2020-10-14 12:35:16 --> Config Class Initialized
INFO - 2020-10-14 12:35:16 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:35:16 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:35:16 --> Utf8 Class Initialized
INFO - 2020-10-14 12:35:16 --> URI Class Initialized
INFO - 2020-10-14 12:35:16 --> Router Class Initialized
INFO - 2020-10-14 12:35:16 --> Output Class Initialized
INFO - 2020-10-14 12:35:16 --> Security Class Initialized
DEBUG - 2020-10-14 12:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:35:16 --> CSRF cookie sent
INFO - 2020-10-14 12:35:16 --> CSRF token verified
INFO - 2020-10-14 12:35:16 --> Input Class Initialized
INFO - 2020-10-14 12:35:16 --> Language Class Initialized
INFO - 2020-10-14 12:35:16 --> Language Class Initialized
INFO - 2020-10-14 12:35:16 --> Config Class Initialized
INFO - 2020-10-14 12:35:16 --> Loader Class Initialized
INFO - 2020-10-14 12:35:16 --> Helper loaded: url_helper
INFO - 2020-10-14 12:35:16 --> Helper loaded: file_helper
INFO - 2020-10-14 12:35:16 --> Helper loaded: string_helper
INFO - 2020-10-14 12:35:16 --> Database Driver Class Initialized
INFO - 2020-10-14 12:35:16 --> Email Class Initialized
INFO - 2020-10-14 12:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:35:16 --> Controller Class Initialized
DEBUG - 2020-10-14 12:35:16 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:35:16 --> Model "Common_model" initialized
INFO - 2020-10-14 12:35:17 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:35:17 --> Final output sent to browser
DEBUG - 2020-10-14 12:35:17 --> Total execution time: 1.0513
INFO - 2020-10-14 12:36:34 --> Config Class Initialized
INFO - 2020-10-14 12:36:34 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:36:34 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:36:34 --> Utf8 Class Initialized
INFO - 2020-10-14 12:36:34 --> URI Class Initialized
INFO - 2020-10-14 12:36:34 --> Router Class Initialized
INFO - 2020-10-14 12:36:34 --> Output Class Initialized
INFO - 2020-10-14 12:36:34 --> Security Class Initialized
DEBUG - 2020-10-14 12:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:36:34 --> CSRF cookie sent
INFO - 2020-10-14 12:36:34 --> CSRF token verified
INFO - 2020-10-14 12:36:34 --> Input Class Initialized
INFO - 2020-10-14 12:36:34 --> Language Class Initialized
INFO - 2020-10-14 12:36:34 --> Language Class Initialized
INFO - 2020-10-14 12:36:34 --> Config Class Initialized
INFO - 2020-10-14 12:36:34 --> Loader Class Initialized
INFO - 2020-10-14 12:36:34 --> Helper loaded: url_helper
INFO - 2020-10-14 12:36:34 --> Helper loaded: file_helper
INFO - 2020-10-14 12:36:34 --> Helper loaded: string_helper
INFO - 2020-10-14 12:36:34 --> Database Driver Class Initialized
INFO - 2020-10-14 12:36:34 --> Email Class Initialized
INFO - 2020-10-14 12:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:36:34 --> Controller Class Initialized
DEBUG - 2020-10-14 12:36:34 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:36:34 --> Model "Common_model" initialized
INFO - 2020-10-14 12:36:35 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:36:35 --> Final output sent to browser
DEBUG - 2020-10-14 12:36:35 --> Total execution time: 0.9998
INFO - 2020-10-14 12:37:55 --> Config Class Initialized
INFO - 2020-10-14 12:37:55 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:37:55 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:37:55 --> Utf8 Class Initialized
INFO - 2020-10-14 12:37:55 --> URI Class Initialized
INFO - 2020-10-14 12:37:55 --> Router Class Initialized
INFO - 2020-10-14 12:37:55 --> Output Class Initialized
INFO - 2020-10-14 12:37:55 --> Security Class Initialized
DEBUG - 2020-10-14 12:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:37:55 --> CSRF cookie sent
INFO - 2020-10-14 12:37:55 --> Input Class Initialized
INFO - 2020-10-14 12:37:55 --> Language Class Initialized
INFO - 2020-10-14 12:37:55 --> Language Class Initialized
INFO - 2020-10-14 12:37:55 --> Config Class Initialized
INFO - 2020-10-14 12:37:55 --> Loader Class Initialized
INFO - 2020-10-14 12:37:55 --> Helper loaded: url_helper
INFO - 2020-10-14 12:37:55 --> Helper loaded: file_helper
INFO - 2020-10-14 12:37:55 --> Helper loaded: string_helper
INFO - 2020-10-14 12:37:55 --> Database Driver Class Initialized
INFO - 2020-10-14 12:37:55 --> Email Class Initialized
INFO - 2020-10-14 12:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:37:55 --> Controller Class Initialized
DEBUG - 2020-10-14 12:37:55 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:37:55 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:37:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:37:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:37:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/mobile_view_links.php
DEBUG - 2020-10-14 12:37:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:37:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/place.php
DEBUG - 2020-10-14 12:37:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:37:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:37:55 --> Final output sent to browser
DEBUG - 2020-10-14 12:37:55 --> Total execution time: 0.0352
INFO - 2020-10-14 12:37:58 --> Config Class Initialized
INFO - 2020-10-14 12:37:58 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:37:58 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:37:58 --> Utf8 Class Initialized
INFO - 2020-10-14 12:37:58 --> URI Class Initialized
INFO - 2020-10-14 12:37:58 --> Router Class Initialized
INFO - 2020-10-14 12:37:58 --> Output Class Initialized
INFO - 2020-10-14 12:37:58 --> Security Class Initialized
DEBUG - 2020-10-14 12:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:37:58 --> CSRF cookie sent
INFO - 2020-10-14 12:37:58 --> Input Class Initialized
INFO - 2020-10-14 12:37:58 --> Language Class Initialized
INFO - 2020-10-14 12:37:58 --> Language Class Initialized
INFO - 2020-10-14 12:37:58 --> Config Class Initialized
INFO - 2020-10-14 12:37:58 --> Loader Class Initialized
INFO - 2020-10-14 12:37:58 --> Helper loaded: url_helper
INFO - 2020-10-14 12:37:58 --> Helper loaded: file_helper
INFO - 2020-10-14 12:37:58 --> Helper loaded: string_helper
INFO - 2020-10-14 12:37:59 --> Database Driver Class Initialized
INFO - 2020-10-14 12:37:59 --> Email Class Initialized
INFO - 2020-10-14 12:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:37:59 --> Controller Class Initialized
DEBUG - 2020-10-14 12:37:59 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:37:59 --> Model "Common_model" initialized
INFO - 2020-10-14 12:37:59 --> Final output sent to browser
DEBUG - 2020-10-14 12:37:59 --> Total execution time: 0.0281
INFO - 2020-10-14 12:37:59 --> Config Class Initialized
INFO - 2020-10-14 12:37:59 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:37:59 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:37:59 --> Utf8 Class Initialized
INFO - 2020-10-14 12:37:59 --> URI Class Initialized
INFO - 2020-10-14 12:37:59 --> Router Class Initialized
INFO - 2020-10-14 12:37:59 --> Output Class Initialized
INFO - 2020-10-14 12:37:59 --> Security Class Initialized
DEBUG - 2020-10-14 12:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:37:59 --> CSRF cookie sent
INFO - 2020-10-14 12:37:59 --> CSRF token verified
INFO - 2020-10-14 12:37:59 --> Input Class Initialized
INFO - 2020-10-14 12:37:59 --> Language Class Initialized
INFO - 2020-10-14 12:37:59 --> Language Class Initialized
INFO - 2020-10-14 12:37:59 --> Config Class Initialized
INFO - 2020-10-14 12:37:59 --> Loader Class Initialized
INFO - 2020-10-14 12:37:59 --> Helper loaded: url_helper
INFO - 2020-10-14 12:37:59 --> Helper loaded: file_helper
INFO - 2020-10-14 12:37:59 --> Helper loaded: string_helper
INFO - 2020-10-14 12:37:59 --> Database Driver Class Initialized
INFO - 2020-10-14 12:37:59 --> Config Class Initialized
INFO - 2020-10-14 12:37:59 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:37:59 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:37:59 --> Utf8 Class Initialized
INFO - 2020-10-14 12:37:59 --> URI Class Initialized
INFO - 2020-10-14 12:37:59 --> Router Class Initialized
INFO - 2020-10-14 12:37:59 --> Email Class Initialized
INFO - 2020-10-14 12:37:59 --> Output Class Initialized
INFO - 2020-10-14 12:37:59 --> Security Class Initialized
INFO - 2020-10-14 12:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:37:59 --> Controller Class Initialized
DEBUG - 2020-10-14 12:37:59 --> Home MX_Controller Initialized
DEBUG - 2020-10-14 12:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:37:59 --> CSRF cookie sent
INFO - 2020-10-14 12:37:59 --> CSRF token verified
INFO - 2020-10-14 12:37:59 --> Input Class Initialized
INFO - 2020-10-14 12:37:59 --> Language Class Initialized
INFO - 2020-10-14 12:37:59 --> Model "Common_model" initialized
INFO - 2020-10-14 12:37:59 --> Final output sent to browser
DEBUG - 2020-10-14 12:37:59 --> Total execution time: 0.0308
INFO - 2020-10-14 12:37:59 --> Language Class Initialized
INFO - 2020-10-14 12:37:59 --> Config Class Initialized
INFO - 2020-10-14 12:37:59 --> Loader Class Initialized
INFO - 2020-10-14 12:37:59 --> Helper loaded: url_helper
INFO - 2020-10-14 12:37:59 --> Helper loaded: file_helper
INFO - 2020-10-14 12:37:59 --> Helper loaded: string_helper
INFO - 2020-10-14 12:37:59 --> Database Driver Class Initialized
INFO - 2020-10-14 12:37:59 --> Email Class Initialized
INFO - 2020-10-14 12:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:37:59 --> Controller Class Initialized
DEBUG - 2020-10-14 12:37:59 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:37:59 --> Model "Common_model" initialized
INFO - 2020-10-14 12:37:59 --> Final output sent to browser
DEBUG - 2020-10-14 12:37:59 --> Total execution time: 0.0282
INFO - 2020-10-14 12:38:08 --> Config Class Initialized
INFO - 2020-10-14 12:38:08 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:38:08 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:38:08 --> Utf8 Class Initialized
INFO - 2020-10-14 12:38:08 --> URI Class Initialized
INFO - 2020-10-14 12:38:08 --> Router Class Initialized
INFO - 2020-10-14 12:38:08 --> Output Class Initialized
INFO - 2020-10-14 12:38:08 --> Security Class Initialized
DEBUG - 2020-10-14 12:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:38:08 --> CSRF cookie sent
INFO - 2020-10-14 12:38:08 --> CSRF token verified
INFO - 2020-10-14 12:38:08 --> Input Class Initialized
INFO - 2020-10-14 12:38:08 --> Language Class Initialized
INFO - 2020-10-14 12:38:08 --> Language Class Initialized
INFO - 2020-10-14 12:38:08 --> Config Class Initialized
INFO - 2020-10-14 12:38:08 --> Loader Class Initialized
INFO - 2020-10-14 12:38:08 --> Helper loaded: url_helper
INFO - 2020-10-14 12:38:08 --> Helper loaded: file_helper
INFO - 2020-10-14 12:38:08 --> Helper loaded: string_helper
INFO - 2020-10-14 12:38:08 --> Database Driver Class Initialized
INFO - 2020-10-14 12:38:08 --> Email Class Initialized
INFO - 2020-10-14 12:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:38:08 --> Controller Class Initialized
DEBUG - 2020-10-14 12:38:08 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:38:08 --> Model "Common_model" initialized
INFO - 2020-10-14 12:38:08 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:38:08 --> Final output sent to browser
DEBUG - 2020-10-14 12:38:08 --> Total execution time: 0.1674
INFO - 2020-10-14 12:38:48 --> Config Class Initialized
INFO - 2020-10-14 12:38:48 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:38:48 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:38:48 --> Utf8 Class Initialized
INFO - 2020-10-14 12:38:48 --> URI Class Initialized
INFO - 2020-10-14 12:38:48 --> Router Class Initialized
INFO - 2020-10-14 12:38:48 --> Output Class Initialized
INFO - 2020-10-14 12:38:48 --> Security Class Initialized
DEBUG - 2020-10-14 12:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:38:48 --> CSRF cookie sent
INFO - 2020-10-14 12:38:48 --> Input Class Initialized
INFO - 2020-10-14 12:38:48 --> Language Class Initialized
INFO - 2020-10-14 12:38:48 --> Language Class Initialized
INFO - 2020-10-14 12:38:48 --> Config Class Initialized
INFO - 2020-10-14 12:38:48 --> Loader Class Initialized
INFO - 2020-10-14 12:38:48 --> Helper loaded: url_helper
INFO - 2020-10-14 12:38:48 --> Helper loaded: file_helper
INFO - 2020-10-14 12:38:48 --> Helper loaded: string_helper
INFO - 2020-10-14 12:38:48 --> Database Driver Class Initialized
INFO - 2020-10-14 12:38:48 --> Email Class Initialized
INFO - 2020-10-14 12:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:38:49 --> Controller Class Initialized
DEBUG - 2020-10-14 12:38:49 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:38:49 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:38:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:38:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:38:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:38:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/make.php
DEBUG - 2020-10-14 12:38:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:38:49 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:38:49 --> Final output sent to browser
DEBUG - 2020-10-14 12:38:49 --> Total execution time: 0.0445
INFO - 2020-10-14 12:38:51 --> Config Class Initialized
INFO - 2020-10-14 12:38:51 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:38:51 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:38:51 --> Utf8 Class Initialized
INFO - 2020-10-14 12:38:51 --> URI Class Initialized
INFO - 2020-10-14 12:38:51 --> Router Class Initialized
INFO - 2020-10-14 12:38:51 --> Output Class Initialized
INFO - 2020-10-14 12:38:51 --> Security Class Initialized
DEBUG - 2020-10-14 12:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:38:51 --> CSRF cookie sent
INFO - 2020-10-14 12:38:51 --> Input Class Initialized
INFO - 2020-10-14 12:38:51 --> Language Class Initialized
ERROR - 2020-10-14 12:38:51 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:38:52 --> Config Class Initialized
INFO - 2020-10-14 12:38:52 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:38:52 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:38:52 --> Utf8 Class Initialized
INFO - 2020-10-14 12:38:52 --> URI Class Initialized
INFO - 2020-10-14 12:38:52 --> Router Class Initialized
INFO - 2020-10-14 12:38:52 --> Output Class Initialized
INFO - 2020-10-14 12:38:52 --> Security Class Initialized
INFO - 2020-10-14 12:38:52 --> Config Class Initialized
INFO - 2020-10-14 12:38:52 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:38:52 --> CSRF cookie sent
INFO - 2020-10-14 12:38:52 --> Input Class Initialized
INFO - 2020-10-14 12:38:52 --> Language Class Initialized
DEBUG - 2020-10-14 12:38:52 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:38:52 --> Utf8 Class Initialized
INFO - 2020-10-14 12:38:52 --> URI Class Initialized
INFO - 2020-10-14 12:38:52 --> Router Class Initialized
INFO - 2020-10-14 12:38:52 --> Language Class Initialized
INFO - 2020-10-14 12:38:52 --> Config Class Initialized
INFO - 2020-10-14 12:38:52 --> Output Class Initialized
INFO - 2020-10-14 12:38:52 --> Security Class Initialized
INFO - 2020-10-14 12:38:52 --> Loader Class Initialized
INFO - 2020-10-14 12:38:52 --> Helper loaded: url_helper
DEBUG - 2020-10-14 12:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:38:52 --> CSRF cookie sent
INFO - 2020-10-14 12:38:52 --> CSRF token verified
INFO - 2020-10-14 12:38:52 --> Input Class Initialized
INFO - 2020-10-14 12:38:52 --> Language Class Initialized
INFO - 2020-10-14 12:38:52 --> Config Class Initialized
INFO - 2020-10-14 12:38:52 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:38:52 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:38:52 --> Utf8 Class Initialized
INFO - 2020-10-14 12:38:52 --> Language Class Initialized
INFO - 2020-10-14 12:38:52 --> Config Class Initialized
INFO - 2020-10-14 12:38:52 --> URI Class Initialized
INFO - 2020-10-14 12:38:52 --> Router Class Initialized
INFO - 2020-10-14 12:38:52 --> Loader Class Initialized
INFO - 2020-10-14 12:38:52 --> Helper loaded: url_helper
INFO - 2020-10-14 12:38:52 --> Helper loaded: file_helper
INFO - 2020-10-14 12:38:52 --> Helper loaded: file_helper
INFO - 2020-10-14 12:38:52 --> Helper loaded: string_helper
INFO - 2020-10-14 12:38:52 --> Helper loaded: string_helper
INFO - 2020-10-14 12:38:52 --> Database Driver Class Initialized
INFO - 2020-10-14 12:38:52 --> Output Class Initialized
INFO - 2020-10-14 12:38:52 --> Database Driver Class Initialized
INFO - 2020-10-14 12:38:52 --> Security Class Initialized
DEBUG - 2020-10-14 12:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:38:52 --> CSRF cookie sent
INFO - 2020-10-14 12:38:52 --> CSRF token verified
INFO - 2020-10-14 12:38:52 --> Input Class Initialized
INFO - 2020-10-14 12:38:52 --> Language Class Initialized
INFO - 2020-10-14 12:38:52 --> Email Class Initialized
INFO - 2020-10-14 12:38:52 --> Language Class Initialized
INFO - 2020-10-14 12:38:52 --> Config Class Initialized
INFO - 2020-10-14 12:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:38:52 --> Controller Class Initialized
DEBUG - 2020-10-14 12:38:52 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:38:52 --> Loader Class Initialized
INFO - 2020-10-14 12:38:52 --> Model "Common_model" initialized
INFO - 2020-10-14 12:38:52 --> Helper loaded: url_helper
INFO - 2020-10-14 12:38:52 --> Helper loaded: file_helper
INFO - 2020-10-14 12:38:52 --> Helper loaded: string_helper
INFO - 2020-10-14 12:38:52 --> Final output sent to browser
DEBUG - 2020-10-14 12:38:52 --> Total execution time: 0.0402
INFO - 2020-10-14 12:38:52 --> Database Driver Class Initialized
INFO - 2020-10-14 12:38:52 --> Email Class Initialized
INFO - 2020-10-14 12:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:38:52 --> Controller Class Initialized
DEBUG - 2020-10-14 12:38:52 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:38:52 --> Model "Common_model" initialized
INFO - 2020-10-14 12:38:52 --> Email Class Initialized
INFO - 2020-10-14 12:38:52 --> Final output sent to browser
DEBUG - 2020-10-14 12:38:52 --> Total execution time: 0.0982
INFO - 2020-10-14 12:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:38:52 --> Controller Class Initialized
DEBUG - 2020-10-14 12:38:52 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:38:52 --> Model "Common_model" initialized
INFO - 2020-10-14 12:38:52 --> Final output sent to browser
DEBUG - 2020-10-14 12:38:52 --> Total execution time: 0.0789
INFO - 2020-10-14 12:39:01 --> Config Class Initialized
INFO - 2020-10-14 12:39:01 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:39:01 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:39:01 --> Utf8 Class Initialized
INFO - 2020-10-14 12:39:01 --> URI Class Initialized
INFO - 2020-10-14 12:39:01 --> Router Class Initialized
INFO - 2020-10-14 12:39:01 --> Output Class Initialized
INFO - 2020-10-14 12:39:01 --> Security Class Initialized
DEBUG - 2020-10-14 12:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:39:01 --> CSRF cookie sent
INFO - 2020-10-14 12:39:01 --> Input Class Initialized
INFO - 2020-10-14 12:39:01 --> Language Class Initialized
ERROR - 2020-10-14 12:39:01 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:39:05 --> Config Class Initialized
INFO - 2020-10-14 12:39:05 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:39:05 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:39:05 --> Utf8 Class Initialized
INFO - 2020-10-14 12:39:05 --> URI Class Initialized
INFO - 2020-10-14 12:39:05 --> Router Class Initialized
INFO - 2020-10-14 12:39:05 --> Output Class Initialized
INFO - 2020-10-14 12:39:05 --> Security Class Initialized
DEBUG - 2020-10-14 12:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:39:05 --> CSRF cookie sent
INFO - 2020-10-14 12:39:05 --> CSRF token verified
INFO - 2020-10-14 12:39:05 --> Input Class Initialized
INFO - 2020-10-14 12:39:05 --> Language Class Initialized
INFO - 2020-10-14 12:39:05 --> Language Class Initialized
INFO - 2020-10-14 12:39:05 --> Config Class Initialized
INFO - 2020-10-14 12:39:05 --> Loader Class Initialized
INFO - 2020-10-14 12:39:05 --> Helper loaded: url_helper
INFO - 2020-10-14 12:39:05 --> Helper loaded: file_helper
INFO - 2020-10-14 12:39:05 --> Helper loaded: string_helper
INFO - 2020-10-14 12:39:05 --> Database Driver Class Initialized
INFO - 2020-10-14 12:39:05 --> Email Class Initialized
INFO - 2020-10-14 12:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:39:05 --> Controller Class Initialized
DEBUG - 2020-10-14 12:39:05 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:39:05 --> Model "Common_model" initialized
INFO - 2020-10-14 12:39:06 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:39:06 --> Final output sent to browser
DEBUG - 2020-10-14 12:39:06 --> Total execution time: 0.4120
INFO - 2020-10-14 12:40:09 --> Config Class Initialized
INFO - 2020-10-14 12:40:09 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:40:09 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:40:09 --> Utf8 Class Initialized
INFO - 2020-10-14 12:40:09 --> URI Class Initialized
INFO - 2020-10-14 12:40:09 --> Router Class Initialized
INFO - 2020-10-14 12:40:09 --> Output Class Initialized
INFO - 2020-10-14 12:40:09 --> Security Class Initialized
DEBUG - 2020-10-14 12:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:40:09 --> CSRF cookie sent
INFO - 2020-10-14 12:40:09 --> Input Class Initialized
INFO - 2020-10-14 12:40:09 --> Language Class Initialized
ERROR - 2020-10-14 12:40:09 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:40:11 --> Config Class Initialized
INFO - 2020-10-14 12:40:11 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:40:11 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:40:11 --> Utf8 Class Initialized
INFO - 2020-10-14 12:40:11 --> URI Class Initialized
INFO - 2020-10-14 12:40:11 --> Router Class Initialized
INFO - 2020-10-14 12:40:11 --> Output Class Initialized
INFO - 2020-10-14 12:40:11 --> Security Class Initialized
DEBUG - 2020-10-14 12:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:40:11 --> CSRF cookie sent
INFO - 2020-10-14 12:40:11 --> CSRF token verified
INFO - 2020-10-14 12:40:11 --> Input Class Initialized
INFO - 2020-10-14 12:40:11 --> Language Class Initialized
INFO - 2020-10-14 12:40:11 --> Language Class Initialized
INFO - 2020-10-14 12:40:11 --> Config Class Initialized
INFO - 2020-10-14 12:40:11 --> Loader Class Initialized
INFO - 2020-10-14 12:40:11 --> Helper loaded: url_helper
INFO - 2020-10-14 12:40:11 --> Helper loaded: file_helper
INFO - 2020-10-14 12:40:11 --> Helper loaded: string_helper
INFO - 2020-10-14 12:40:11 --> Database Driver Class Initialized
INFO - 2020-10-14 12:40:11 --> Email Class Initialized
INFO - 2020-10-14 12:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:40:11 --> Controller Class Initialized
DEBUG - 2020-10-14 12:40:11 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:40:11 --> Model "Common_model" initialized
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecreatefromjpeg(): gd-jpeg: JPEG library reports unrecoverable error: Not a JPEG file: starts with 0x89 0x50 /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 844
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecreatefromjpeg(): 'https://dinoflex.com/color-innovator/images/1_70_0_0_0_Fine-14_25_173_47_52_Fine-21_5_119_130_155_Fine-1602670748434.jpg' is not a valid JPEG file /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 844
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
ERROR - 2020-10-14 12:40:11 --> Severity: Warning --> imagecopyresampled() expects parameter 2 to be resource, bool given /home/dinof2/public_html/color-innovator/application/modules/Home/controllers/Home.php 868
INFO - 2020-10-14 12:40:12 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:40:12 --> Final output sent to browser
DEBUG - 2020-10-14 12:40:12 --> Total execution time: 0.8929
INFO - 2020-10-14 12:41:21 --> Config Class Initialized
INFO - 2020-10-14 12:41:21 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:41:21 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:41:21 --> Utf8 Class Initialized
INFO - 2020-10-14 12:41:21 --> URI Class Initialized
INFO - 2020-10-14 12:41:21 --> Router Class Initialized
INFO - 2020-10-14 12:41:21 --> Output Class Initialized
INFO - 2020-10-14 12:41:21 --> Security Class Initialized
DEBUG - 2020-10-14 12:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:41:21 --> CSRF cookie sent
INFO - 2020-10-14 12:41:21 --> Input Class Initialized
INFO - 2020-10-14 12:41:21 --> Language Class Initialized
INFO - 2020-10-14 12:41:21 --> Language Class Initialized
INFO - 2020-10-14 12:41:21 --> Config Class Initialized
INFO - 2020-10-14 12:41:21 --> Loader Class Initialized
INFO - 2020-10-14 12:41:21 --> Helper loaded: url_helper
INFO - 2020-10-14 12:41:21 --> Helper loaded: file_helper
INFO - 2020-10-14 12:41:21 --> Helper loaded: string_helper
INFO - 2020-10-14 12:41:21 --> Database Driver Class Initialized
INFO - 2020-10-14 12:41:21 --> Email Class Initialized
INFO - 2020-10-14 12:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:41:21 --> Controller Class Initialized
DEBUG - 2020-10-14 12:41:21 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:41:21 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:41:21 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:41:21 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:41:21 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/mobile_view_links.php
DEBUG - 2020-10-14 12:41:21 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:41:21 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/place.php
DEBUG - 2020-10-14 12:41:21 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:41:21 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:41:21 --> Final output sent to browser
DEBUG - 2020-10-14 12:41:21 --> Total execution time: 0.0331
INFO - 2020-10-14 12:41:24 --> Config Class Initialized
INFO - 2020-10-14 12:41:24 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:41:24 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:41:24 --> Utf8 Class Initialized
INFO - 2020-10-14 12:41:24 --> URI Class Initialized
INFO - 2020-10-14 12:41:24 --> Router Class Initialized
INFO - 2020-10-14 12:41:24 --> Config Class Initialized
INFO - 2020-10-14 12:41:24 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:41:24 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:41:24 --> Utf8 Class Initialized
INFO - 2020-10-14 12:41:24 --> URI Class Initialized
INFO - 2020-10-14 12:41:24 --> Router Class Initialized
INFO - 2020-10-14 12:41:24 --> Output Class Initialized
INFO - 2020-10-14 12:41:24 --> Output Class Initialized
INFO - 2020-10-14 12:41:24 --> Security Class Initialized
DEBUG - 2020-10-14 12:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:41:24 --> Security Class Initialized
INFO - 2020-10-14 12:41:24 --> CSRF cookie sent
DEBUG - 2020-10-14 12:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:41:24 --> Input Class Initialized
INFO - 2020-10-14 12:41:24 --> CSRF cookie sent
INFO - 2020-10-14 12:41:24 --> CSRF token verified
INFO - 2020-10-14 12:41:24 --> Input Class Initialized
INFO - 2020-10-14 12:41:24 --> Language Class Initialized
INFO - 2020-10-14 12:41:24 --> Language Class Initialized
INFO - 2020-10-14 12:41:24 --> Language Class Initialized
INFO - 2020-10-14 12:41:24 --> Config Class Initialized
INFO - 2020-10-14 12:41:24 --> Language Class Initialized
INFO - 2020-10-14 12:41:24 --> Config Class Initialized
INFO - 2020-10-14 12:41:24 --> Loader Class Initialized
INFO - 2020-10-14 12:41:24 --> Loader Class Initialized
INFO - 2020-10-14 12:41:24 --> Helper loaded: url_helper
INFO - 2020-10-14 12:41:24 --> Helper loaded: url_helper
INFO - 2020-10-14 12:41:24 --> Helper loaded: file_helper
INFO - 2020-10-14 12:41:24 --> Helper loaded: file_helper
INFO - 2020-10-14 12:41:24 --> Helper loaded: string_helper
INFO - 2020-10-14 12:41:24 --> Helper loaded: string_helper
INFO - 2020-10-14 12:41:24 --> Database Driver Class Initialized
INFO - 2020-10-14 12:41:24 --> Config Class Initialized
INFO - 2020-10-14 12:41:24 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:41:24 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:41:24 --> Utf8 Class Initialized
INFO - 2020-10-14 12:41:24 --> URI Class Initialized
INFO - 2020-10-14 12:41:24 --> Router Class Initialized
INFO - 2020-10-14 12:41:24 --> Email Class Initialized
INFO - 2020-10-14 12:41:24 --> Output Class Initialized
INFO - 2020-10-14 12:41:24 --> Security Class Initialized
INFO - 2020-10-14 12:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:41:24 --> Controller Class Initialized
DEBUG - 2020-10-14 12:41:24 --> Home MX_Controller Initialized
DEBUG - 2020-10-14 12:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:41:24 --> CSRF cookie sent
INFO - 2020-10-14 12:41:24 --> CSRF token verified
INFO - 2020-10-14 12:41:24 --> Input Class Initialized
INFO - 2020-10-14 12:41:24 --> Language Class Initialized
INFO - 2020-10-14 12:41:24 --> Model "Common_model" initialized
INFO - 2020-10-14 12:41:24 --> Database Driver Class Initialized
INFO - 2020-10-14 12:41:24 --> Final output sent to browser
DEBUG - 2020-10-14 12:41:24 --> Total execution time: 0.0813
INFO - 2020-10-14 12:41:24 --> Language Class Initialized
INFO - 2020-10-14 12:41:24 --> Config Class Initialized
INFO - 2020-10-14 12:41:24 --> Loader Class Initialized
INFO - 2020-10-14 12:41:24 --> Helper loaded: url_helper
INFO - 2020-10-14 12:41:24 --> Helper loaded: file_helper
INFO - 2020-10-14 12:41:24 --> Helper loaded: string_helper
INFO - 2020-10-14 12:41:24 --> Email Class Initialized
INFO - 2020-10-14 12:41:24 --> Database Driver Class Initialized
INFO - 2020-10-14 12:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:41:24 --> Controller Class Initialized
DEBUG - 2020-10-14 12:41:24 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:41:24 --> Model "Common_model" initialized
INFO - 2020-10-14 12:41:24 --> Final output sent to browser
DEBUG - 2020-10-14 12:41:24 --> Total execution time: 0.0844
INFO - 2020-10-14 12:41:24 --> Email Class Initialized
INFO - 2020-10-14 12:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:41:24 --> Controller Class Initialized
DEBUG - 2020-10-14 12:41:24 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:41:24 --> Model "Common_model" initialized
INFO - 2020-10-14 12:41:24 --> Final output sent to browser
DEBUG - 2020-10-14 12:41:24 --> Total execution time: 0.0316
INFO - 2020-10-14 12:41:36 --> Config Class Initialized
INFO - 2020-10-14 12:41:36 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:41:36 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:41:36 --> Utf8 Class Initialized
INFO - 2020-10-14 12:41:36 --> URI Class Initialized
INFO - 2020-10-14 12:41:36 --> Router Class Initialized
INFO - 2020-10-14 12:41:36 --> Output Class Initialized
INFO - 2020-10-14 12:41:36 --> Security Class Initialized
DEBUG - 2020-10-14 12:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:41:36 --> CSRF cookie sent
INFO - 2020-10-14 12:41:36 --> Input Class Initialized
INFO - 2020-10-14 12:41:36 --> Language Class Initialized
INFO - 2020-10-14 12:41:36 --> Language Class Initialized
INFO - 2020-10-14 12:41:36 --> Config Class Initialized
INFO - 2020-10-14 12:41:36 --> Loader Class Initialized
INFO - 2020-10-14 12:41:36 --> Helper loaded: url_helper
INFO - 2020-10-14 12:41:36 --> Helper loaded: file_helper
INFO - 2020-10-14 12:41:36 --> Helper loaded: string_helper
INFO - 2020-10-14 12:41:36 --> Database Driver Class Initialized
INFO - 2020-10-14 12:41:36 --> Email Class Initialized
INFO - 2020-10-14 12:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:41:36 --> Controller Class Initialized
DEBUG - 2020-10-14 12:41:36 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:41:36 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:41:36 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:41:36 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:41:36 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:41:36 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/step_4.php
DEBUG - 2020-10-14 12:41:36 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:41:36 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:41:36 --> Final output sent to browser
DEBUG - 2020-10-14 12:41:36 --> Total execution time: 0.0354
INFO - 2020-10-14 12:41:40 --> Config Class Initialized
INFO - 2020-10-14 12:41:40 --> Hooks Class Initialized
INFO - 2020-10-14 12:41:40 --> Config Class Initialized
INFO - 2020-10-14 12:41:40 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:41:40 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:41:40 --> Utf8 Class Initialized
DEBUG - 2020-10-14 12:41:40 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:41:40 --> Utf8 Class Initialized
INFO - 2020-10-14 12:41:40 --> URI Class Initialized
INFO - 2020-10-14 12:41:40 --> URI Class Initialized
INFO - 2020-10-14 12:41:40 --> Router Class Initialized
INFO - 2020-10-14 12:41:40 --> Router Class Initialized
INFO - 2020-10-14 12:41:40 --> Output Class Initialized
INFO - 2020-10-14 12:41:40 --> Output Class Initialized
INFO - 2020-10-14 12:41:40 --> Security Class Initialized
DEBUG - 2020-10-14 12:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:41:40 --> Security Class Initialized
INFO - 2020-10-14 12:41:40 --> CSRF cookie sent
INFO - 2020-10-14 12:41:40 --> Input Class Initialized
INFO - 2020-10-14 12:41:40 --> Language Class Initialized
DEBUG - 2020-10-14 12:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:41:40 --> CSRF cookie sent
INFO - 2020-10-14 12:41:40 --> CSRF token verified
INFO - 2020-10-14 12:41:40 --> Input Class Initialized
INFO - 2020-10-14 12:41:40 --> Language Class Initialized
INFO - 2020-10-14 12:41:40 --> Language Class Initialized
INFO - 2020-10-14 12:41:40 --> Config Class Initialized
INFO - 2020-10-14 12:41:40 --> Language Class Initialized
INFO - 2020-10-14 12:41:40 --> Config Class Initialized
INFO - 2020-10-14 12:41:40 --> Loader Class Initialized
INFO - 2020-10-14 12:41:40 --> Helper loaded: url_helper
INFO - 2020-10-14 12:41:40 --> Helper loaded: file_helper
INFO - 2020-10-14 12:41:40 --> Loader Class Initialized
INFO - 2020-10-14 12:41:40 --> Helper loaded: string_helper
INFO - 2020-10-14 12:41:40 --> Helper loaded: url_helper
INFO - 2020-10-14 12:41:40 --> Helper loaded: file_helper
INFO - 2020-10-14 12:41:40 --> Helper loaded: string_helper
INFO - 2020-10-14 12:41:40 --> Database Driver Class Initialized
INFO - 2020-10-14 12:41:40 --> Database Driver Class Initialized
INFO - 2020-10-14 12:41:40 --> Email Class Initialized
INFO - 2020-10-14 12:41:40 --> Email Class Initialized
INFO - 2020-10-14 12:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:41:40 --> Controller Class Initialized
DEBUG - 2020-10-14 12:41:40 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:41:40 --> Model "Common_model" initialized
INFO - 2020-10-14 12:41:40 --> Final output sent to browser
DEBUG - 2020-10-14 12:41:40 --> Total execution time: 0.0318
INFO - 2020-10-14 12:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:41:40 --> Controller Class Initialized
DEBUG - 2020-10-14 12:41:40 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:41:40 --> Model "Common_model" initialized
INFO - 2020-10-14 12:41:40 --> Final output sent to browser
DEBUG - 2020-10-14 12:41:40 --> Total execution time: 0.0387
INFO - 2020-10-14 12:41:41 --> Config Class Initialized
INFO - 2020-10-14 12:41:41 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:41:41 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:41:41 --> Utf8 Class Initialized
INFO - 2020-10-14 12:41:41 --> URI Class Initialized
INFO - 2020-10-14 12:41:41 --> Router Class Initialized
INFO - 2020-10-14 12:41:41 --> Output Class Initialized
INFO - 2020-10-14 12:41:41 --> Security Class Initialized
DEBUG - 2020-10-14 12:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:41:41 --> CSRF cookie sent
INFO - 2020-10-14 12:41:41 --> CSRF token verified
INFO - 2020-10-14 12:41:41 --> Input Class Initialized
INFO - 2020-10-14 12:41:41 --> Language Class Initialized
INFO - 2020-10-14 12:41:41 --> Language Class Initialized
INFO - 2020-10-14 12:41:41 --> Config Class Initialized
INFO - 2020-10-14 12:41:41 --> Loader Class Initialized
INFO - 2020-10-14 12:41:41 --> Helper loaded: url_helper
INFO - 2020-10-14 12:41:41 --> Helper loaded: file_helper
INFO - 2020-10-14 12:41:41 --> Helper loaded: string_helper
INFO - 2020-10-14 12:41:41 --> Database Driver Class Initialized
INFO - 2020-10-14 12:41:41 --> Email Class Initialized
INFO - 2020-10-14 12:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:41:41 --> Controller Class Initialized
DEBUG - 2020-10-14 12:41:41 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:41:41 --> Model "Common_model" initialized
INFO - 2020-10-14 12:41:41 --> Final output sent to browser
DEBUG - 2020-10-14 12:41:41 --> Total execution time: 0.0289
INFO - 2020-10-14 12:43:36 --> Config Class Initialized
INFO - 2020-10-14 12:43:36 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:43:36 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:43:36 --> Utf8 Class Initialized
INFO - 2020-10-14 12:43:36 --> URI Class Initialized
INFO - 2020-10-14 12:43:36 --> Router Class Initialized
INFO - 2020-10-14 12:43:36 --> Output Class Initialized
INFO - 2020-10-14 12:43:36 --> Security Class Initialized
DEBUG - 2020-10-14 12:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:43:36 --> CSRF cookie sent
INFO - 2020-10-14 12:43:36 --> CSRF token verified
INFO - 2020-10-14 12:43:36 --> Input Class Initialized
INFO - 2020-10-14 12:43:36 --> Language Class Initialized
INFO - 2020-10-14 12:43:36 --> Language Class Initialized
INFO - 2020-10-14 12:43:36 --> Config Class Initialized
INFO - 2020-10-14 12:43:36 --> Loader Class Initialized
INFO - 2020-10-14 12:43:36 --> Helper loaded: url_helper
INFO - 2020-10-14 12:43:36 --> Helper loaded: file_helper
INFO - 2020-10-14 12:43:36 --> Helper loaded: string_helper
INFO - 2020-10-14 12:43:36 --> Database Driver Class Initialized
INFO - 2020-10-14 12:43:36 --> Email Class Initialized
INFO - 2020-10-14 12:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:43:36 --> Controller Class Initialized
DEBUG - 2020-10-14 12:43:36 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:43:36 --> Model "Common_model" initialized
INFO - 2020-10-14 12:43:36 --> Final output sent to browser
DEBUG - 2020-10-14 12:43:36 --> Total execution time: 0.0325
INFO - 2020-10-14 12:43:36 --> Config Class Initialized
INFO - 2020-10-14 12:43:36 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:43:36 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:43:36 --> Utf8 Class Initialized
INFO - 2020-10-14 12:43:36 --> URI Class Initialized
INFO - 2020-10-14 12:43:36 --> Router Class Initialized
INFO - 2020-10-14 12:43:36 --> Output Class Initialized
INFO - 2020-10-14 12:43:36 --> Security Class Initialized
DEBUG - 2020-10-14 12:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:43:36 --> CSRF cookie sent
INFO - 2020-10-14 12:43:36 --> CSRF token verified
INFO - 2020-10-14 12:43:36 --> Input Class Initialized
INFO - 2020-10-14 12:43:36 --> Language Class Initialized
INFO - 2020-10-14 12:43:36 --> Language Class Initialized
INFO - 2020-10-14 12:43:36 --> Config Class Initialized
INFO - 2020-10-14 12:43:36 --> Loader Class Initialized
INFO - 2020-10-14 12:43:36 --> Helper loaded: url_helper
INFO - 2020-10-14 12:43:36 --> Helper loaded: file_helper
INFO - 2020-10-14 12:43:36 --> Helper loaded: string_helper
INFO - 2020-10-14 12:43:36 --> Database Driver Class Initialized
INFO - 2020-10-14 12:43:36 --> Email Class Initialized
INFO - 2020-10-14 12:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:43:36 --> Controller Class Initialized
DEBUG - 2020-10-14 12:43:36 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:43:36 --> Model "Common_model" initialized
INFO - 2020-10-14 12:43:36 --> Final output sent to browser
DEBUG - 2020-10-14 12:43:36 --> Total execution time: 0.0384
INFO - 2020-10-14 12:43:36 --> Config Class Initialized
INFO - 2020-10-14 12:43:36 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:43:36 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:43:36 --> Utf8 Class Initialized
INFO - 2020-10-14 12:43:36 --> URI Class Initialized
INFO - 2020-10-14 12:43:36 --> Router Class Initialized
INFO - 2020-10-14 12:43:36 --> Output Class Initialized
INFO - 2020-10-14 12:43:36 --> Security Class Initialized
DEBUG - 2020-10-14 12:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:43:36 --> CSRF cookie sent
INFO - 2020-10-14 12:43:36 --> CSRF token verified
INFO - 2020-10-14 12:43:36 --> Input Class Initialized
INFO - 2020-10-14 12:43:36 --> Language Class Initialized
INFO - 2020-10-14 12:43:36 --> Language Class Initialized
INFO - 2020-10-14 12:43:36 --> Config Class Initialized
INFO - 2020-10-14 12:43:36 --> Loader Class Initialized
INFO - 2020-10-14 12:43:36 --> Helper loaded: url_helper
INFO - 2020-10-14 12:43:36 --> Helper loaded: file_helper
INFO - 2020-10-14 12:43:36 --> Helper loaded: string_helper
INFO - 2020-10-14 12:43:36 --> Database Driver Class Initialized
INFO - 2020-10-14 12:43:36 --> Email Class Initialized
INFO - 2020-10-14 12:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:43:36 --> Controller Class Initialized
DEBUG - 2020-10-14 12:43:36 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:43:36 --> Model "Common_model" initialized
INFO - 2020-10-14 12:43:36 --> Final output sent to browser
DEBUG - 2020-10-14 12:43:36 --> Total execution time: 0.0333
INFO - 2020-10-14 12:43:36 --> Config Class Initialized
INFO - 2020-10-14 12:43:36 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:43:36 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:43:36 --> Utf8 Class Initialized
INFO - 2020-10-14 12:43:36 --> URI Class Initialized
INFO - 2020-10-14 12:43:36 --> Router Class Initialized
INFO - 2020-10-14 12:43:36 --> Output Class Initialized
INFO - 2020-10-14 12:43:36 --> Security Class Initialized
DEBUG - 2020-10-14 12:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:43:36 --> CSRF cookie sent
INFO - 2020-10-14 12:43:36 --> CSRF token verified
INFO - 2020-10-14 12:43:36 --> Input Class Initialized
INFO - 2020-10-14 12:43:36 --> Language Class Initialized
INFO - 2020-10-14 12:43:36 --> Language Class Initialized
INFO - 2020-10-14 12:43:36 --> Config Class Initialized
INFO - 2020-10-14 12:43:36 --> Loader Class Initialized
INFO - 2020-10-14 12:43:36 --> Helper loaded: url_helper
INFO - 2020-10-14 12:43:36 --> Helper loaded: file_helper
INFO - 2020-10-14 12:43:36 --> Helper loaded: string_helper
INFO - 2020-10-14 12:43:36 --> Database Driver Class Initialized
INFO - 2020-10-14 12:43:36 --> Email Class Initialized
INFO - 2020-10-14 12:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:43:36 --> Controller Class Initialized
DEBUG - 2020-10-14 12:43:36 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:43:36 --> Model "Common_model" initialized
INFO - 2020-10-14 12:43:36 --> Final output sent to browser
DEBUG - 2020-10-14 12:43:36 --> Total execution time: 0.0334
INFO - 2020-10-14 12:43:38 --> Config Class Initialized
INFO - 2020-10-14 12:43:38 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:43:38 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:43:38 --> Utf8 Class Initialized
INFO - 2020-10-14 12:43:38 --> URI Class Initialized
INFO - 2020-10-14 12:43:38 --> Router Class Initialized
INFO - 2020-10-14 12:43:38 --> Output Class Initialized
INFO - 2020-10-14 12:43:38 --> Security Class Initialized
DEBUG - 2020-10-14 12:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:43:38 --> CSRF cookie sent
INFO - 2020-10-14 12:43:38 --> CSRF token verified
INFO - 2020-10-14 12:43:38 --> Input Class Initialized
INFO - 2020-10-14 12:43:38 --> Language Class Initialized
INFO - 2020-10-14 12:43:38 --> Language Class Initialized
INFO - 2020-10-14 12:43:38 --> Config Class Initialized
INFO - 2020-10-14 12:43:38 --> Loader Class Initialized
INFO - 2020-10-14 12:43:38 --> Helper loaded: url_helper
INFO - 2020-10-14 12:43:38 --> Helper loaded: file_helper
INFO - 2020-10-14 12:43:38 --> Helper loaded: string_helper
INFO - 2020-10-14 12:43:38 --> Database Driver Class Initialized
INFO - 2020-10-14 12:43:38 --> Email Class Initialized
INFO - 2020-10-14 12:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:43:38 --> Controller Class Initialized
DEBUG - 2020-10-14 12:43:38 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:43:38 --> Model "Common_model" initialized
INFO - 2020-10-14 12:43:38 --> Final output sent to browser
DEBUG - 2020-10-14 12:43:38 --> Total execution time: 0.0347
INFO - 2020-10-14 12:43:38 --> Config Class Initialized
INFO - 2020-10-14 12:43:38 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:43:38 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:43:38 --> Utf8 Class Initialized
INFO - 2020-10-14 12:43:38 --> URI Class Initialized
INFO - 2020-10-14 12:43:38 --> Router Class Initialized
INFO - 2020-10-14 12:43:38 --> Output Class Initialized
INFO - 2020-10-14 12:43:38 --> Security Class Initialized
DEBUG - 2020-10-14 12:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:43:38 --> CSRF cookie sent
INFO - 2020-10-14 12:43:38 --> CSRF token verified
INFO - 2020-10-14 12:43:38 --> Input Class Initialized
INFO - 2020-10-14 12:43:38 --> Language Class Initialized
INFO - 2020-10-14 12:43:38 --> Language Class Initialized
INFO - 2020-10-14 12:43:38 --> Config Class Initialized
INFO - 2020-10-14 12:43:38 --> Loader Class Initialized
INFO - 2020-10-14 12:43:38 --> Helper loaded: url_helper
INFO - 2020-10-14 12:43:38 --> Helper loaded: file_helper
INFO - 2020-10-14 12:43:38 --> Helper loaded: string_helper
INFO - 2020-10-14 12:43:38 --> Database Driver Class Initialized
INFO - 2020-10-14 12:43:38 --> Email Class Initialized
INFO - 2020-10-14 12:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:43:38 --> Controller Class Initialized
DEBUG - 2020-10-14 12:43:38 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:43:38 --> Model "Common_model" initialized
INFO - 2020-10-14 12:43:38 --> Final output sent to browser
DEBUG - 2020-10-14 12:43:38 --> Total execution time: 0.0336
INFO - 2020-10-14 12:44:02 --> Config Class Initialized
INFO - 2020-10-14 12:44:02 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:44:02 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:44:02 --> Utf8 Class Initialized
INFO - 2020-10-14 12:44:02 --> URI Class Initialized
INFO - 2020-10-14 12:44:02 --> Router Class Initialized
INFO - 2020-10-14 12:44:02 --> Output Class Initialized
INFO - 2020-10-14 12:44:02 --> Security Class Initialized
DEBUG - 2020-10-14 12:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:44:02 --> CSRF cookie sent
INFO - 2020-10-14 12:44:02 --> Input Class Initialized
INFO - 2020-10-14 12:44:02 --> Language Class Initialized
INFO - 2020-10-14 12:44:02 --> Language Class Initialized
INFO - 2020-10-14 12:44:02 --> Config Class Initialized
INFO - 2020-10-14 12:44:02 --> Loader Class Initialized
INFO - 2020-10-14 12:44:02 --> Helper loaded: url_helper
INFO - 2020-10-14 12:44:02 --> Helper loaded: file_helper
INFO - 2020-10-14 12:44:02 --> Helper loaded: string_helper
INFO - 2020-10-14 12:44:02 --> Database Driver Class Initialized
INFO - 2020-10-14 12:44:02 --> Email Class Initialized
INFO - 2020-10-14 12:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:44:02 --> Controller Class Initialized
DEBUG - 2020-10-14 12:44:02 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:44:02 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:44:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:44:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:44:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:44:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/step_4.php
DEBUG - 2020-10-14 12:44:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:44:02 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:44:02 --> Final output sent to browser
DEBUG - 2020-10-14 12:44:02 --> Total execution time: 0.0429
INFO - 2020-10-14 12:47:17 --> Config Class Initialized
INFO - 2020-10-14 12:47:17 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:47:17 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:47:17 --> Utf8 Class Initialized
INFO - 2020-10-14 12:47:17 --> URI Class Initialized
INFO - 2020-10-14 12:47:17 --> Router Class Initialized
INFO - 2020-10-14 12:47:17 --> Output Class Initialized
INFO - 2020-10-14 12:47:17 --> Security Class Initialized
DEBUG - 2020-10-14 12:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:47:17 --> CSRF cookie sent
INFO - 2020-10-14 12:47:17 --> Input Class Initialized
INFO - 2020-10-14 12:47:17 --> Language Class Initialized
INFO - 2020-10-14 12:47:17 --> Language Class Initialized
INFO - 2020-10-14 12:47:17 --> Config Class Initialized
INFO - 2020-10-14 12:47:17 --> Loader Class Initialized
INFO - 2020-10-14 12:47:17 --> Helper loaded: url_helper
INFO - 2020-10-14 12:47:17 --> Helper loaded: file_helper
INFO - 2020-10-14 12:47:17 --> Helper loaded: string_helper
INFO - 2020-10-14 12:47:17 --> Database Driver Class Initialized
INFO - 2020-10-14 12:47:17 --> Email Class Initialized
INFO - 2020-10-14 12:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:47:17 --> Controller Class Initialized
DEBUG - 2020-10-14 12:47:17 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:47:17 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:47:17 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:47:17 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:47:17 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:47:17 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/view_gallery.php
DEBUG - 2020-10-14 12:47:17 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:47:17 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:47:17 --> Final output sent to browser
DEBUG - 2020-10-14 12:47:17 --> Total execution time: 0.0391
INFO - 2020-10-14 12:47:21 --> Config Class Initialized
INFO - 2020-10-14 12:47:21 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:47:21 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:47:21 --> Utf8 Class Initialized
INFO - 2020-10-14 12:47:21 --> URI Class Initialized
INFO - 2020-10-14 12:47:21 --> Router Class Initialized
INFO - 2020-10-14 12:47:21 --> Output Class Initialized
INFO - 2020-10-14 12:47:21 --> Security Class Initialized
DEBUG - 2020-10-14 12:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:47:21 --> CSRF cookie sent
INFO - 2020-10-14 12:47:21 --> Input Class Initialized
INFO - 2020-10-14 12:47:21 --> Language Class Initialized
INFO - 2020-10-14 12:47:21 --> Language Class Initialized
INFO - 2020-10-14 12:47:21 --> Config Class Initialized
INFO - 2020-10-14 12:47:21 --> Loader Class Initialized
INFO - 2020-10-14 12:47:21 --> Helper loaded: url_helper
INFO - 2020-10-14 12:47:21 --> Helper loaded: file_helper
INFO - 2020-10-14 12:47:21 --> Helper loaded: string_helper
INFO - 2020-10-14 12:47:21 --> Database Driver Class Initialized
INFO - 2020-10-14 12:47:21 --> Email Class Initialized
INFO - 2020-10-14 12:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:47:21 --> Controller Class Initialized
DEBUG - 2020-10-14 12:47:21 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:47:21 --> Model "Common_model" initialized
INFO - 2020-10-14 12:47:21 --> Final output sent to browser
DEBUG - 2020-10-14 12:47:21 --> Total execution time: 0.0629
INFO - 2020-10-14 12:47:21 --> Config Class Initialized
INFO - 2020-10-14 12:47:21 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:47:21 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:47:21 --> Utf8 Class Initialized
INFO - 2020-10-14 12:47:21 --> Config Class Initialized
INFO - 2020-10-14 12:47:21 --> Hooks Class Initialized
INFO - 2020-10-14 12:47:21 --> URI Class Initialized
DEBUG - 2020-10-14 12:47:21 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:47:21 --> Utf8 Class Initialized
INFO - 2020-10-14 12:47:21 --> URI Class Initialized
INFO - 2020-10-14 12:47:21 --> Router Class Initialized
INFO - 2020-10-14 12:47:21 --> Output Class Initialized
INFO - 2020-10-14 12:47:21 --> Router Class Initialized
INFO - 2020-10-14 12:47:21 --> Security Class Initialized
INFO - 2020-10-14 12:47:21 --> Output Class Initialized
DEBUG - 2020-10-14 12:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:47:21 --> CSRF cookie sent
INFO - 2020-10-14 12:47:21 --> CSRF token verified
INFO - 2020-10-14 12:47:21 --> Input Class Initialized
INFO - 2020-10-14 12:47:21 --> Language Class Initialized
INFO - 2020-10-14 12:47:21 --> Security Class Initialized
DEBUG - 2020-10-14 12:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:47:21 --> CSRF cookie sent
INFO - 2020-10-14 12:47:21 --> CSRF token verified
INFO - 2020-10-14 12:47:21 --> Input Class Initialized
INFO - 2020-10-14 12:47:21 --> Language Class Initialized
INFO - 2020-10-14 12:47:21 --> Language Class Initialized
INFO - 2020-10-14 12:47:21 --> Config Class Initialized
INFO - 2020-10-14 12:47:21 --> Language Class Initialized
INFO - 2020-10-14 12:47:21 --> Config Class Initialized
INFO - 2020-10-14 12:47:21 --> Loader Class Initialized
INFO - 2020-10-14 12:47:21 --> Helper loaded: url_helper
INFO - 2020-10-14 12:47:21 --> Helper loaded: file_helper
INFO - 2020-10-14 12:47:21 --> Helper loaded: string_helper
INFO - 2020-10-14 12:47:21 --> Loader Class Initialized
INFO - 2020-10-14 12:47:21 --> Helper loaded: url_helper
INFO - 2020-10-14 12:47:21 --> Helper loaded: file_helper
INFO - 2020-10-14 12:47:21 --> Helper loaded: string_helper
INFO - 2020-10-14 12:47:21 --> Database Driver Class Initialized
INFO - 2020-10-14 12:47:21 --> Database Driver Class Initialized
INFO - 2020-10-14 12:47:21 --> Email Class Initialized
INFO - 2020-10-14 12:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:47:21 --> Controller Class Initialized
DEBUG - 2020-10-14 12:47:21 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:47:21 --> Model "Common_model" initialized
INFO - 2020-10-14 12:47:21 --> Email Class Initialized
INFO - 2020-10-14 12:47:21 --> Final output sent to browser
DEBUG - 2020-10-14 12:47:21 --> Total execution time: 0.0650
INFO - 2020-10-14 12:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:47:21 --> Controller Class Initialized
DEBUG - 2020-10-14 12:47:21 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:47:21 --> Model "Common_model" initialized
INFO - 2020-10-14 12:47:21 --> Final output sent to browser
DEBUG - 2020-10-14 12:47:21 --> Total execution time: 0.0668
INFO - 2020-10-14 12:47:39 --> Config Class Initialized
INFO - 2020-10-14 12:47:39 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:47:39 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:47:39 --> Utf8 Class Initialized
INFO - 2020-10-14 12:47:39 --> URI Class Initialized
INFO - 2020-10-14 12:47:39 --> Router Class Initialized
INFO - 2020-10-14 12:47:39 --> Output Class Initialized
INFO - 2020-10-14 12:47:39 --> Security Class Initialized
DEBUG - 2020-10-14 12:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:47:39 --> CSRF cookie sent
INFO - 2020-10-14 12:47:39 --> CSRF token verified
INFO - 2020-10-14 12:47:39 --> Input Class Initialized
INFO - 2020-10-14 12:47:39 --> Language Class Initialized
INFO - 2020-10-14 12:47:39 --> Language Class Initialized
INFO - 2020-10-14 12:47:39 --> Config Class Initialized
INFO - 2020-10-14 12:47:39 --> Loader Class Initialized
INFO - 2020-10-14 12:47:39 --> Helper loaded: url_helper
INFO - 2020-10-14 12:47:39 --> Helper loaded: file_helper
INFO - 2020-10-14 12:47:39 --> Helper loaded: string_helper
INFO - 2020-10-14 12:47:39 --> Database Driver Class Initialized
INFO - 2020-10-14 12:47:39 --> Email Class Initialized
INFO - 2020-10-14 12:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:47:39 --> Controller Class Initialized
DEBUG - 2020-10-14 12:47:39 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:47:39 --> Model "Common_model" initialized
INFO - 2020-10-14 12:47:39 --> Final output sent to browser
DEBUG - 2020-10-14 12:47:39 --> Total execution time: 0.0313
INFO - 2020-10-14 12:47:42 --> Config Class Initialized
INFO - 2020-10-14 12:47:42 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:47:42 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:47:42 --> Utf8 Class Initialized
INFO - 2020-10-14 12:47:42 --> URI Class Initialized
INFO - 2020-10-14 12:47:42 --> Router Class Initialized
INFO - 2020-10-14 12:47:42 --> Output Class Initialized
INFO - 2020-10-14 12:47:42 --> Security Class Initialized
DEBUG - 2020-10-14 12:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:47:42 --> CSRF cookie sent
INFO - 2020-10-14 12:47:42 --> CSRF token verified
INFO - 2020-10-14 12:47:42 --> Input Class Initialized
INFO - 2020-10-14 12:47:42 --> Language Class Initialized
INFO - 2020-10-14 12:47:42 --> Language Class Initialized
INFO - 2020-10-14 12:47:42 --> Config Class Initialized
INFO - 2020-10-14 12:47:42 --> Loader Class Initialized
INFO - 2020-10-14 12:47:42 --> Helper loaded: url_helper
INFO - 2020-10-14 12:47:42 --> Helper loaded: file_helper
INFO - 2020-10-14 12:47:42 --> Helper loaded: string_helper
INFO - 2020-10-14 12:47:42 --> Database Driver Class Initialized
INFO - 2020-10-14 12:47:42 --> Email Class Initialized
INFO - 2020-10-14 12:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:47:42 --> Controller Class Initialized
DEBUG - 2020-10-14 12:47:42 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:47:42 --> Model "Common_model" initialized
INFO - 2020-10-14 12:47:42 --> Final output sent to browser
DEBUG - 2020-10-14 12:47:42 --> Total execution time: 0.0316
INFO - 2020-10-14 12:47:51 --> Config Class Initialized
INFO - 2020-10-14 12:47:51 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:47:51 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:47:51 --> Utf8 Class Initialized
INFO - 2020-10-14 12:47:51 --> URI Class Initialized
INFO - 2020-10-14 12:47:51 --> Router Class Initialized
INFO - 2020-10-14 12:47:51 --> Output Class Initialized
INFO - 2020-10-14 12:47:51 --> Security Class Initialized
DEBUG - 2020-10-14 12:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:47:51 --> CSRF cookie sent
INFO - 2020-10-14 12:47:51 --> CSRF token verified
INFO - 2020-10-14 12:47:51 --> Input Class Initialized
INFO - 2020-10-14 12:47:51 --> Language Class Initialized
INFO - 2020-10-14 12:47:51 --> Language Class Initialized
INFO - 2020-10-14 12:47:51 --> Config Class Initialized
INFO - 2020-10-14 12:47:51 --> Loader Class Initialized
INFO - 2020-10-14 12:47:51 --> Helper loaded: url_helper
INFO - 2020-10-14 12:47:51 --> Helper loaded: file_helper
INFO - 2020-10-14 12:47:51 --> Helper loaded: string_helper
INFO - 2020-10-14 12:47:51 --> Database Driver Class Initialized
INFO - 2020-10-14 12:47:51 --> Email Class Initialized
INFO - 2020-10-14 12:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:47:51 --> Controller Class Initialized
DEBUG - 2020-10-14 12:47:51 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:47:51 --> Model "Common_model" initialized
INFO - 2020-10-14 12:47:51 --> Final output sent to browser
DEBUG - 2020-10-14 12:47:51 --> Total execution time: 0.0329
INFO - 2020-10-14 12:47:52 --> Config Class Initialized
INFO - 2020-10-14 12:47:52 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:47:52 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:47:52 --> Utf8 Class Initialized
INFO - 2020-10-14 12:47:52 --> URI Class Initialized
INFO - 2020-10-14 12:47:52 --> Router Class Initialized
INFO - 2020-10-14 12:47:52 --> Output Class Initialized
INFO - 2020-10-14 12:47:52 --> Security Class Initialized
DEBUG - 2020-10-14 12:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:47:52 --> CSRF cookie sent
INFO - 2020-10-14 12:47:52 --> CSRF token verified
INFO - 2020-10-14 12:47:52 --> Input Class Initialized
INFO - 2020-10-14 12:47:52 --> Language Class Initialized
INFO - 2020-10-14 12:47:52 --> Language Class Initialized
INFO - 2020-10-14 12:47:52 --> Config Class Initialized
INFO - 2020-10-14 12:47:52 --> Loader Class Initialized
INFO - 2020-10-14 12:47:52 --> Helper loaded: url_helper
INFO - 2020-10-14 12:47:52 --> Helper loaded: file_helper
INFO - 2020-10-14 12:47:52 --> Helper loaded: string_helper
INFO - 2020-10-14 12:47:52 --> Database Driver Class Initialized
INFO - 2020-10-14 12:47:52 --> Email Class Initialized
INFO - 2020-10-14 12:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:47:52 --> Controller Class Initialized
DEBUG - 2020-10-14 12:47:52 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:47:52 --> Model "Common_model" initialized
INFO - 2020-10-14 12:47:52 --> Final output sent to browser
DEBUG - 2020-10-14 12:47:52 --> Total execution time: 0.0327
INFO - 2020-10-14 12:47:56 --> Config Class Initialized
INFO - 2020-10-14 12:47:56 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:47:56 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:47:56 --> Utf8 Class Initialized
INFO - 2020-10-14 12:47:56 --> URI Class Initialized
INFO - 2020-10-14 12:47:56 --> Router Class Initialized
INFO - 2020-10-14 12:47:56 --> Output Class Initialized
INFO - 2020-10-14 12:47:56 --> Security Class Initialized
DEBUG - 2020-10-14 12:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:47:56 --> CSRF cookie sent
INFO - 2020-10-14 12:47:56 --> CSRF token verified
INFO - 2020-10-14 12:47:56 --> Input Class Initialized
INFO - 2020-10-14 12:47:56 --> Language Class Initialized
INFO - 2020-10-14 12:47:56 --> Language Class Initialized
INFO - 2020-10-14 12:47:56 --> Config Class Initialized
INFO - 2020-10-14 12:47:56 --> Loader Class Initialized
INFO - 2020-10-14 12:47:56 --> Helper loaded: url_helper
INFO - 2020-10-14 12:47:56 --> Helper loaded: file_helper
INFO - 2020-10-14 12:47:56 --> Helper loaded: string_helper
INFO - 2020-10-14 12:47:56 --> Database Driver Class Initialized
INFO - 2020-10-14 12:47:56 --> Email Class Initialized
INFO - 2020-10-14 12:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:47:56 --> Controller Class Initialized
DEBUG - 2020-10-14 12:47:56 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:47:56 --> Model "Common_model" initialized
INFO - 2020-10-14 12:47:56 --> Final output sent to browser
DEBUG - 2020-10-14 12:47:56 --> Total execution time: 0.0300
INFO - 2020-10-14 12:48:06 --> Config Class Initialized
INFO - 2020-10-14 12:48:06 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:48:06 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:48:06 --> Utf8 Class Initialized
INFO - 2020-10-14 12:48:06 --> URI Class Initialized
INFO - 2020-10-14 12:48:06 --> Router Class Initialized
INFO - 2020-10-14 12:48:06 --> Output Class Initialized
INFO - 2020-10-14 12:48:06 --> Security Class Initialized
DEBUG - 2020-10-14 12:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:48:06 --> CSRF cookie sent
INFO - 2020-10-14 12:48:06 --> Input Class Initialized
INFO - 2020-10-14 12:48:06 --> Language Class Initialized
INFO - 2020-10-14 12:48:06 --> Language Class Initialized
INFO - 2020-10-14 12:48:06 --> Config Class Initialized
INFO - 2020-10-14 12:48:06 --> Loader Class Initialized
INFO - 2020-10-14 12:48:06 --> Helper loaded: url_helper
INFO - 2020-10-14 12:48:06 --> Helper loaded: file_helper
INFO - 2020-10-14 12:48:06 --> Helper loaded: string_helper
INFO - 2020-10-14 12:48:06 --> Database Driver Class Initialized
INFO - 2020-10-14 12:48:06 --> Email Class Initialized
INFO - 2020-10-14 12:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:48:06 --> Controller Class Initialized
DEBUG - 2020-10-14 12:48:06 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:48:06 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:48:06 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:48:06 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:48:06 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:48:06 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/view_gallery.php
DEBUG - 2020-10-14 12:48:06 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:48:06 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:48:06 --> Final output sent to browser
DEBUG - 2020-10-14 12:48:06 --> Total execution time: 0.0351
INFO - 2020-10-14 12:49:32 --> Config Class Initialized
INFO - 2020-10-14 12:49:32 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:49:32 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:49:32 --> Utf8 Class Initialized
INFO - 2020-10-14 12:49:32 --> URI Class Initialized
INFO - 2020-10-14 12:49:32 --> Router Class Initialized
INFO - 2020-10-14 12:49:32 --> Output Class Initialized
INFO - 2020-10-14 12:49:32 --> Security Class Initialized
DEBUG - 2020-10-14 12:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:49:32 --> CSRF cookie sent
INFO - 2020-10-14 12:49:32 --> Input Class Initialized
INFO - 2020-10-14 12:49:32 --> Language Class Initialized
INFO - 2020-10-14 12:49:32 --> Language Class Initialized
INFO - 2020-10-14 12:49:32 --> Config Class Initialized
INFO - 2020-10-14 12:49:32 --> Loader Class Initialized
INFO - 2020-10-14 12:49:32 --> Helper loaded: url_helper
INFO - 2020-10-14 12:49:32 --> Helper loaded: file_helper
INFO - 2020-10-14 12:49:32 --> Helper loaded: string_helper
INFO - 2020-10-14 12:49:32 --> Database Driver Class Initialized
INFO - 2020-10-14 12:49:32 --> Email Class Initialized
INFO - 2020-10-14 12:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:49:32 --> Controller Class Initialized
DEBUG - 2020-10-14 12:49:32 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:49:32 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:49:32 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:49:32 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:49:32 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:49:32 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/make.php
DEBUG - 2020-10-14 12:49:32 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:49:32 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:49:32 --> Final output sent to browser
DEBUG - 2020-10-14 12:49:32 --> Total execution time: 0.0421
INFO - 2020-10-14 12:49:35 --> Config Class Initialized
INFO - 2020-10-14 12:49:35 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:49:35 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:49:35 --> Utf8 Class Initialized
INFO - 2020-10-14 12:49:35 --> URI Class Initialized
INFO - 2020-10-14 12:49:35 --> Router Class Initialized
INFO - 2020-10-14 12:49:35 --> Output Class Initialized
INFO - 2020-10-14 12:49:35 --> Security Class Initialized
DEBUG - 2020-10-14 12:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:49:35 --> CSRF cookie sent
INFO - 2020-10-14 12:49:35 --> Input Class Initialized
INFO - 2020-10-14 12:49:35 --> Language Class Initialized
ERROR - 2020-10-14 12:49:35 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:49:36 --> Config Class Initialized
INFO - 2020-10-14 12:49:36 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:49:36 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:49:36 --> Utf8 Class Initialized
INFO - 2020-10-14 12:49:36 --> URI Class Initialized
INFO - 2020-10-14 12:49:36 --> Router Class Initialized
INFO - 2020-10-14 12:49:36 --> Output Class Initialized
INFO - 2020-10-14 12:49:36 --> Security Class Initialized
DEBUG - 2020-10-14 12:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:49:36 --> CSRF cookie sent
INFO - 2020-10-14 12:49:36 --> CSRF token verified
INFO - 2020-10-14 12:49:36 --> Input Class Initialized
INFO - 2020-10-14 12:49:36 --> Language Class Initialized
INFO - 2020-10-14 12:49:36 --> Language Class Initialized
INFO - 2020-10-14 12:49:36 --> Config Class Initialized
INFO - 2020-10-14 12:49:36 --> Loader Class Initialized
INFO - 2020-10-14 12:49:36 --> Helper loaded: url_helper
INFO - 2020-10-14 12:49:36 --> Helper loaded: file_helper
INFO - 2020-10-14 12:49:36 --> Helper loaded: string_helper
INFO - 2020-10-14 12:49:36 --> Database Driver Class Initialized
INFO - 2020-10-14 12:49:36 --> Config Class Initialized
INFO - 2020-10-14 12:49:36 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:49:36 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:49:36 --> Utf8 Class Initialized
INFO - 2020-10-14 12:49:36 --> URI Class Initialized
INFO - 2020-10-14 12:49:36 --> Router Class Initialized
INFO - 2020-10-14 12:49:36 --> Output Class Initialized
INFO - 2020-10-14 12:49:36 --> Security Class Initialized
DEBUG - 2020-10-14 12:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:49:36 --> CSRF cookie sent
INFO - 2020-10-14 12:49:36 --> Input Class Initialized
INFO - 2020-10-14 12:49:36 --> Language Class Initialized
INFO - 2020-10-14 12:49:36 --> Language Class Initialized
INFO - 2020-10-14 12:49:36 --> Config Class Initialized
INFO - 2020-10-14 12:49:37 --> Email Class Initialized
INFO - 2020-10-14 12:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:49:37 --> Controller Class Initialized
DEBUG - 2020-10-14 12:49:37 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:49:37 --> Model "Common_model" initialized
INFO - 2020-10-14 12:49:37 --> Final output sent to browser
DEBUG - 2020-10-14 12:49:37 --> Total execution time: 0.0434
INFO - 2020-10-14 12:49:37 --> Loader Class Initialized
INFO - 2020-10-14 12:49:37 --> Helper loaded: url_helper
INFO - 2020-10-14 12:49:37 --> Helper loaded: file_helper
INFO - 2020-10-14 12:49:37 --> Helper loaded: string_helper
INFO - 2020-10-14 12:49:37 --> Database Driver Class Initialized
INFO - 2020-10-14 12:49:37 --> Email Class Initialized
INFO - 2020-10-14 12:49:37 --> Config Class Initialized
INFO - 2020-10-14 12:49:37 --> Hooks Class Initialized
INFO - 2020-10-14 12:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:49:37 --> Controller Class Initialized
DEBUG - 2020-10-14 12:49:37 --> Home MX_Controller Initialized
DEBUG - 2020-10-14 12:49:37 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:49:37 --> Utf8 Class Initialized
INFO - 2020-10-14 12:49:37 --> URI Class Initialized
INFO - 2020-10-14 12:49:37 --> Model "Common_model" initialized
INFO - 2020-10-14 12:49:37 --> Router Class Initialized
INFO - 2020-10-14 12:49:37 --> Output Class Initialized
INFO - 2020-10-14 12:49:37 --> Final output sent to browser
DEBUG - 2020-10-14 12:49:37 --> Total execution time: 0.0861
INFO - 2020-10-14 12:49:37 --> Security Class Initialized
DEBUG - 2020-10-14 12:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:49:37 --> CSRF cookie sent
INFO - 2020-10-14 12:49:37 --> CSRF token verified
INFO - 2020-10-14 12:49:37 --> Input Class Initialized
INFO - 2020-10-14 12:49:37 --> Language Class Initialized
INFO - 2020-10-14 12:49:37 --> Language Class Initialized
INFO - 2020-10-14 12:49:37 --> Config Class Initialized
INFO - 2020-10-14 12:49:37 --> Loader Class Initialized
INFO - 2020-10-14 12:49:37 --> Helper loaded: url_helper
INFO - 2020-10-14 12:49:37 --> Helper loaded: file_helper
INFO - 2020-10-14 12:49:37 --> Helper loaded: string_helper
INFO - 2020-10-14 12:49:37 --> Database Driver Class Initialized
INFO - 2020-10-14 12:49:37 --> Email Class Initialized
INFO - 2020-10-14 12:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:49:37 --> Controller Class Initialized
DEBUG - 2020-10-14 12:49:37 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:49:37 --> Model "Common_model" initialized
INFO - 2020-10-14 12:49:37 --> Final output sent to browser
DEBUG - 2020-10-14 12:49:37 --> Total execution time: 0.0324
INFO - 2020-10-14 12:49:59 --> Config Class Initialized
INFO - 2020-10-14 12:49:59 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:49:59 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:49:59 --> Utf8 Class Initialized
INFO - 2020-10-14 12:49:59 --> URI Class Initialized
INFO - 2020-10-14 12:49:59 --> Router Class Initialized
INFO - 2020-10-14 12:49:59 --> Output Class Initialized
INFO - 2020-10-14 12:49:59 --> Security Class Initialized
DEBUG - 2020-10-14 12:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:49:59 --> CSRF cookie sent
INFO - 2020-10-14 12:49:59 --> Input Class Initialized
INFO - 2020-10-14 12:49:59 --> Language Class Initialized
ERROR - 2020-10-14 12:49:59 --> 404 Page Not Found: /index
INFO - 2020-10-14 12:50:55 --> Config Class Initialized
INFO - 2020-10-14 12:50:55 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:50:55 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:50:55 --> Utf8 Class Initialized
INFO - 2020-10-14 12:50:55 --> URI Class Initialized
INFO - 2020-10-14 12:50:55 --> Router Class Initialized
INFO - 2020-10-14 12:50:55 --> Output Class Initialized
INFO - 2020-10-14 12:50:55 --> Security Class Initialized
DEBUG - 2020-10-14 12:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:50:55 --> CSRF cookie sent
INFO - 2020-10-14 12:50:55 --> Input Class Initialized
INFO - 2020-10-14 12:50:55 --> Language Class Initialized
INFO - 2020-10-14 12:50:55 --> Language Class Initialized
INFO - 2020-10-14 12:50:55 --> Config Class Initialized
INFO - 2020-10-14 12:50:55 --> Loader Class Initialized
INFO - 2020-10-14 12:50:55 --> Helper loaded: url_helper
INFO - 2020-10-14 12:50:55 --> Helper loaded: file_helper
INFO - 2020-10-14 12:50:55 --> Helper loaded: string_helper
INFO - 2020-10-14 12:50:55 --> Database Driver Class Initialized
INFO - 2020-10-14 12:50:55 --> Email Class Initialized
INFO - 2020-10-14 12:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:50:55 --> Controller Class Initialized
DEBUG - 2020-10-14 12:50:55 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:50:55 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:50:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:50:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:50:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/mobile_view_links.php
DEBUG - 2020-10-14 12:50:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:50:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/place.php
DEBUG - 2020-10-14 12:50:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:50:55 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:50:55 --> Final output sent to browser
DEBUG - 2020-10-14 12:50:55 --> Total execution time: 0.0419
INFO - 2020-10-14 12:50:59 --> Config Class Initialized
INFO - 2020-10-14 12:50:59 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:50:59 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:50:59 --> Utf8 Class Initialized
INFO - 2020-10-14 12:50:59 --> URI Class Initialized
INFO - 2020-10-14 12:50:59 --> Router Class Initialized
INFO - 2020-10-14 12:50:59 --> Output Class Initialized
INFO - 2020-10-14 12:50:59 --> Security Class Initialized
DEBUG - 2020-10-14 12:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:50:59 --> CSRF cookie sent
INFO - 2020-10-14 12:50:59 --> Input Class Initialized
INFO - 2020-10-14 12:50:59 --> Language Class Initialized
INFO - 2020-10-14 12:50:59 --> Language Class Initialized
INFO - 2020-10-14 12:50:59 --> Config Class Initialized
INFO - 2020-10-14 12:50:59 --> Loader Class Initialized
INFO - 2020-10-14 12:50:59 --> Helper loaded: url_helper
INFO - 2020-10-14 12:50:59 --> Helper loaded: file_helper
INFO - 2020-10-14 12:50:59 --> Helper loaded: string_helper
INFO - 2020-10-14 12:50:59 --> Database Driver Class Initialized
INFO - 2020-10-14 12:50:59 --> Email Class Initialized
INFO - 2020-10-14 12:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:50:59 --> Controller Class Initialized
DEBUG - 2020-10-14 12:50:59 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:50:59 --> Model "Common_model" initialized
INFO - 2020-10-14 12:50:59 --> Config Class Initialized
INFO - 2020-10-14 12:50:59 --> Hooks Class Initialized
INFO - 2020-10-14 12:50:59 --> Final output sent to browser
DEBUG - 2020-10-14 12:50:59 --> Total execution time: 0.0732
DEBUG - 2020-10-14 12:50:59 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:50:59 --> Utf8 Class Initialized
INFO - 2020-10-14 12:50:59 --> URI Class Initialized
INFO - 2020-10-14 12:50:59 --> Router Class Initialized
INFO - 2020-10-14 12:50:59 --> Output Class Initialized
INFO - 2020-10-14 12:50:59 --> Security Class Initialized
DEBUG - 2020-10-14 12:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:50:59 --> CSRF cookie sent
INFO - 2020-10-14 12:50:59 --> CSRF token verified
INFO - 2020-10-14 12:50:59 --> Input Class Initialized
INFO - 2020-10-14 12:50:59 --> Language Class Initialized
INFO - 2020-10-14 12:50:59 --> Config Class Initialized
INFO - 2020-10-14 12:50:59 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:50:59 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:50:59 --> Utf8 Class Initialized
INFO - 2020-10-14 12:50:59 --> URI Class Initialized
INFO - 2020-10-14 12:50:59 --> Router Class Initialized
INFO - 2020-10-14 12:50:59 --> Output Class Initialized
INFO - 2020-10-14 12:50:59 --> Security Class Initialized
INFO - 2020-10-14 12:50:59 --> Language Class Initialized
INFO - 2020-10-14 12:50:59 --> Config Class Initialized
DEBUG - 2020-10-14 12:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:50:59 --> CSRF cookie sent
INFO - 2020-10-14 12:50:59 --> CSRF token verified
INFO - 2020-10-14 12:50:59 --> Input Class Initialized
INFO - 2020-10-14 12:50:59 --> Language Class Initialized
INFO - 2020-10-14 12:50:59 --> Loader Class Initialized
INFO - 2020-10-14 12:50:59 --> Helper loaded: url_helper
INFO - 2020-10-14 12:50:59 --> Helper loaded: file_helper
INFO - 2020-10-14 12:50:59 --> Language Class Initialized
INFO - 2020-10-14 12:50:59 --> Helper loaded: string_helper
INFO - 2020-10-14 12:50:59 --> Config Class Initialized
INFO - 2020-10-14 12:50:59 --> Loader Class Initialized
INFO - 2020-10-14 12:50:59 --> Helper loaded: url_helper
INFO - 2020-10-14 12:50:59 --> Helper loaded: file_helper
INFO - 2020-10-14 12:50:59 --> Helper loaded: string_helper
INFO - 2020-10-14 12:50:59 --> Database Driver Class Initialized
INFO - 2020-10-14 12:50:59 --> Database Driver Class Initialized
INFO - 2020-10-14 12:50:59 --> Email Class Initialized
INFO - 2020-10-14 12:50:59 --> Email Class Initialized
INFO - 2020-10-14 12:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:50:59 --> Controller Class Initialized
DEBUG - 2020-10-14 12:50:59 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:50:59 --> Model "Common_model" initialized
INFO - 2020-10-14 12:50:59 --> Final output sent to browser
DEBUG - 2020-10-14 12:50:59 --> Total execution time: 0.0298
INFO - 2020-10-14 12:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:50:59 --> Controller Class Initialized
DEBUG - 2020-10-14 12:50:59 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:50:59 --> Model "Common_model" initialized
INFO - 2020-10-14 12:50:59 --> Final output sent to browser
DEBUG - 2020-10-14 12:50:59 --> Total execution time: 0.0477
INFO - 2020-10-14 12:51:10 --> Config Class Initialized
INFO - 2020-10-14 12:51:10 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:51:10 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:51:10 --> Utf8 Class Initialized
INFO - 2020-10-14 12:51:10 --> URI Class Initialized
INFO - 2020-10-14 12:51:10 --> Router Class Initialized
INFO - 2020-10-14 12:51:10 --> Output Class Initialized
INFO - 2020-10-14 12:51:10 --> Security Class Initialized
DEBUG - 2020-10-14 12:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:51:10 --> CSRF cookie sent
INFO - 2020-10-14 12:51:10 --> Input Class Initialized
INFO - 2020-10-14 12:51:10 --> Language Class Initialized
INFO - 2020-10-14 12:51:10 --> Language Class Initialized
INFO - 2020-10-14 12:51:10 --> Config Class Initialized
INFO - 2020-10-14 12:51:10 --> Loader Class Initialized
INFO - 2020-10-14 12:51:10 --> Helper loaded: url_helper
INFO - 2020-10-14 12:51:10 --> Helper loaded: file_helper
INFO - 2020-10-14 12:51:10 --> Helper loaded: string_helper
INFO - 2020-10-14 12:51:10 --> Database Driver Class Initialized
INFO - 2020-10-14 12:51:10 --> Email Class Initialized
INFO - 2020-10-14 12:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:51:10 --> Controller Class Initialized
DEBUG - 2020-10-14 12:51:10 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:51:10 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:51:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:51:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:51:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:51:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/step_4.php
DEBUG - 2020-10-14 12:51:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:51:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:51:10 --> Final output sent to browser
DEBUG - 2020-10-14 12:51:10 --> Total execution time: 0.0361
INFO - 2020-10-14 12:51:14 --> Config Class Initialized
INFO - 2020-10-14 12:51:14 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:51:14 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:51:14 --> Utf8 Class Initialized
INFO - 2020-10-14 12:51:14 --> URI Class Initialized
INFO - 2020-10-14 12:51:14 --> Router Class Initialized
INFO - 2020-10-14 12:51:14 --> Output Class Initialized
INFO - 2020-10-14 12:51:14 --> Security Class Initialized
DEBUG - 2020-10-14 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:51:14 --> CSRF cookie sent
INFO - 2020-10-14 12:51:14 --> CSRF token verified
INFO - 2020-10-14 12:51:14 --> Input Class Initialized
INFO - 2020-10-14 12:51:14 --> Language Class Initialized
INFO - 2020-10-14 12:51:14 --> Language Class Initialized
INFO - 2020-10-14 12:51:14 --> Config Class Initialized
INFO - 2020-10-14 12:51:14 --> Loader Class Initialized
INFO - 2020-10-14 12:51:14 --> Helper loaded: url_helper
INFO - 2020-10-14 12:51:14 --> Helper loaded: file_helper
INFO - 2020-10-14 12:51:14 --> Helper loaded: string_helper
INFO - 2020-10-14 12:51:14 --> Database Driver Class Initialized
INFO - 2020-10-14 12:51:14 --> Email Class Initialized
INFO - 2020-10-14 12:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:51:14 --> Controller Class Initialized
DEBUG - 2020-10-14 12:51:14 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:51:14 --> Model "Common_model" initialized
INFO - 2020-10-14 12:51:14 --> Final output sent to browser
DEBUG - 2020-10-14 12:51:14 --> Total execution time: 0.0289
INFO - 2020-10-14 12:51:14 --> Config Class Initialized
INFO - 2020-10-14 12:51:14 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:51:14 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:51:14 --> Utf8 Class Initialized
INFO - 2020-10-14 12:51:14 --> URI Class Initialized
INFO - 2020-10-14 12:51:14 --> Router Class Initialized
INFO - 2020-10-14 12:51:14 --> Output Class Initialized
INFO - 2020-10-14 12:51:14 --> Security Class Initialized
DEBUG - 2020-10-14 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:51:14 --> CSRF cookie sent
INFO - 2020-10-14 12:51:14 --> CSRF token verified
INFO - 2020-10-14 12:51:14 --> Input Class Initialized
INFO - 2020-10-14 12:51:14 --> Language Class Initialized
INFO - 2020-10-14 12:51:14 --> Language Class Initialized
INFO - 2020-10-14 12:51:14 --> Config Class Initialized
INFO - 2020-10-14 12:51:14 --> Loader Class Initialized
INFO - 2020-10-14 12:51:14 --> Helper loaded: url_helper
INFO - 2020-10-14 12:51:14 --> Helper loaded: file_helper
INFO - 2020-10-14 12:51:14 --> Helper loaded: string_helper
INFO - 2020-10-14 12:51:14 --> Database Driver Class Initialized
INFO - 2020-10-14 12:51:14 --> Email Class Initialized
INFO - 2020-10-14 12:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:51:14 --> Controller Class Initialized
DEBUG - 2020-10-14 12:51:14 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:51:14 --> Model "Common_model" initialized
INFO - 2020-10-14 12:51:14 --> Final output sent to browser
DEBUG - 2020-10-14 12:51:14 --> Total execution time: 0.0299
INFO - 2020-10-14 12:51:15 --> Config Class Initialized
INFO - 2020-10-14 12:51:15 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:51:15 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:51:15 --> Utf8 Class Initialized
INFO - 2020-10-14 12:51:15 --> URI Class Initialized
INFO - 2020-10-14 12:51:15 --> Router Class Initialized
INFO - 2020-10-14 12:51:15 --> Output Class Initialized
INFO - 2020-10-14 12:51:15 --> Security Class Initialized
DEBUG - 2020-10-14 12:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:51:15 --> CSRF cookie sent
INFO - 2020-10-14 12:51:15 --> Input Class Initialized
INFO - 2020-10-14 12:51:15 --> Language Class Initialized
INFO - 2020-10-14 12:51:15 --> Language Class Initialized
INFO - 2020-10-14 12:51:15 --> Config Class Initialized
INFO - 2020-10-14 12:51:15 --> Loader Class Initialized
INFO - 2020-10-14 12:51:15 --> Helper loaded: url_helper
INFO - 2020-10-14 12:51:15 --> Helper loaded: file_helper
INFO - 2020-10-14 12:51:15 --> Helper loaded: string_helper
INFO - 2020-10-14 12:51:15 --> Database Driver Class Initialized
INFO - 2020-10-14 12:51:15 --> Email Class Initialized
INFO - 2020-10-14 12:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:51:15 --> Controller Class Initialized
DEBUG - 2020-10-14 12:51:15 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:51:15 --> Model "Common_model" initialized
INFO - 2020-10-14 12:51:15 --> Final output sent to browser
DEBUG - 2020-10-14 12:51:15 --> Total execution time: 0.0345
INFO - 2020-10-14 12:51:19 --> Config Class Initialized
INFO - 2020-10-14 12:51:19 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:51:19 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:51:19 --> Utf8 Class Initialized
INFO - 2020-10-14 12:51:19 --> URI Class Initialized
INFO - 2020-10-14 12:51:19 --> Router Class Initialized
INFO - 2020-10-14 12:51:19 --> Output Class Initialized
INFO - 2020-10-14 12:51:19 --> Security Class Initialized
DEBUG - 2020-10-14 12:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:51:19 --> CSRF cookie sent
INFO - 2020-10-14 12:51:19 --> CSRF token verified
INFO - 2020-10-14 12:51:19 --> Input Class Initialized
INFO - 2020-10-14 12:51:19 --> Language Class Initialized
INFO - 2020-10-14 12:51:19 --> Language Class Initialized
INFO - 2020-10-14 12:51:19 --> Config Class Initialized
INFO - 2020-10-14 12:51:19 --> Loader Class Initialized
INFO - 2020-10-14 12:51:19 --> Helper loaded: url_helper
INFO - 2020-10-14 12:51:19 --> Helper loaded: file_helper
INFO - 2020-10-14 12:51:19 --> Helper loaded: string_helper
INFO - 2020-10-14 12:51:19 --> Database Driver Class Initialized
INFO - 2020-10-14 12:51:19 --> Email Class Initialized
INFO - 2020-10-14 12:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:51:19 --> Controller Class Initialized
DEBUG - 2020-10-14 12:51:19 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:51:19 --> Model "Common_model" initialized
INFO - 2020-10-14 12:51:19 --> Final output sent to browser
DEBUG - 2020-10-14 12:51:19 --> Total execution time: 0.0333
INFO - 2020-10-14 12:51:20 --> Config Class Initialized
INFO - 2020-10-14 12:51:20 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:51:20 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:51:20 --> Utf8 Class Initialized
INFO - 2020-10-14 12:51:20 --> URI Class Initialized
INFO - 2020-10-14 12:51:20 --> Router Class Initialized
INFO - 2020-10-14 12:51:20 --> Output Class Initialized
INFO - 2020-10-14 12:51:20 --> Security Class Initialized
DEBUG - 2020-10-14 12:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:51:20 --> CSRF cookie sent
INFO - 2020-10-14 12:51:20 --> CSRF token verified
INFO - 2020-10-14 12:51:20 --> Input Class Initialized
INFO - 2020-10-14 12:51:20 --> Language Class Initialized
INFO - 2020-10-14 12:51:20 --> Language Class Initialized
INFO - 2020-10-14 12:51:20 --> Config Class Initialized
INFO - 2020-10-14 12:51:20 --> Loader Class Initialized
INFO - 2020-10-14 12:51:20 --> Helper loaded: url_helper
INFO - 2020-10-14 12:51:20 --> Helper loaded: file_helper
INFO - 2020-10-14 12:51:20 --> Helper loaded: string_helper
INFO - 2020-10-14 12:51:20 --> Database Driver Class Initialized
INFO - 2020-10-14 12:51:20 --> Email Class Initialized
INFO - 2020-10-14 12:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:51:20 --> Controller Class Initialized
DEBUG - 2020-10-14 12:51:20 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:51:20 --> Model "Common_model" initialized
INFO - 2020-10-14 12:51:20 --> Final output sent to browser
DEBUG - 2020-10-14 12:51:20 --> Total execution time: 0.0340
INFO - 2020-10-14 12:58:59 --> Config Class Initialized
INFO - 2020-10-14 12:58:59 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:58:59 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:58:59 --> Utf8 Class Initialized
INFO - 2020-10-14 12:58:59 --> URI Class Initialized
INFO - 2020-10-14 12:58:59 --> Router Class Initialized
INFO - 2020-10-14 12:58:59 --> Output Class Initialized
INFO - 2020-10-14 12:58:59 --> Security Class Initialized
DEBUG - 2020-10-14 12:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:58:59 --> CSRF cookie sent
INFO - 2020-10-14 12:58:59 --> Input Class Initialized
INFO - 2020-10-14 12:58:59 --> Language Class Initialized
INFO - 2020-10-14 12:58:59 --> Language Class Initialized
INFO - 2020-10-14 12:58:59 --> Config Class Initialized
INFO - 2020-10-14 12:58:59 --> Loader Class Initialized
INFO - 2020-10-14 12:58:59 --> Helper loaded: url_helper
INFO - 2020-10-14 12:58:59 --> Helper loaded: file_helper
INFO - 2020-10-14 12:58:59 --> Helper loaded: string_helper
INFO - 2020-10-14 12:58:59 --> Database Driver Class Initialized
INFO - 2020-10-14 12:58:59 --> Email Class Initialized
INFO - 2020-10-14 12:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:58:59 --> Controller Class Initialized
DEBUG - 2020-10-14 12:58:59 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:58:59 --> Model "Common_model" initialized
DEBUG - 2020-10-14 12:58:59 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:58:59 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 12:58:59 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 12:58:59 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/step_4.php
DEBUG - 2020-10-14 12:58:59 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 12:58:59 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 12:58:59 --> Final output sent to browser
DEBUG - 2020-10-14 12:58:59 --> Total execution time: 0.0498
INFO - 2020-10-14 12:59:02 --> Config Class Initialized
INFO - 2020-10-14 12:59:02 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:59:02 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:59:02 --> Utf8 Class Initialized
INFO - 2020-10-14 12:59:02 --> URI Class Initialized
INFO - 2020-10-14 12:59:02 --> Router Class Initialized
INFO - 2020-10-14 12:59:02 --> Output Class Initialized
INFO - 2020-10-14 12:59:02 --> Security Class Initialized
DEBUG - 2020-10-14 12:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:59:02 --> CSRF cookie sent
INFO - 2020-10-14 12:59:02 --> CSRF token verified
INFO - 2020-10-14 12:59:02 --> Input Class Initialized
INFO - 2020-10-14 12:59:02 --> Language Class Initialized
INFO - 2020-10-14 12:59:02 --> Language Class Initialized
INFO - 2020-10-14 12:59:02 --> Config Class Initialized
INFO - 2020-10-14 12:59:02 --> Loader Class Initialized
INFO - 2020-10-14 12:59:02 --> Helper loaded: url_helper
INFO - 2020-10-14 12:59:02 --> Helper loaded: file_helper
INFO - 2020-10-14 12:59:02 --> Helper loaded: string_helper
INFO - 2020-10-14 12:59:02 --> Database Driver Class Initialized
INFO - 2020-10-14 12:59:02 --> Config Class Initialized
INFO - 2020-10-14 12:59:02 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:59:02 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:59:02 --> Utf8 Class Initialized
INFO - 2020-10-14 12:59:02 --> URI Class Initialized
INFO - 2020-10-14 12:59:02 --> Email Class Initialized
INFO - 2020-10-14 12:59:02 --> Config Class Initialized
INFO - 2020-10-14 12:59:02 --> Hooks Class Initialized
INFO - 2020-10-14 12:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:59:02 --> Controller Class Initialized
DEBUG - 2020-10-14 12:59:02 --> Home MX_Controller Initialized
DEBUG - 2020-10-14 12:59:02 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:59:02 --> Utf8 Class Initialized
INFO - 2020-10-14 12:59:02 --> URI Class Initialized
INFO - 2020-10-14 12:59:02 --> Model "Common_model" initialized
INFO - 2020-10-14 12:59:02 --> Router Class Initialized
INFO - 2020-10-14 12:59:02 --> Router Class Initialized
INFO - 2020-10-14 12:59:02 --> Output Class Initialized
INFO - 2020-10-14 12:59:02 --> Output Class Initialized
INFO - 2020-10-14 12:59:02 --> Security Class Initialized
INFO - 2020-10-14 12:59:02 --> Security Class Initialized
DEBUG - 2020-10-14 12:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:59:02 --> CSRF cookie sent
INFO - 2020-10-14 12:59:02 --> CSRF token verified
INFO - 2020-10-14 12:59:02 --> Input Class Initialized
INFO - 2020-10-14 12:59:02 --> Language Class Initialized
DEBUG - 2020-10-14 12:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:59:02 --> CSRF cookie sent
INFO - 2020-10-14 12:59:02 --> Input Class Initialized
INFO - 2020-10-14 12:59:02 --> Language Class Initialized
INFO - 2020-10-14 12:59:02 --> Language Class Initialized
INFO - 2020-10-14 12:59:02 --> Config Class Initialized
INFO - 2020-10-14 12:59:02 --> Language Class Initialized
INFO - 2020-10-14 12:59:02 --> Config Class Initialized
INFO - 2020-10-14 12:59:02 --> Loader Class Initialized
INFO - 2020-10-14 12:59:02 --> Loader Class Initialized
INFO - 2020-10-14 12:59:02 --> Helper loaded: url_helper
INFO - 2020-10-14 12:59:02 --> Helper loaded: file_helper
INFO - 2020-10-14 12:59:02 --> Helper loaded: string_helper
INFO - 2020-10-14 12:59:02 --> Helper loaded: url_helper
INFO - 2020-10-14 12:59:02 --> Helper loaded: file_helper
INFO - 2020-10-14 12:59:02 --> Helper loaded: string_helper
INFO - 2020-10-14 12:59:02 --> Final output sent to browser
DEBUG - 2020-10-14 12:59:02 --> Total execution time: 0.0889
INFO - 2020-10-14 12:59:02 --> Database Driver Class Initialized
INFO - 2020-10-14 12:59:02 --> Email Class Initialized
INFO - 2020-10-14 12:59:02 --> Database Driver Class Initialized
INFO - 2020-10-14 12:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:59:02 --> Controller Class Initialized
DEBUG - 2020-10-14 12:59:02 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:59:02 --> Model "Common_model" initialized
INFO - 2020-10-14 12:59:02 --> Email Class Initialized
INFO - 2020-10-14 12:59:02 --> Final output sent to browser
DEBUG - 2020-10-14 12:59:02 --> Total execution time: 0.0302
INFO - 2020-10-14 12:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:59:02 --> Controller Class Initialized
DEBUG - 2020-10-14 12:59:02 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:59:02 --> Model "Common_model" initialized
INFO - 2020-10-14 12:59:02 --> Final output sent to browser
DEBUG - 2020-10-14 12:59:02 --> Total execution time: 0.0816
INFO - 2020-10-14 12:59:11 --> Config Class Initialized
INFO - 2020-10-14 12:59:11 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:59:11 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:59:11 --> Utf8 Class Initialized
INFO - 2020-10-14 12:59:11 --> URI Class Initialized
INFO - 2020-10-14 12:59:11 --> Router Class Initialized
INFO - 2020-10-14 12:59:11 --> Output Class Initialized
INFO - 2020-10-14 12:59:11 --> Security Class Initialized
DEBUG - 2020-10-14 12:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:59:11 --> CSRF cookie sent
INFO - 2020-10-14 12:59:11 --> CSRF token verified
INFO - 2020-10-14 12:59:11 --> Input Class Initialized
INFO - 2020-10-14 12:59:11 --> Language Class Initialized
INFO - 2020-10-14 12:59:11 --> Language Class Initialized
INFO - 2020-10-14 12:59:11 --> Config Class Initialized
INFO - 2020-10-14 12:59:11 --> Loader Class Initialized
INFO - 2020-10-14 12:59:11 --> Helper loaded: url_helper
INFO - 2020-10-14 12:59:11 --> Helper loaded: file_helper
INFO - 2020-10-14 12:59:11 --> Helper loaded: string_helper
INFO - 2020-10-14 12:59:11 --> Database Driver Class Initialized
INFO - 2020-10-14 12:59:11 --> Email Class Initialized
INFO - 2020-10-14 12:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:59:11 --> Controller Class Initialized
DEBUG - 2020-10-14 12:59:11 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:59:11 --> Model "Common_model" initialized
INFO - 2020-10-14 12:59:11 --> Final output sent to browser
DEBUG - 2020-10-14 12:59:11 --> Total execution time: 0.0347
INFO - 2020-10-14 12:59:11 --> Config Class Initialized
INFO - 2020-10-14 12:59:11 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:59:11 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:59:11 --> Utf8 Class Initialized
INFO - 2020-10-14 12:59:11 --> URI Class Initialized
INFO - 2020-10-14 12:59:11 --> Router Class Initialized
INFO - 2020-10-14 12:59:11 --> Output Class Initialized
INFO - 2020-10-14 12:59:11 --> Security Class Initialized
DEBUG - 2020-10-14 12:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:59:11 --> CSRF cookie sent
INFO - 2020-10-14 12:59:11 --> CSRF token verified
INFO - 2020-10-14 12:59:11 --> Input Class Initialized
INFO - 2020-10-14 12:59:11 --> Language Class Initialized
INFO - 2020-10-14 12:59:11 --> Language Class Initialized
INFO - 2020-10-14 12:59:11 --> Config Class Initialized
INFO - 2020-10-14 12:59:11 --> Loader Class Initialized
INFO - 2020-10-14 12:59:11 --> Helper loaded: url_helper
INFO - 2020-10-14 12:59:11 --> Helper loaded: file_helper
INFO - 2020-10-14 12:59:11 --> Helper loaded: string_helper
INFO - 2020-10-14 12:59:11 --> Database Driver Class Initialized
INFO - 2020-10-14 12:59:11 --> Email Class Initialized
INFO - 2020-10-14 12:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:59:11 --> Controller Class Initialized
DEBUG - 2020-10-14 12:59:11 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:59:11 --> Model "Common_model" initialized
INFO - 2020-10-14 12:59:11 --> Final output sent to browser
DEBUG - 2020-10-14 12:59:11 --> Total execution time: 0.0299
INFO - 2020-10-14 12:59:16 --> Config Class Initialized
INFO - 2020-10-14 12:59:16 --> Hooks Class Initialized
DEBUG - 2020-10-14 12:59:16 --> UTF-8 Support Enabled
INFO - 2020-10-14 12:59:16 --> Utf8 Class Initialized
INFO - 2020-10-14 12:59:16 --> URI Class Initialized
INFO - 2020-10-14 12:59:16 --> Router Class Initialized
INFO - 2020-10-14 12:59:16 --> Output Class Initialized
INFO - 2020-10-14 12:59:16 --> Security Class Initialized
DEBUG - 2020-10-14 12:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 12:59:16 --> CSRF cookie sent
INFO - 2020-10-14 12:59:16 --> CSRF token verified
INFO - 2020-10-14 12:59:16 --> Input Class Initialized
INFO - 2020-10-14 12:59:16 --> Language Class Initialized
INFO - 2020-10-14 12:59:16 --> Language Class Initialized
INFO - 2020-10-14 12:59:16 --> Config Class Initialized
INFO - 2020-10-14 12:59:16 --> Loader Class Initialized
INFO - 2020-10-14 12:59:16 --> Helper loaded: url_helper
INFO - 2020-10-14 12:59:16 --> Helper loaded: file_helper
INFO - 2020-10-14 12:59:16 --> Helper loaded: string_helper
INFO - 2020-10-14 12:59:16 --> Database Driver Class Initialized
INFO - 2020-10-14 12:59:16 --> Email Class Initialized
INFO - 2020-10-14 12:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 12:59:16 --> Controller Class Initialized
DEBUG - 2020-10-14 12:59:16 --> Home MX_Controller Initialized
INFO - 2020-10-14 12:59:16 --> Model "Common_model" initialized
INFO - 2020-10-14 12:59:16 --> Language file loaded: language/english/email_lang.php
INFO - 2020-10-14 12:59:16 --> Final output sent to browser
DEBUG - 2020-10-14 12:59:16 --> Total execution time: 0.1789
INFO - 2020-10-14 13:03:10 --> Config Class Initialized
INFO - 2020-10-14 13:03:10 --> Hooks Class Initialized
DEBUG - 2020-10-14 13:03:10 --> UTF-8 Support Enabled
INFO - 2020-10-14 13:03:10 --> Utf8 Class Initialized
INFO - 2020-10-14 13:03:10 --> URI Class Initialized
INFO - 2020-10-14 13:03:10 --> Router Class Initialized
INFO - 2020-10-14 13:03:10 --> Output Class Initialized
INFO - 2020-10-14 13:03:10 --> Security Class Initialized
DEBUG - 2020-10-14 13:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 13:03:10 --> CSRF cookie sent
INFO - 2020-10-14 13:03:10 --> Input Class Initialized
INFO - 2020-10-14 13:03:10 --> Language Class Initialized
INFO - 2020-10-14 13:03:10 --> Language Class Initialized
INFO - 2020-10-14 13:03:10 --> Config Class Initialized
INFO - 2020-10-14 13:03:10 --> Loader Class Initialized
INFO - 2020-10-14 13:03:10 --> Helper loaded: url_helper
INFO - 2020-10-14 13:03:10 --> Helper loaded: file_helper
INFO - 2020-10-14 13:03:10 --> Helper loaded: string_helper
INFO - 2020-10-14 13:03:10 --> Database Driver Class Initialized
INFO - 2020-10-14 13:03:10 --> Email Class Initialized
INFO - 2020-10-14 13:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 13:03:10 --> Controller Class Initialized
DEBUG - 2020-10-14 13:03:10 --> Home MX_Controller Initialized
INFO - 2020-10-14 13:03:10 --> Model "Common_model" initialized
INFO - 2020-10-14 13:03:10 --> Config Class Initialized
INFO - 2020-10-14 13:03:10 --> Hooks Class Initialized
DEBUG - 2020-10-14 13:03:10 --> UTF-8 Support Enabled
INFO - 2020-10-14 13:03:10 --> Utf8 Class Initialized
INFO - 2020-10-14 13:03:10 --> URI Class Initialized
INFO - 2020-10-14 13:03:10 --> Router Class Initialized
INFO - 2020-10-14 13:03:10 --> Output Class Initialized
INFO - 2020-10-14 13:03:10 --> Security Class Initialized
DEBUG - 2020-10-14 13:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 13:03:10 --> CSRF cookie sent
INFO - 2020-10-14 13:03:10 --> Input Class Initialized
INFO - 2020-10-14 13:03:10 --> Language Class Initialized
INFO - 2020-10-14 13:03:10 --> Language Class Initialized
INFO - 2020-10-14 13:03:10 --> Config Class Initialized
INFO - 2020-10-14 13:03:10 --> Loader Class Initialized
INFO - 2020-10-14 13:03:10 --> Helper loaded: url_helper
INFO - 2020-10-14 13:03:10 --> Helper loaded: file_helper
INFO - 2020-10-14 13:03:10 --> Helper loaded: string_helper
INFO - 2020-10-14 13:03:10 --> Database Driver Class Initialized
INFO - 2020-10-14 13:03:10 --> Email Class Initialized
INFO - 2020-10-14 13:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 13:03:10 --> Controller Class Initialized
DEBUG - 2020-10-14 13:03:10 --> Home MX_Controller Initialized
INFO - 2020-10-14 13:03:10 --> Model "Common_model" initialized
DEBUG - 2020-10-14 13:03:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 13:03:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/header_new.php
DEBUG - 2020-10-14 13:03:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/login_reg_form.php
DEBUG - 2020-10-14 13:03:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/home.php
DEBUG - 2020-10-14 13:03:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/modules/Home/views/desktop_view_links.php
DEBUG - 2020-10-14 13:03:10 --> File loaded: /home/dinof2/public_html/color-innovator/application/views/home/footer_new.php
INFO - 2020-10-14 13:03:10 --> Final output sent to browser
DEBUG - 2020-10-14 13:03:10 --> Total execution time: 0.0308
INFO - 2020-10-14 13:03:14 --> Config Class Initialized
INFO - 2020-10-14 13:03:14 --> Hooks Class Initialized
DEBUG - 2020-10-14 13:03:14 --> UTF-8 Support Enabled
INFO - 2020-10-14 13:03:14 --> Utf8 Class Initialized
INFO - 2020-10-14 13:03:14 --> URI Class Initialized
INFO - 2020-10-14 13:03:14 --> Router Class Initialized
INFO - 2020-10-14 13:03:14 --> Output Class Initialized
INFO - 2020-10-14 13:03:14 --> Security Class Initialized
DEBUG - 2020-10-14 13:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 13:03:14 --> CSRF cookie sent
INFO - 2020-10-14 13:03:14 --> Input Class Initialized
INFO - 2020-10-14 13:03:14 --> Language Class Initialized
INFO - 2020-10-14 13:03:14 --> Language Class Initialized
INFO - 2020-10-14 13:03:14 --> Config Class Initialized
INFO - 2020-10-14 13:03:14 --> Loader Class Initialized
INFO - 2020-10-14 13:03:14 --> Helper loaded: url_helper
INFO - 2020-10-14 13:03:14 --> Helper loaded: file_helper
INFO - 2020-10-14 13:03:14 --> Helper loaded: string_helper
INFO - 2020-10-14 13:03:14 --> Database Driver Class Initialized
INFO - 2020-10-14 13:03:14 --> Email Class Initialized
INFO - 2020-10-14 13:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 13:03:14 --> Controller Class Initialized
DEBUG - 2020-10-14 13:03:14 --> Home MX_Controller Initialized
INFO - 2020-10-14 13:03:14 --> Model "Common_model" initialized
INFO - 2020-10-14 13:03:14 --> Config Class Initialized
INFO - 2020-10-14 13:03:14 --> Hooks Class Initialized
DEBUG - 2020-10-14 13:03:14 --> UTF-8 Support Enabled
INFO - 2020-10-14 13:03:14 --> Utf8 Class Initialized
INFO - 2020-10-14 13:03:14 --> URI Class Initialized
INFO - 2020-10-14 13:03:14 --> Config Class Initialized
INFO - 2020-10-14 13:03:14 --> Hooks Class Initialized
INFO - 2020-10-14 13:03:14 --> Router Class Initialized
DEBUG - 2020-10-14 13:03:14 --> UTF-8 Support Enabled
INFO - 2020-10-14 13:03:14 --> Utf8 Class Initialized
INFO - 2020-10-14 13:03:14 --> Output Class Initialized
INFO - 2020-10-14 13:03:14 --> URI Class Initialized
INFO - 2020-10-14 13:03:14 --> Final output sent to browser
DEBUG - 2020-10-14 13:03:14 --> Total execution time: 0.0900
INFO - 2020-10-14 13:03:14 --> Router Class Initialized
INFO - 2020-10-14 13:03:14 --> Output Class Initialized
INFO - 2020-10-14 13:03:14 --> Security Class Initialized
DEBUG - 2020-10-14 13:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 13:03:14 --> CSRF cookie sent
INFO - 2020-10-14 13:03:14 --> CSRF token verified
INFO - 2020-10-14 13:03:14 --> Input Class Initialized
INFO - 2020-10-14 13:03:14 --> Language Class Initialized
INFO - 2020-10-14 13:03:14 --> Security Class Initialized
DEBUG - 2020-10-14 13:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-14 13:03:14 --> CSRF cookie sent
INFO - 2020-10-14 13:03:14 --> CSRF token verified
INFO - 2020-10-14 13:03:14 --> Input Class Initialized
INFO - 2020-10-14 13:03:14 --> Language Class Initialized
INFO - 2020-10-14 13:03:14 --> Language Class Initialized
INFO - 2020-10-14 13:03:14 --> Config Class Initialized
INFO - 2020-10-14 13:03:14 --> Language Class Initialized
INFO - 2020-10-14 13:03:14 --> Config Class Initialized
INFO - 2020-10-14 13:03:14 --> Loader Class Initialized
INFO - 2020-10-14 13:03:14 --> Helper loaded: url_helper
INFO - 2020-10-14 13:03:14 --> Loader Class Initialized
INFO - 2020-10-14 13:03:14 --> Helper loaded: file_helper
INFO - 2020-10-14 13:03:14 --> Helper loaded: url_helper
INFO - 2020-10-14 13:03:14 --> Helper loaded: string_helper
INFO - 2020-10-14 13:03:14 --> Helper loaded: file_helper
INFO - 2020-10-14 13:03:14 --> Helper loaded: string_helper
INFO - 2020-10-14 13:03:14 --> Database Driver Class Initialized
INFO - 2020-10-14 13:03:14 --> Database Driver Class Initialized
INFO - 2020-10-14 13:03:14 --> Email Class Initialized
INFO - 2020-10-14 13:03:14 --> Email Class Initialized
INFO - 2020-10-14 13:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 13:03:14 --> Controller Class Initialized
DEBUG - 2020-10-14 13:03:14 --> Home MX_Controller Initialized
INFO - 2020-10-14 13:03:14 --> Model "Common_model" initialized
INFO - 2020-10-14 13:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-14 13:03:14 --> Controller Class Initialized
DEBUG - 2020-10-14 13:03:14 --> Home MX_Controller Initialized
INFO - 2020-10-14 13:03:14 --> Model "Common_model" initialized
INFO - 2020-10-14 13:03:14 --> Final output sent to browser
DEBUG - 2020-10-14 13:03:14 --> Total execution time: 0.0356
INFO - 2020-10-14 13:03:14 --> Final output sent to browser
DEBUG - 2020-10-14 13:03:14 --> Total execution time: 0.0369
