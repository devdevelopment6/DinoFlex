<?php 
 
// To use reCAPTCHA, we need to sign up for an API key pair for your site which we already did above.
 
$config['recaptcha_site_key'] = '6LcYZ0AUAAAAANSNv7WOxoLHEn229F7vDHQFaHVT'; 
$config['recaptcha_secret_key'] = '6LcYZ0AUAAAAACkDvVROfwkqPAeunnedx74A4w2T'; 
 
// reCAPTCHA supports 40+ languages
 
$config['recaptcha_lang'] = 'en'; 
 
/* End of file recaptcha.php */ 
/* Location: ./application/config/recaptcha.php */

