<!-- Indor Out Door -->
				<div class="col-sm-12 col-xs-12 col-md-6 col-lg-6">
					<div class="slogan">
					 <h3>Add YOUR ACCOUNT</h3>
						<div style="margin-top: 50px; subsl">
								<div class="row">
									<div class="col-sm-12 col-xs-12 col-md-4 col-lg-4">
										<div class="form-group ">
    										<label class="name_label">User Name</label>
    										<input type="text" class="form-control" name ="name" id="uname" placeholder="Your Name"/>
 										 </div>
									</div>
									<div class="col-sm-12 col-xs-12 col-md-4 col-lg-4">
										<div class="form-group">
											<label class="name_label">Email ID</label>
											<input type="email" class="form-control" name="newemail" id="email" placeholder="Your Email"/>
										</div>
									</div>
									<div class="col-sm-12 col-xs-12 col-md-4 col-lg-4">
										<div class="form-group">
											<label class="name_label">Mobile Number</label>
											<input type="text" class="form-control" name="mobile" id="mobile" placeholder="Mobile Number"/>
										</div>
									</div>
									<div class="col-sm-12 col-xs-12 col-md-4 col-lg-4">
										<div class="form-group">
											<label class="name_label">Password</label>
											<input type="password" class="form-control" name="newpwd" id="newpwd" placeholder="Password"/>
										</div>
									</div>
									<div class="col-sm-12 col-xs-12 col-md-4 col-lg-4">
										<div class="form-group">
											<label class="name_label">Confirm Password</label>
											<input type="password" class="form-control" name="connewpwd" id="connewpwd" placeholder="Confirm Password"/>
										</div>
									</div>
									
								</div>
								<!--<div class="row">
									<div class="col-sm-12 col-xs-12 col-md-6 col-lg-6">
										<div class="form-group">
											<div class="g-recaptcha" data-sitekey="6Lf3WH8UAAAAAGAnQONl8l8bodoEW_7yPgozQwNm"></div>
											<label id="g-recaptcha-response-error" class="error" for="g-recaptcha-response"></label>
										</div>
									</div>
								</div>-->
						</div>
					</div>
				</div>
			
				
				<!--<div class="col-xs-12 col-sm-12	col-md-6 delnex">	
					<div class="step-links">
						<ul>
							<div class="form-group">
								<input type="submit" class="btn red text-right" name="submit" value="SAVE"/>
								<a class="btn trans text-right spacesideac leftcss" href="">DELETE ACCOUNT</a>
							</div>
						</ul>
					</div>
				</div>-->
			
			</div>
		<div class="step-links">
			<ul>
				<div class="form-group">
					<input type="submit" class="btn red text-right" name="submit" value="SAVE"/>
					<!--<a class="btn transreg text-right spacesideac leftcss delete_account" href="">Edit ACCOUNT</a>-->
				</div>
			</ul>
		