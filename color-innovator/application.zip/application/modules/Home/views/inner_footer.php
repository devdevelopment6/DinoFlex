<footer>
	 <div id="cus_foo">
		 <div class="submit-flooring">
			<a href="https://www.summit-flooring.com" title="Summit Flooring" target="_blank">
			  <img src="<?php echo base_url(); ?>home_assets/images/submit-flooring.png" alt="">
			</a>
		  </div>
	</div> 
</footer>